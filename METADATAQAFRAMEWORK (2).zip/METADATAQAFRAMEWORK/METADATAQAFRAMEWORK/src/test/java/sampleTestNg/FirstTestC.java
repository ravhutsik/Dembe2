package sampleTestNg;


import cm_utils.BusinessBankingHelper;
import cm_utils.ExcelDataProvider;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;
import objects.*;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.ITestResult;
import org.testng.annotations.*;

import java.io.File;
import java.util.concurrent.TimeUnit;

public class FirstTestC {

    private static WebDriver driver = null;
    LoginObject loginObject;

    ExtentHtmlReporter htmlReporter;
    ExtentReports extentReports;
    BusinessBankingHelper businessBankingHelper;
    ExtentTest test;

    private String absolutepath = "C:\\Users\\NB325553\\METADATAQAFRAMEWORK\\target\\Screenshotfolder\\";

    private static ThreadLocal threadLocal = new ThreadLocal();

    TakesScreenshot Screenshot = (TakesScreenshot)driver;

    @BeforeSuite
    void setUp() {
        htmlReporter = new ExtentHtmlReporter("target\\extent.html");

        htmlReporter.config().setTestViewChartLocation(ChartLocation.BOTTOM);
        htmlReporter.config().setChartVisibilityOnOpen(true);
        htmlReporter.config().setTheme(Theme.STANDARD);
        htmlReporter.config().setDocumentTitle("EMI Front End Testing");
        htmlReporter.config().setEncoding("utf-8");
        htmlReporter.config().setReportName("EMI Front End Testing");

        extentReports = new ExtentReports();
        extentReports.attachReporter(htmlReporter);

        String url = "https://xqawaabn01.africa.nedcor.net:6263/nedbank_metahub_qa_dg/dg/index.jsp#/abvdl-component?view=BizGlossaryTopicLandingView&rid_main=id_main1642489818598_4";
        System.setProperty("webdriver.edge.driver", "common_drivers" + File.separator + "msedgedriver.exe");

        if (driver == null) {
            driver = new EdgeDriver();
        }

        driver.get(url); // open the metadata hub system URL
        driver.manage().window().maximize(); //maximise the browser
        driver.manage().deleteAllCookies();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); //waiting for the page to load

    }

    @BeforeTest
    void initialise() {


        String username = "nb325553";
        String password = "@@Dee06827986";

        businessBankingHelper = new BusinessBankingHelper(driver);
        loginObject = new LoginObject(driver);

        loginObject.login(username, password);
    }

    @Test(priority = 1)
    void businesslineage() {

        BusinessLineage businesslineage = new BusinessLineage(driver);
        test = extentReports.createTest("Load Business lineage", "The business lineage is loaded successfully");
        try {

            Thread.sleep(10000);

            businesslineage.businessLineage();

            test.pass("Login", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"LoginAccess.jpg").build());
            test.pass("SelectBusinessMetadata and Business Asset", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath + "BusinessMetadataandBusinessAsset.jpg").build());
            test.pass("TickApplication group,choose app group and select lineage", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath + "AppgroupwithLineage.jpg").build());
            test.pass("Showing Lineage", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath + "LineageDisplay.jpg").build());


        } catch (Exception e) {
            e.printStackTrace();
            throw new AssertionError();
        }
    }

    @Test(priority = 2)
    void clickBusinessMetadata() {

        BusinessMetadata businessmetadata = new BusinessMetadata (driver);
        test = extentReports.createTest("View Details and Quicklooks", "Test to View Details and Quicklooks");
        try {

            Thread.sleep(10000);

            businessmetadata.clickbusinessmetadata();

            test.pass("Login", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"LoginAccess.jpg").build());
            test.pass("SelectBusinessMetadata and Glossary", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath + "BusinessMetadataandGlassary.jpg").build());
            test.pass("Select Business Term and Details", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath + "BusinessTermAndDetails.jpg").build());
            test.pass("Select Business Term and Quicklook", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath + "BusinessTermAndQuickLook.jpg").build());
            test.pass("Show Quicklook", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath + "ViewQuickLook.jpg").build());

        } catch (Exception e) {
            e.printStackTrace();
            throw new AssertionError();
        }
    }

    @Test(priority = 3)
    void technicalmetadata() {

        TechnicalMetadata technicalmetadata = new TechnicalMetadata(driver);
        test = extentReports.createTest("Technical Metadata","When viewing any technical asset I must be able to click on the Details or Quick Look options and see the relevant details.");

        try {
            Thread.sleep(10000);

            technicalmetadata.DataAssetDetails();

            test.pass("Login", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"LoginAccess.jpg").build());
            test.pass("Technical Metadata And Data Asset", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"DataAssetLink.jpg").build());
            test.pass("Datasets with Details", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"DatasetDetails.jpg").build());
            technicalmetadata.clickDataElements();
            test.pass("Data Elements with Details", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"DataElementsDetails.jpg").build());
            technicalmetadata.clickExecutable();
            test.pass("Executables with Details", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"ExecutablesDetails.jpg").build());
            technicalmetadata.clickTasks();
            test.pass("Tasks with Details", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"TasksDetails.jpg").build());
            technicalmetadata.clickITApplications();
            test.pass("ITApplication with Details", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"ITApplicationDetails.jpg").build());
            technicalmetadata.clickITSystem();
            test.pass("ITSystem with Details", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"ITSystemDetails.jpg").build());
            technicalmetadata.clickRepositories();
            test.pass("Repositories with Details", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"RepositoriesDetails.jpg").build());
            technicalmetadata.clickSchemasAndDirectories();
            test.pass("SchemasAndDirectories with Details", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"SchemasAndDirectoriesDetails.jpg").build());
            technicalmetadata.PrintDataElementLineage();
            test.pass("PrintButton", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"PrintReport.jpg").build());
            test.pass("SaveAsPDF", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"SaveAsPDF.jpg").build());
            technicalmetadata.matricsanddimension();
            test.pass("Insert into search textbox", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"InsertMetricsAndDimension.jpg").build());
            test.pass("Click SearchButton", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"SearchMetricsAndDimension.jpg").build());


            businessBankingHelper.takeSnapShot("test");


        } catch (Exception e) {
            e.printStackTrace();
            throw new AssertionError();
        }

    }
    @Test(priority = 4)
    void diagrams() {

        Diagram diagram = new Diagram(driver);
        test = extentReports.createTest("Diagrams","load the diagram,view diagram and link it to technical lineage,and link the diagram  with lineage");

        try {
            Thread.sleep(10000);
            diagram.ClickDiagrams();
            businessBankingHelper.takeSnapShot("test");

            test.pass("Login", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"LoginAccess.jpg").build());

            test.pass("Select Diagrams Element", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"diagrams.jpg").build());

            test.pass("Select a Diagram and view diagram", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"choosediagram.jpg").build());
            test.pass("view diagram", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"ViewDiagram.jpg").build());

            test.pass("Select Risk Report Categories and view report", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"ChooseReport.jpg").build());
            test.pass("view report", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"viewReport.jpg").build());

            test.pass("View Risk Report", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"BA400reportlink.jpg").build());
            test.pass("Select Lineage", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"diagramlineage.jpg").build());



        } catch (Exception e) {
            e.printStackTrace();
            throw new AssertionError();
        }

    }
    @Test(priority = 5)
    void Report() {

        Report report = new Report(driver);

        test = extentReports.createTest("Create and view reports","I can create my reports,have access and can see my reports");

        try {
            Thread.sleep(10000);
            report.ClickReport();
            businessBankingHelper.takeSnapShot("test");

            test.pass("Login", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"LoginAccess.jpg").build());
            test.pass("Click Reports and new report", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"createnewReport.jpg").build());
            test.pass("Select DATASETS AND Data Elements", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"DatasetAndDataElements.jpg").build());
            test.pass("Enable inputs and save your report public ", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"enableimputargumentsondataset.jpg").build());
            test.pass("Give your report a name", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"namereport.jpg").build());
            test.pass("Click Edit to edit report", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"editreport.jpg").build());
            test.pass("update the report with tech group", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"saveDescriptiongroup.jpg").build());
            test.pass("View Shared Public Reports", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"ViewShareReports.jpg").build());
            test.pass("Insert All Registered Users", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"SearchReport.jpg").build());
            test.pass("Save to Edit", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"SaveToEdit.jpg").build());
            test.pass("OK to Edit", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"OKEdit.jpg").build());
            test.pass("select report", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"SelectreportandViewDetails.jpg").build());
            test.pass("View public report details", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"PublicReportDetails.jpg").build());
            test.pass("Add Tech Group", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"AddTechGroup.jpg").build());
        } catch (Exception e) {
            e.printStackTrace();
            throw new AssertionError();
        }

    }
    @Test(priority = 6)
    void businesstotechnicallineage() {

        BusinessToTechnicalLinking businesstoTechnicalLinking = new BusinessToTechnicalLinking(driver);

        test = extentReports.createTest("Link Business to Technical Lineage","The business linage is linked to the Technical linage correctly and the i.e. Account Number *Business lineage - Resides in system X and hosted in SQL Database");

        try {
            Thread.sleep(10000);
            businesstoTechnicalLinking.businesstotechnicallineage();
            businessBankingHelper.takeSnapShot("test");

            test.pass("Login", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"LoginAccess.jpg").build());
            test.pass("BusinessMetadata And BusinessGlossaryn", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"BusinessMetadataAndBusinessGlossary.jpg").build());
            test.pass("Search and choose the lineage", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"searchUntickshowpublishedClickHastechnicallineageChooselineage.jpg").build());
            test.pass("Link lineage and apply the grouping strategy with Annotations", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"ApplyGroupingStrategyAapplyGroupingStrategy.jpg").build());
            test.pass("Search Technical Lineage", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"InsertBDW04182.jpg").build());

        } catch (Exception e) {
            e.printStackTrace();
            throw new AssertionError();
        }

    }
    @Test(priority = 7)
    void approveimportedfeed() {

        ApproveImportedFeed approveimportedfeed = new ApproveImportedFeed(driver);

        test = extentReports.createTest("Approve Imported Feed","The approve button works correctly and I can approve the work that was submitted by the import");

        try {
            Thread.sleep(10000);
            approveimportedfeed.ClickImportMonitor();
            businessBankingHelper.takeSnapShot("test");

            test.pass("Login", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"LoginAccess.jpg").build());
            test.pass("Untick Last 7days feeds ran", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"allmyfeeds.jpg").build());
            test.pass("Select all feeds ran", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"feedsran.jpg").build());
            test.pass("Select feed and details", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"feeddetails.jpg").build());
            test.pass("Select submit and ok", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"oktosubmit.jpg").build());
            test.pass("Select approve and ok", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"oktoapprove.jpg").build());
            test.pass("Show Approved Feed", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"ShowApprovedFeed.jpg").build());

        } catch (Exception e) {
            e.printStackTrace();
            throw new AssertionError();
        }

    }
    @Test(priority = 8)
    void approvefeedaddedbyUI() {

        ApproveWorkAddedByUI approveworkAddedByUI = new ApproveWorkAddedByUI(driver);

        test = extentReports.createTest("Approve Imported Feed on UI","The approve button works correctly and I can approve the work that was submitted by the import");

        try {
            Thread.sleep(10000);
            approveworkAddedByUI.ClickDiagramToApproveUIFeed();
            businessBankingHelper.takeSnapShot("test");

            test.pass("Login", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"LoginAccess.jpg").build());
            test.pass("Select Diagrams and Diagrams", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"ClickDiagramsAndViewDiagrams.jpg").build());
            test.pass("Choose a diagram and its Details", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"UntickpublishedChooseDiagramAnddetails.jpg").build());
            test.pass("Submit feed", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"SubmitAndOk.jpg").build());
            test.pass("Approve feed", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"ApproveAndOk.jpg").build());
            test.pass("Show Approved feed", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"ApprovedFeed.jpg").build());

        } catch (Exception e) {
            e.printStackTrace();
            throw new AssertionError();
        }

    }
    @Test(priority = 9)
    void importandfeeds() {

        Importsandfeeds importsandfeeds = new Importsandfeeds(driver);
        test = extentReports.createTest("Run Imported Feeds","Run Imported Feeds and create new feeds,withdraw,discard,submit and approve the feeds");

        try {
            Thread.sleep(10000);
            importsandfeeds.ClickImportMonitor();
            businessBankingHelper.takeSnapShot("test");

            test.pass("Login", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"LoginAccess.jpg").build());
            test.pass("Untick Last day run Link", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"UntickLastdayrunLink.jpg").build());
            test.pass("Choose a feed and Run Feed", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"RunChosenFeed.jpg").build());
            test.pass("Add New Feed", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"AddnewFeed.jpg").build());
            test.pass("Select Excel And Next", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"SelectExcelAndNext.jpg").build());
            test.pass("Select Standard Excel Import And then Next", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"SelectStandardExcelImportAndNext.jpg").build());
            test.pass("Give your report a name", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"NameYourReport.jpg").build());

            test.pass("Select a Feed and Details", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"ChooseFeedAndDetails.jpg").build());
            test.pass("Select Submit Button and OK", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"SubmitFeedAndOK.jpg").build());
            test.pass("Select Withdraw And OK", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"WithdrawFeedAndOK.jpg").build());
            test.pass("Select Submit Button again And OK", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"SubmitButtonAndOK.jpg").build());
            test.pass("Select Approve Button And OK", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"ApproveButtonAndOK.jpg").build());
            test.pass("Select Run to run the Feed", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"RunFeed.jpg").build());
            test.pass("Select Discard And OK", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"DiscardAndOK.jpg").build());
            test.pass("Select Run to run the Feed", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"RunFeed.jpg").build());
            test.pass("Select DiscardandRerun to rerun the Feed", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"DiscardandRerunFeed.jpg").build());
            test.pass("Select Yes To confirm to DiscardandRerun the Feed", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"YesToDiscardandRerunFeed.jpg").build());
            test.pass("Feed Discarded Successfully", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"Feeddiscarded.jpg").build());

        } catch (Exception e) {
            e.printStackTrace();
            throw new AssertionError();
        }

    }
    @AfterMethod
    void teardown(ITestResult result){
        try {


            if(result.getStatus() == ITestResult.FAILURE) {
                businessBankingHelper.getScreenShot("failure");
                test.fail(result.getThrowable().getMessage(), MediaEntityBuilder.createScreenCaptureFromPath(absolutepath + "failure" + ".png").build());
            }


        }catch (Exception e){
            e.printStackTrace();
        }
    }


    @DataProvider(name = "testData1")
     public Object[][] getData(){

         ExcelDataProvider excelDataProvider = new ExcelDataProvider();

         Object object = excelDataProvider.testData("C:\\onboarding\\ADAMCO\\EMIData.xlsx", "Sheet1");

         return (Object[][]) object;
     }

    @AfterMethod
    void teardown( ){
        System.out.println("After Test");
    }

    @AfterSuite
    void tearF(){
        extentReports.flush();
    }
}
