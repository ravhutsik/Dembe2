package sampleTestNg;
import cm_utils.BusinessBankingHelper;
import cm_utils.ExcelDataProvider;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;
import objects.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.ITestResult;
import org.testng.annotations.*;

import java.io.File;
import java.util.concurrent.TimeUnit;

public class Running {

    private static WebDriver driver = null;
    LoginObject loginObject;

    ExtentHtmlReporter htmlReporter;
    ExtentReports extentReports;
    BusinessBankingHelper businessBankingHelper;
    ExtentTest test;

   // private String absolutepath = "C:\\Users\\NB325553\\METADATAQAFRAMEWORK\\target\\screenshot";

    private String absolutepath = "C:\\Users\\NB325553\\METADATAQAFRAMEWORK\\target\\Screenshotfolder\\";
    private static ThreadLocal threadLocal = new ThreadLocal();

    @BeforeSuite
    void setUp() {
        htmlReporter = new ExtentHtmlReporter("target\\extent.html");

        htmlReporter.config().setTestViewChartLocation(ChartLocation.BOTTOM);
        htmlReporter.config().setChartVisibilityOnOpen(true);
        htmlReporter.config().setTheme(Theme.STANDARD);
        htmlReporter.config().setDocumentTitle("EMI Front End Testing");
        htmlReporter.config().setEncoding("utf-8");
        htmlReporter.config().setReportName("EMI Front End Testing");

        extentReports = new ExtentReports();
        extentReports.attachReporter(htmlReporter);

        String url = "https://xqawaabn01.africa.nedcor.net:6263/nedbank_metahub_qa_dg/dg/index.jsp#/abvdl-component?view=BizGlossaryTopicLandingView&rid_main=id_main1642489818598_4";
//        String url = "https://xdevabwanbp01:6263/nedbank_metahub_dev_dg/dg/index.jsp#/abvdl-component?view=BizGlossaryTopicLandingView&rid_main=id_main1641548671214_1";
//        String url = "http://ciaabinitiomhqa.it.nednet.co.za:6261/cia_nedbank_metahub_dev/dg/index.jsp";
        System.setProperty("webdriver.edge.driver", "common_drivers" + File.separator + "msedgedriver.exe");

        if (driver == null) {
            driver = new EdgeDriver();
        }

        driver.get(url); // open the metadata hub system URL
        driver.manage().window().maximize(); //maximise the browser
        driver.manage().deleteAllCookies();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); //waiting for the page to load

    }

    @BeforeTest
    void initialise() {


        String username = "nb325553";
        String password = "@@Dee06827986";

        businessBankingHelper = new BusinessBankingHelper(driver);
        loginObject = new LoginObject(driver);

        loginObject.login(username, password);
    }

    @Test(priority = 1)
    void Report() {

        Report report = new Report(driver);

        test = extentReports.createTest("Create and view reports","I can create my reports,have access and can see my reports");

        try {
            Thread.sleep(10000);
            report.ClickReport();
            businessBankingHelper.takeSnapShot("test");

            test.pass("Login", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"LoginAccess.jpg").build());
            test.pass("Click Reports and new report", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"createnewReport.jpg").build());
            test.pass("Select DATASETS AND Data Elements", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"DatasetAndDataElements.jpg").build());
            test.pass("Enable inputs and save your report public ", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"enableimputargumentsondataset.jpg").build());
            test.pass("Give your report a name", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"namereport.jpg").build());
            test.pass("Click Edit to edit report", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"editreport.jpg").build());
            test.pass("update the report with tech group", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"saveDescriptiongroup.jpg").build());
            test.pass("View Shared Public Reports", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"ViewShareReports.jpg").build());
            test.pass("Insert All Registered Users", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"SearchReport.jpg").build());
            test.pass("Save to Edit", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"SaveToEdit.jpg").build());
            test.pass("OK to Edit", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"OKEdit.jpg").build());
            test.pass("select report", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"SelectreportandViewDetails.jpg").build());
            test.pass("View public report details", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"PublicReportDetails.jpg").build());
            test.pass("Add Tech Group", MediaEntityBuilder.createScreenCaptureFromPath(absolutepath +"AddTechGroup.jpg").build());
        } catch (Exception e) {
            e.printStackTrace();
            throw new AssertionError();
        }

    }
    @AfterMethod
    void teardown(ITestResult result){
        try {


            if(result.getStatus() == ITestResult.FAILURE) {
                businessBankingHelper.getScreenShot("failure");
                test.fail(result.getThrowable().getMessage(), MediaEntityBuilder.createScreenCaptureFromPath(absolutepath + "failure" + ".jpg").build());
            }


        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @DataProvider(name = "testData1")
    public Object[][] getData(){

        ExcelDataProvider excelDataProvider = new ExcelDataProvider();

        Object object = excelDataProvider.testData("C:\\onboarding\\METADATAQA\\EMIData.xlsx", "Sheet1");

        return (Object[][]) object;
    }

    @AfterMethod
    void teardown( ){
        System.out.println("After Test");
    }

    @AfterSuite
    void tearF(){
        extentReports.flush();
    }
}
