package cm_utils;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.PageFactory;

import java.io.File;
import java.util.List;

public class BusinessBankingHelper {

    private final WebDriver driver;

    public BusinessBankingHelper(WebDriver driver){
        this.driver=driver;

        //Initialise Elements
        PageFactory.initElements(driver, this);
    }

    public void verifyPage(String expected, WebElement webElement){

        String actualText = webElement.getText();
        Assert.assertEquals(expected.replaceAll(" ","") , actualText.replaceAll(" ",""));

    }
    public void verifyMultiPage(String expected, WebElement webElement){
        takeSnapShot(expected +" Page");
        String actualText = webElement.getText();
        Assert.assertEquals(expected.replaceAll(" ","") ,actualText.replaceAll(" ",""));
    }

    public void clickElement(WebElement webElement){
        webElement.click();
    }

    public int getWebElement(WebElement webElement, String elementName){

        List<WebElement> elements = webElement.findElements(By.xpath("*"));
        int index = 0;
        for (WebElement element: elements) {
            System.out.println(element);

            ++index;

            if(element.getText().trim().equals(elementName.trim())){
                return index;
            }
        }

        throw new AssertionError(elementName + " Not Found on the List");
    }

    public void verifyAndClickElement(WebElement webElement,String pictureName){
        try{
            takeSnapShot(pictureName.replaceAll("[^a-zA-Z0-9]",""));

            if(webElement.isDisplayed()){
                webElement.click();
            }else{
                throw new AssertionError( pictureName + " Element is not visible");
            }

        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }

    }
    public void verifyAndClickMultiElement(WebElement webElement,String pictureName){
        try{
            String actualText = webElement.getText();
            System.out.println(actualText);
            takeSnapShot(pictureName);
            if(webElement.isDisplayed()){
                webElement.click();
            }else{
                throw new AssertionError( pictureName + " Element is not visible");
            }
            takeSnapShot(pictureName +" Page");
            Assert.assertEquals(pictureName.replaceAll(" ","") ,actualText.replaceAll(" ",""));

        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }

    }

    public void navigateBack()  {
        driver.navigate().back();
    }


    public WebElement getWebElement(String value){
        return driver.findElement(By.xpath("//*[text() = '"+ value +"']"));
    }


    public void verifyAndClickElement(String expected, WebElement webElement,String pictureName){
        try{
            System.out.println(webElement.getText());
            takeSnapShot(pictureName);
            if(webElement.isDisplayed()){
                webElement.click();
            }else{
                throw new AssertionError("Element is not visible");
            }

        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }

    }
    public void sliderElement(WebElement element,int start, int terminate){
        for(int x = start; x < terminate;++x){
            element.sendKeys(Keys.ARROW_RIGHT);
        }
    }

    public void performOperation(String [] listOfValues){
        for (String listOfValue : listOfValues) {
            verifyAndClickMultiElement(getWebElement(listOfValue), listOfValue);
            navigateBack();
        }
    }
    public void verifyList(String [] listOfValues){
        for (String listOfValue : listOfValues) {
            if(!getWebElement(listOfValue).isDisplayed()){
                throw new AssertionError(listOfValue + " is not displayed");
            }
        }
    }

    public void takeSnapShot(String fileWithPath){

        try{
            TakesScreenshot takeScreenshot = ((TakesScreenshot) driver);

            File srcFile = takeScreenshot.getScreenshotAs(OutputType.FILE);


            File destFile = new File("C:\\Users\\NB325553\\METADATAQAFRAMEWORK\\target\\Screenshotfolder\\" + fileWithPath.replaceAll("[^a-zA-Z0-9]","") + ".jpg");

            FileUtils.copyFile(srcFile,destFile);

        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }
    public String getScreenShot(String fileWithPath){

        File destFile;
        try{
            TakesScreenshot takeScreenshot = ((TakesScreenshot) driver);

            File srcFile = takeScreenshot.getScreenshotAs(OutputType.FILE);

             destFile = new File("C:\\Users\\NB325553\\METADATAQAFRAMEWORK\\target\\Screenshotfolder\\" + fileWithPath.replaceAll("[^a-zA-Z0-9]","") + ".jpg");

            FileUtils.copyFile(srcFile,destFile);

        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }

        return destFile.getAbsolutePath();
    }

    public void closePage(){
        driver.close();
    }
}
