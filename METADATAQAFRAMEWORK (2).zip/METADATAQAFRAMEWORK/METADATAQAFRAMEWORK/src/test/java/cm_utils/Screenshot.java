package cm_utils;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;

public class Screenshot {


    public void takeSnapShot(WebDriver webDriver, String fileWithPath)throws Exception{

        TakesScreenshot takeScreenshot = ((TakesScreenshot) webDriver);

        File srcFile = takeScreenshot.getScreenshotAs(OutputType.FILE);


        File destFile = new File(fileWithPath);

        FileUtils.copyFile(srcFile,destFile);


    }
}
