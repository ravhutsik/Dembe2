package cm_utils;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFShape;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtils {


    static XSSFWorkbook workbook;
    static XSSFSheet sheet;

    public ExcelUtils(String excelPath, String sheetName){
        try{
            workbook = new XSSFWorkbook(excelPath);
            sheet = workbook.getSheet(sheetName);

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public int getColCount(){
        int colCount =0;
        try {
             colCount = sheet.getRow(0).getPhysicalNumberOfCells();
        }catch (Exception e){
            e.printStackTrace();
        }

        return colCount;
    }

    public int getRowCount(){
        int rowCount = 0;
        try {
             rowCount = sheet.getPhysicalNumberOfRows();
        }catch (Exception e){
            e.printStackTrace();
        }

        return rowCount;
    }

    public String getCellDataString(int rowNum, int colnum){

        String cellData = "";

        try{
            cellData = sheet.getRow(rowNum).getCell(colnum).getStringCellValue();
        }catch (Exception e){
            e.printStackTrace();
        }

        return cellData;
    }
}
