package objects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import cm_utils.BusinessBankingHelper;

public class BusinessToTechnicalLinking {

    public WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    Actions actions;


    @FindBy(how = How.XPATH, using = "//*[@id=\"abDropdownAnchor\"]")
    public WebElement BusinessMetadaLink;

    @FindBy(how = How.XPATH, using = "//*[text() = 'Business Glossary']")
    public WebElement BusinessGlossaryLink;

    @FindBy(how = How.XPATH, using = "//*[@id=\"explore\"]")
    public WebElement SearchButtonGlossaryLink;

    @FindBy(how = How.XPATH, using = "/html/body/div[1]/section/div/div[3]/div/div/div/div/div/div/div/div/div[3]/div/div/div[1]/div/div/div[2]/label/input")
    public WebElement untickshowpublishedLink;

    @FindBy(how = How.XPATH, using = "/html/body/div[1]/section/div/div[3]/div/div/div/div/div/div/div/div/div[3]/div/div/div[1]/div/div/div[6]/div[2]/div[2]/label/input")
    public WebElement HasTechnicallineageLink;

    @FindBy(how = How.XPATH, using = "//*[@id=\"explore-panel\"]/div/div/div[1]/div/div/div[3]/div/input")
    public WebElement SearchButtonLink;


    @FindBy(how = How.XPATH, using = "//*[@id=\"searchButton\"]")
    public WebElement SearchbuttonLink;

    @FindBy(how = How.XPATH, using = "//*[@id=\"explore-panel\"]/div/div/div[2]/div[3]/div/div/div[1]/div/div/div[2]/div[2]/div/div[1]/div[1]/span/a")
    public WebElement BDW04182Link;


    @FindBy(how = How.XPATH, using = "/html/body/div[2]/div/div/div[2]/div/div[3]/div/div/div/div[3]/div/a[1]/span/span")
    public WebElement LineageLink;

    @FindBy(how = How.XPATH, using = "//*[@id=\"boxOptions\"]/div/ul/li[2]/a/span/span")
    public WebElement LinktotechnicallineageLink;

    @FindBy(how = How.XPATH, using = "/html/body/div[1]/section/div/div[3]/div/div/div/div/div[2]/div/div/div/div[2]/div/div/div[3]/div/div[5]/div[1]")
    public WebElement GroupingstrategyLink;

    @FindBy(how = How.XPATH, using = "/html/body/div[1]/section/div/div[3]/div/div/div/div/div[2]/div/div/div/div[2]/div/div/div[3]/div/div[6]/div/div/div[1]/div[3]/div/div/div/input")
    public WebElement ExpansionLink;

    @FindBy(how = How.XPATH, using = "/html/body/div[1]/section/div/div[3]/div/div/div/div/div[2]/div/div/div/div[2]/div/div/div[3]/div/div[6]/div/div/div[1]/div[1]/div[2]/button")
    public WebElement ApplyLink;

    @FindBy(how = How.XPATH, using = "//*[@id=\"lineagePage\"]/div[2]/div/div/div[3]/div/div[9]/div[1]")
    public WebElement AnnotationsLink;

    @FindBy(how = How.XPATH, using = "//*[@id=\"BizTermObjectTechnicalLineageGraph\"]/div/div[3]/div/div[10]/div/div[1]/div/div[2]/div[2]/label")
    public WebElement BusinessTermLink;



    public BusinessToTechnicalLinking(WebDriver driver) {
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        actions = new Actions(driver);
        PageFactory.initElements(driver, this);
    }

    public void businesstotechnicallineage() {

        try {
            Thread.sleep(3000);
            actions.click(BusinessMetadaLink).build().perform();
            Thread.sleep(1000);
            businessBankingHelper.takeSnapShot("BusinessMetadataAndBusinessGlossary");
            actions.doubleClick(BusinessGlossaryLink).build().perform();
            Thread.sleep(2000);

            actions.click(SearchButtonGlossaryLink).build().perform();
            Thread.sleep(2000);
        actions.click(untickshowpublishedLink).build().perform();
            Thread.sleep(1000);
        actions.click(HasTechnicallineageLink).build().perform();
            Thread.sleep(1000);

            actions.sendKeys(SearchButtonLink,"BDW04182").build().perform();
            Thread.sleep(2000);
            businessBankingHelper.takeSnapShot("InsertBDW04182");
            actions.click(SearchbuttonLink).build().perform();
            Thread.sleep(5000);

        actions.click(BDW04182Link).build().perform();
            Thread.sleep(2000);
            businessBankingHelper.takeSnapShot("searchUntickshowpublishedClickHastechnicallineageChooselineage");
            actions.click(LineageLink).build().perform();
            Thread.sleep(5000);
        actions.doubleClick(LinktotechnicallineageLink).build().perform();
            Thread.sleep(2000);

        actions.click(GroupingstrategyLink).build().perform();
            Thread.sleep(1000);

            businessBankingHelper.sliderElement(ExpansionLink,1,5);
            Thread.sleep(1000);

        actions.click(ApplyLink).build().perform();
            Thread.sleep(1000);
        actions.click(AnnotationsLink).build().perform();
            Thread.sleep(1000);
        actions.click(BusinessTermLink).build().perform();
            Thread.sleep(5000);
            businessBankingHelper.takeSnapShot("ApplyGroupingStrategyAapplyGroupingStrategy");

        } catch (InterruptedException e) {
            e.printStackTrace();
        }


    }

}