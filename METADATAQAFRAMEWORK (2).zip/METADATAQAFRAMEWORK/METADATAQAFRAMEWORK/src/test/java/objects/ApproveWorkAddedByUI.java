package objects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import cm_utils.BusinessBankingHelper;

public class ApproveWorkAddedByUI {

    public WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    Actions actions;

    @FindBy(how = How.XPATH, using = "/html/body/div[1]/header/div/div/div/div[2]/ul[1]/li[7]/a/span[1]")
    public WebElement DiagramsLink;

    @FindBy(how = How.XPATH, using = "/html/body/div[1]/header/div/div/div/div[2]/ul[1]/li[7]/ul/button/span/span")
    public WebElement DiagramLink;

    @FindBy(how = How.XPATH, using = "/html/body/div[1]/section/div/div[3]/div/div/div/div/div[2]/div/div/div/div/div/div/div/div[1]/div/div/div[2]/label/input")
    public WebElement UntickshowpublishedLink;
    @FindBy(how = How.XPATH, using = "//*[text() = 'testingg']")
    public WebElement DembeTestDiagram1Link;
    @FindBy(how = How.XPATH, using = "//*[text() = 'Details']")
    public WebElement DetailsLink;
    @FindBy(how = How.XPATH, using = "/html/body/div[1]/section/div/div[3]/div/div/div/div/div[2]/div/div[3]/div[1]/div/div/div[2]/div[2]/div/div[2]/div/div/div/button[1]")
    public WebElement SubmitLink;
    @FindBy(how = How.XPATH, using = "/html/body/div[2]/div/div/div[3]/div/button[1]")
    public WebElement OksubmitLink;
    @FindBy(how = How.XPATH, using = "//*[@id=\"wfTaskBtn\"]")
    public WebElement ApproveLink;
    @FindBy(how = How.XPATH, using = "//*[@id=\"okButton\"]")
    public WebElement OkApproveLink;


    public ApproveWorkAddedByUI(WebDriver driver) {
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        actions = new Actions(driver);
        PageFactory.initElements(driver, this);

    }

    public void ClickDiagramToApproveUIFeed() {
        try {
            actions.click(DiagramsLink).build().perform();
            businessBankingHelper.takeSnapShot("ClickDiagramsAndViewDiagrams");

            actions.doubleClick(DiagramLink).build().perform();
            Thread.sleep(3000);
        actions.click(UntickshowpublishedLink).build().perform();
            Thread.sleep(2000);
        actions.click(DembeTestDiagram1Link).build().perform();
            Thread.sleep(2000);
            businessBankingHelper.takeSnapShot("UntickpublishedChooseDiagramAnddetails");
        actions.click(DetailsLink).build().perform();
            Thread.sleep(2000);
        actions.click(SubmitLink).build().perform();
            Thread.sleep(2000);
            businessBankingHelper.takeSnapShot("SubmitAndOk");
        actions.click(OksubmitLink).build().perform();
            Thread.sleep(2000);
        actions.click(ApproveLink).build().perform();
            Thread.sleep(5000);
            businessBankingHelper.takeSnapShot("ApproveAndOk");
            actions.click(OkApproveLink).build().perform();
            Thread.sleep(8000);
            businessBankingHelper.takeSnapShot("ApprovedFeed");
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}
