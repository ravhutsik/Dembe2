package objects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import cm_utils.BusinessBankingHelper;

public class BusinessMetadata {

    public WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    Actions actions;

    @FindBy(how = How.XPATH, using = "//*[@id=\"abDropdownAnchor\"]")
    public WebElement BusinessMetadaLink;

    @FindBy(how = How.XPATH, using = "//*[text() = 'Business Glossary']")
    public WebElement BusinessGlossaryLink;

    @FindBy(how = How.XPATH, using = "//*[@id=\"explore\"]")
    public WebElement SearchButtonGlossaryLink;

    @FindBy(how = How.XPATH, using = "//*[@id=\"explore-panel\"]/div/div/div[1]/div/div/div[4]/div[2]/div[3]/label/input")
    public WebElement TickBusinessTermLink;

    @FindBy(how = How.XPATH, using = "//*[@id=\"explore-panel\"]/div/div/div[2]/div[3]/div/div/div[1]/div/div/div[2]/div[2]/div/div[1]/div[1]/span/a")
    public WebElement ChoosePSABusinessTermLink;

    @FindBy(how = How.XPATH, using = "//*[text() = 'Details']")
    public WebElement DetailsLink;

    @FindBy(how = How.XPATH, using = "//*[@id=\"bcPath\"]/div/div/span[3]/a")
    public WebElement PSALink;

    @FindBy(how = How.XPATH, using = "//*[text() = 'Quick Look...']")
    public WebElement QuicklookLink;


    public BusinessMetadata(WebDriver driver) {
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        actions = new Actions(driver);
        PageFactory.initElements(driver, this);

    }
    public void clickbusinessmetadata() {
        try {
            Thread.sleep(10000);
        actions.click(BusinessMetadaLink).build().perform();
            Thread.sleep(2000);
            businessBankingHelper.takeSnapShot("BusinessMetadataandGlassary");
        actions.doubleClick(BusinessGlossaryLink).build().perform();
            Thread.sleep(3000);

        actions.click(SearchButtonGlossaryLink).build().perform();
            Thread.sleep(2000);

        actions.click(TickBusinessTermLink).build().perform();
            Thread.sleep(2000);

        actions.click(ChoosePSABusinessTermLink).build().perform();
            Thread.sleep(1000);
            businessBankingHelper.takeSnapShot("BusinessTermAndDetails");
        actions.click(DetailsLink).build().perform();
            Thread.sleep(3000);
            businessBankingHelper.takeSnapShot("ViewDetails");
        actions.click(PSALink).build().perform();
            Thread.sleep(1000);
            businessBankingHelper.takeSnapShot("BusinessTermAndQuickLook");

        actions.click(QuicklookLink).build().perform();
            Thread.sleep(5000);
            businessBankingHelper.takeSnapShot("ViewQuickLook");

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
