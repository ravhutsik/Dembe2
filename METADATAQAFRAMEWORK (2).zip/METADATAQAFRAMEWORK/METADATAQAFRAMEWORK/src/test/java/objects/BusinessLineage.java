package objects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import cm_utils.BusinessBankingHelper;

public class BusinessLineage {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    Actions actions;


    @FindBy(how = How.XPATH, using = "//*[@id=\"abDropdownAnchor\"]")
    public WebElement BusinessMetadataLink;

    @FindBy(how = How.XPATH, using = "/html/body/div[1]/header/div/div/div/div[2]/ul[1]/li[1]/ul/button[2]/span/span")
    public WebElement BusinessAssetsLink;

    @FindBy(how = How.XPATH, using = "/html/body/div[1]/section/div/div[3]/div/div/div/div/div[2]/div/div/div/div/div[1]/div/div/div/div[4]/div[2]/div[1]/label/input")
    public WebElement SelectApplicationGroupLink;

    @FindBy(how = How.XPATH, using = "/html/body/div[1]/section/div/div[3]/div/div/div/div/div[2]/div/div/div/div/div[2]/div[3]/div[3]/table/tbody/tr[1]/td/div[1]/span/a")
    public WebElement AppGroupLink;

    @FindBy(how = How.XPATH, using = "//*[text() = 'Lineage']")
    public WebElement LineageLink;

    public BusinessLineage(WebDriver driver) {
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        actions = new Actions(driver);
        PageFactory.initElements(driver, this);

    }
    public void businessLineage(){
        try {
            Thread.sleep(5000);
        actions.click(BusinessMetadataLink).build().perform();
//            Thread.sleep(10000);
           businessBankingHelper.takeSnapShot("BusinessMetadataandBusinessAsset");
        actions.click(BusinessAssetsLink).build().perform();
            Thread.sleep(3000);
        actions.click(SelectApplicationGroupLink).build().perform();
            Thread.sleep(5000);

        actions.click(AppGroupLink).build().perform();

            Thread.sleep(3000);
            businessBankingHelper.takeSnapShot("AppgroupwithLineage");
        actions.click(LineageLink).build().perform();
            Thread.sleep(6000);
            businessBankingHelper.takeSnapShot("LineageDisplay");

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}
