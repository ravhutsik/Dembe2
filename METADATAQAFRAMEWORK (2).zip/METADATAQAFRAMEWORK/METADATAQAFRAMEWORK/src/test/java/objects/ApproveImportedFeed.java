package objects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import cm_utils.BusinessBankingHelper;

public class ApproveImportedFeed {

    public WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    Actions actions;

    @FindBy(how = How.XPATH, using = "//*[text() = 'Import Monitor']")
    public WebElement ImportMonitorLink;

    @FindBy(how = How.XPATH, using = "//*[@id=\"monitor-panel\"]/div/div/div[1]/div/div/div[3]/div[2]/div[1]/label/input")
    public WebElement UntickLastdayrunLink;

    @FindBy(how = How.XPATH, using = "//*[@id=\"monitor-panel\"]/div/div/div[1]/div/div/div[4]/div[1]/div")
    public WebElement ClickMyfeedsLink;

    @FindBy(how = How.XPATH, using = "/html/body/div[1]/section/div/div[3]/div/div/div/div/div/div/div/div/div[2]/div/div/div[1]/div/div/div[4]/div[2]/div[1]/label/input")
    public WebElement FeedsihaverunLink;

    @FindBy(how = How.XPATH, using = "//*[@id=\"monitor-panel\"]/div/div/div[2]/div[3]/div[1]/div/div/div[1]/div/div/div[2]/div[2]/div/div[51]/span/a")
    public WebElement DembefeedLink;

    @FindBy(how = How.XPATH, using = "//*[text() = 'Details']")
    public WebElement DetailsLink;

    @FindBy(how = How.XPATH, using = "//*[text() = 'Submit']")
    public WebElement SubmitLink;

    @FindBy(how = How.XPATH, using = "//*[text() = 'OK']")
    public WebElement OKSubmitLink;

    @FindBy(how = How.XPATH, using = "//*[text() = 'Approve']")
    public WebElement ApprovebuttonLink;

    @FindBy(how = How.XPATH, using = "//*[text() = 'OK']")
    public WebElement OkApproveLink;


    public ApproveImportedFeed(WebDriver driver) {
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        actions = new Actions(driver);
        PageFactory.initElements(driver, this);

    }

    public void ClickImportMonitor() {
        try {
            actions.click(ImportMonitorLink).build().perform();
            Thread.sleep(3000);
            actions.click(UntickLastdayrunLink).build().perform();
            businessBankingHelper.takeSnapShot("allmyfeeds");
            Thread.sleep(3000);
            actions.click(ClickMyfeedsLink).build().perform();
            Thread.sleep(2000);
            actions.click(FeedsihaverunLink).build().perform();
            businessBankingHelper.takeSnapShot("feedsran");
            Thread.sleep(3000);

            actions.click(DembefeedLink).build().perform();
            businessBankingHelper.takeSnapShot("feeddetails");
            actions.click(DetailsLink).build().perform();
            Thread.sleep(5000);
            actions.click(SubmitLink).build().perform();
            Thread.sleep(2000);
            businessBankingHelper.takeSnapShot("oktosubmit");
            actions.click(OKSubmitLink).build().perform();
            Thread.sleep(3000);
            actions.click(ApprovebuttonLink).build().perform();
            Thread.sleep(2000);
            businessBankingHelper.takeSnapShot("oktoapprove");
            actions.click(OkApproveLink).build().perform();
            Thread.sleep(5000);
            businessBankingHelper.takeSnapShot("ShowApprovedFeed");
        } catch (InterruptedException e) {
            e.printStackTrace();

        }
    }
}

