package objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Diagram {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    Actions actions;


    @FindBy(how = How.XPATH, using = "/html/body/div[1]/header/div/div/div/div[2]/ul[1]/li[7]/a/span[1]")
    public WebElement DiagramsLink;

   @FindBy(how = How.XPATH, using = "/html/body/div[1]/header/div/div/div/div[2]/ul[1]/li[7]/ul/button/span/span")
   // @FindBy(how = How.XPATH, using = "/html/body/div[1]/header/div[2]/div/div/div[2]/ul[1]/li[8]/ul/button/span/span")
    public WebElement DiagramLink;

    @FindBy(how = How.XPATH, using = "//*[text() = 'BCBS 239 Risk Report']")
    public WebElement SelectADiagramLink;

    @FindBy(how = How.XPATH, using = "//*[text() = 'View Diagram']")
    public WebElement ViewDiagramLink;

    @FindBy(how = How.XPATH, using = "/html/body/div[1]/section/div/div[3]/div/div/div/div/div[2]/div/div/div/div[2]")
    public WebElement OperationalReportLink;

    @FindBy(how = How.XPATH, using = "/html/body/div[2]/div/div[2]/div/div[3]/div/div/div/div[3]/div/div/a/span/span")
    public WebElement ViewOperationalDiagramLink;

    @FindBy(how = How.XPATH, using = "/html/body/div[1]/section/div/div[3]/div/div/div/div/div[2]/div/div/div/div[1]")
    public WebElement BA400Link;

    @FindBy(how = How.XPATH, using = "/html/body/div[2]/div/div[2]/div/div[3]/div/div/div/div[3]/div/a[1]/span/span")
    public WebElement LineageLink;


    public Diagram(WebDriver driver) {
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        actions = new Actions(driver);
        PageFactory.initElements(driver, this);

    }

    public void ClickDiagrams() {
        try {

        actions.click(DiagramsLink).build().perform();
        businessBankingHelper.takeSnapShot("diagrams");

        actions.doubleClick(DiagramLink).build().perform();

        actions.click(SelectADiagramLink).build().perform();
            Thread.sleep(2000);
        businessBankingHelper.takeSnapShot("choosediagram");

        actions.click(ViewDiagramLink).build().perform();
            Thread.sleep(1000);
        businessBankingHelper.takeSnapShot("ViewDiagram");

        actions.click(OperationalReportLink).build().perform();
            Thread.sleep(1000);
        businessBankingHelper.takeSnapShot("ChooseReport");

        actions.click(ViewOperationalDiagramLink).build().perform();
            Thread.sleep(1000);
        businessBankingHelper.takeSnapShot("viewReport");

        actions.click(BA400Link).build().perform();
            Thread.sleep(1000);
        businessBankingHelper.takeSnapShot("BA400reportlink");

        actions.click(LineageLink).build().perform();
            Thread.sleep(5000);
        businessBankingHelper.takeSnapShot("diagramlineage");

        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

}
