package objects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import cm_utils.BusinessBankingHelper;

public class Report {

    public WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    Actions actions;

    @FindBy(how = How.XPATH, using = "//*[text() = 'Reports']")
    public WebElement ReportsLink;
    @FindBy(how = How.XPATH, using = "//*[text() = 'Create New Report']")
    public WebElement CreateReportLink;
    @FindBy(how = How.XPATH, using = "//*[@id=\"mhReportBuilder\"]/div/div/div[2]/div/div/div/div[1]/div/div[2]/div[3]/div[1]/div/div/div/div[5]/img")
    public WebElement DataAssetsLink;
    @FindBy(how = How.XPATH, using = "//*[@id=\"mhReportBuilder\"]/div/div/div[2]/div/div/div/div[1]/div/div[2]/div[3]/div[1]/div/div/div/div[8]/div/span")
    public WebElement DataElementLink;
    @FindBy(how = How.XPATH, using = "/html/body/div[1]/section/div/div[3]/div/div/div/div/div/div/div/div/div[2]/div/div[2]/div/div[1]/div/div[2]/div[3]/div[2]/span/span")
    public WebElement FiltersLink;
    @FindBy(how = How.XPATH, using = "//*[@id=\"mhReportBuilder\"]/div/div/div[2]/div/div[2]/div/div[1]/div/div[2]/div[4]/div/div[1]/div/div/div/div[8]/div/div/span")
    public WebElement DataSetsLink;
    @FindBy(how = How.XPATH, using = "//*[@id=\"filterValueBox\"]/div[2]/div/div/button")
    public WebElement DotsLink;
    @FindBy(how = How.XPATH, using = "//*[@id=\"dataSetsFacetedSearch\"]/div/div/div[2]/div[3]/div/div/div[1]/div/div/div[2]/div[2]/div/div[1]/div[1]/div/span/a")
    public WebElement GeneralInformationLink;
    @FindBy(how = How.XPATH, using = "//*[text() = 'Select']")
    public WebElement SelectLink;
    @FindBy(how = How.XPATH, using = "//*[@id=\"enableAsInputArg\"]")
    public WebElement EnableAsInputArgumentLink;
    @FindBy(how = How.XPATH, using = "//*[text() = 'OK']")
    public WebElement OkLink;
    @FindBy(how = How.XPATH, using = "//*[text() = 'Save']")
    public WebElement SaveLink;
    @FindBy(how = How.XPATH, using = "/html/body/div[2]/div/div/div[2]/div/div/div[2]/div/input")
    public WebElement ReportNameTextboxLink;
    @FindBy(how = How.XPATH, using = "//*[@id=\"ab-layer-31\"]/div[2]/div/div/label[1]/input")
    public WebElement PrivateReportLink;
    @FindBy(how = How.XPATH, using = "/html/body/div[2]/div/div/div[2]/div/div/label[2]/input")
    public WebElement PublicReportLink;
    @FindBy(how = How.XPATH, using = "//*[text() = 'OK']")
    public WebElement FinalOKLink;
    @FindBy(how = How.XPATH, using = "/html/body/div[1]/section/div/div[3]/div/div/div/div/div[1]/div[2]/div[1]/ul/li[1]/a/span/span")
    public WebElement ReportsagainLink;
    @FindBy(how = How.XPATH, using = "//*[@id=\"userreportsFacetedSearchInner\"]/div/div/div[2]/div[3]/div/div/div[1]/div/div/div[2]/div[2]/div/div[1]/div/span/a")
    public WebElement ChoosereportLink;
    @FindBy(how = How.XPATH, using = "//*[text() = 'Details']")
    public WebElement ReportdetailsLink;
    @FindBy(how = How.XPATH, using = "//*[text() = 'Edit Report']")
    public WebElement  EditReportLink;

    @FindBy(how = How.XPATH, using = "//*[text() = 'Subtype']")
    public WebElement  SubType;
    @FindBy(how = How.XPATH, using = "/html/body/div[1]/section/div/div[3]/div/div/div/div/div/div/div/div/div[2]/div/div[2]/div/div[1]/div/div[2]/div[2]/div/div[1]/div/div")
    public WebElement  DropDown;
    @FindBy(how = How.XPATH, using = "//*[@id=\"mhReportBuilder\"]/div/div/div[2]/div/div[2]/div/div[1]/div/div[2]/div[2]/div/div[1]/div/div/div/div[17]/div/div/span")
    public WebElement  TechGroup;

    @FindBy(how = How.XPATH, using = "//*[text() = 'Save As...']")
    public WebElement  SaveEditEmailLink;
    @FindBy(how = How.XPATH, using = "//*[text() = 'OK']")
    public WebElement  OOKLink;

    @FindBy(how = How.XPATH, using = "/html/body/div[1]/section/div/div[3]/div/div/div/div/div/div/div/div/div[2]/div/div[2]/div/div[1]/div/div[2]/div[2]/div/div[1]/div/div/div/div[7]/div/div/span")
    public WebElement  DescriptionLink;
    @FindBy(how = How.XPATH, using = "//*[@id=\"mhReportBuilder\"]/div/div/div[1]/button[1]")
    public WebElement  SaveDescriptionLink;
    @FindBy(how = How.XPATH, using = "//*[text() = 'OK']")
    public WebElement  OkDescriptionLink;

    @FindBy(how = How.XPATH, using = "//*[@id=\"userreportsFacetedSearchInner\"]/div/div/div[1]/div/div/div[4]/div[2]/div[2]/label/input")
    public WebElement  SeePublicReportsLink;


    @FindBy(how = How.XPATH, using = "//*[@id=\"userreportsFacetedSearchInner\"]/div/div/div[1]/div/div/div[3]/div/input")
    public WebElement  SearchButtonLink;
    @FindBy(how = How.XPATH, using = "//*[@id=\"searchButton\"]")
    public WebElement  SearchbuttonLink;

    @FindBy(how = How.XPATH, using = "//*[text() = 'Details']")
    public WebElement  PublicReportsDetailsLink;

    public Report(WebDriver driver) {
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        actions = new Actions(driver);
        PageFactory.initElements(driver, this);
    }

    public void ClickReport() {
        try {

        actions.click(ReportsLink).build().perform();
            Thread.sleep(2000);
            businessBankingHelper.takeSnapShot("createnewReport");
        actions.click(CreateReportLink).build().perform();
            Thread.sleep(2000);

        actions.click(DataAssetsLink).build().perform();
            businessBankingHelper.takeSnapShot("DatasetAndDataElements");

        actions.doubleClick(DataElementLink).perform();

            Thread.sleep(5000);

        actions.click(FiltersLink).build().perform();
            Thread.sleep(2000);

        actions.doubleClick(DataSetsLink).perform();
            Thread.sleep(2000);

        actions.click(DotsLink).build().perform();
            Thread.sleep(2000);

        actions.click(GeneralInformationLink).build().perform();
            Thread.sleep(2000);

        actions.click(SelectLink).build().perform();
            Thread.sleep(2000);

        actions.click(EnableAsInputArgumentLink).build().perform();
            Thread.sleep(2000);
            businessBankingHelper.takeSnapShot("enableimputargumentsondataset");
        actions.click(OkLink).build().perform();
            Thread.sleep(2000);

        actions.click(SaveLink).build().perform();
            Thread.sleep(2000);

        actions.click(ReportNameTextboxLink).build().perform();
            Thread.sleep(2000);
        actions.sendKeys(ReportNameTextboxLink,"2Report").build().perform();
            Thread.sleep(2300);

            actions.click(SaveLink).build().perform();

        actions.click(PublicReportLink).build().perform();
            Thread.sleep(3000);
            businessBankingHelper.takeSnapShot("namereport");
        actions.click(FinalOKLink).build().perform();
            Thread.sleep(3000);

        actions.click(ReportsLink).build().perform();
            Thread.sleep(8000);

            // Check to view private report
            actions.sendKeys(SearchButtonLink,"Test Private Report").build().perform();
            Thread.sleep(2000);
            businessBankingHelper.takeSnapShot("SearchReport");
            actions.click(SearchbuttonLink).build().perform();
            Thread.sleep(7000);


        actions.click(ChoosereportLink).build().perform();
            Thread.sleep(2000);
       businessBankingHelper.takeSnapShot("editreport");
        actions.click(EditReportLink).build().perform();
            Thread.sleep(4000);


            actions.click(DropDown).build().perform();
            Thread.sleep(3000);
            actions.click(SubType).build().perform();
            businessBankingHelper.takeSnapShot("SaveToEdit");
            Thread.sleep(3000);
            actions.click(TechGroup).build().perform();
            businessBankingHelper.takeSnapShot("AddTechGroup");
            Thread.sleep(3000);

            actions.doubleClick(SaveEditEmailLink).build().perform();
            Thread.sleep(3000);
            businessBankingHelper.takeSnapShot("OKEdit");
            actions.doubleClick(OOKLink).build().perform();

            actions.click(ReportsLink).build().perform();
            Thread.sleep(2000);
            actions.click(SeePublicReportsLink).build().perform();
            Thread.sleep(3000);
            businessBankingHelper.takeSnapShot("ViewShareReports");

            actions.sendKeys(SearchButtonLink,"All Registered Users").build().perform();
            Thread.sleep(2000);
            businessBankingHelper.takeSnapShot("SearchReport");
            actions.click(SearchbuttonLink).build().perform();
            Thread.sleep(3000);

            actions.click(ChoosereportLink).build().perform();
            Thread.sleep(2000);
            businessBankingHelper.takeSnapShot("SelectreportandViewDetails");
            actions.click(PublicReportsDetailsLink).build().perform();
            Thread.sleep(2000);
            businessBankingHelper.takeSnapShot("PublicReportDetails");


//              View Public report


        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}













