package objects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import cm_utils.BusinessBankingHelper;

public class Importsandfeeds {

    public WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    Actions actions;

    @FindBy(how = How.XPATH, using = "//*[text() = 'Import Monitor']")
    public WebElement ImportMonitorLink;
    @FindBy(how = How.XPATH, using = "//*[@id=\"monitor-panel\"]/div/div/div[1]/div/div/div[3]/div[2]/div[1]/label/input")
    public WebElement UntickLastdayrunLink;
    @FindBy(how = How.XPATH, using = "//*[@id=\"monitor-panel\"]/div/div/div[1]/div/div/div[4]/div[1]/div")
    public WebElement ClickMyfeedsLink;
    @FindBy(how = How.XPATH, using = "/html/body/div[1]/section/div/div[3]/div/div/div/div/div/div/div/div/div[2]/div/div/div[1]/div/div/div[4]/div[2]/div[1]/label/input")
    public WebElement FeedsihaverunLink;
    @FindBy(how = How.XPATH, using = "//*[@id=\"monitor-panel\"]/div/div/div[2]/div[3]/div[1]/div/div/div[1]/div/div/div[2]/div[2]/div/div[41]/span/a")
    public WebElement TestfeedLink;
    @FindBy(how = How.XPATH, using = "/html/body/div[2]/div/div/div[2]/div/div[3]/div/div/div/div[2]/div[2]/div/button")
    public WebElement RunLiink;
    @FindBy(how = How.XPATH, using = "//*[text() = 'Import Monitor']")
    public WebElement BacktoImportMonitorLink;
    @FindBy(how = How.XPATH, using = "//*[@id=\"feeds\"]")
    public WebElement FeedsLink;
    @FindBy(how = How.XPATH, using = "//*[@id=\"feeds-panel\"]/div/div[1]/div[1]/button")
    public WebElement AddnewLink;
    @FindBy(how = How.XPATH, using = "/html/body/div[2]/div/div/div[2]/div[1]/div[2]/ul/li[40]/div")
    public WebElement ExcelLink;
    @FindBy(how = How.XPATH, using = "//*[text() = 'Next >>']")
    public WebElement NextLink;

    @FindBy(how = How.XPATH, using = "/html/body/div[2]/div/div/div[2]/div[2]/div[3]/ul/li[16]/div/img")
    public WebElement StandardExcelImportLink;
    @FindBy(how = How.XPATH, using = "//*[text() = 'Next >>']")
    public WebElement StandardNextLink;

    @FindBy(how = How.XPATH, using = "/html/body/div[2]/div/div/div[2]/div[3]/div[3]/div[1]/div/input")
    public WebElement GiveFeedNameLink;
    @FindBy(how = How.XPATH, using = "/html/body/div[2]/div/div/div[3]/div/button[2]")
    public WebElement FinishLink;
    @FindBy(how = How.XPATH, using = "/html/body/div[1]/section/div/div[3]/div/div/div/div/div/div/div/div/div[2]/div/div/div[1]/div/div/div[3]/div[2]/div[3]/label/input")
    public WebElement Last30daysLink;
    @FindBy(how = How.XPATH, using = "//*[text() = 'DembeTestFeed']")
    public WebElement NewFeddDembe30Link;

    @FindBy(how = How.XPATH, using = "//*[text() = 'Details']")
    public WebElement DetailsNewfeedLink;
    @FindBy(how = How.XPATH, using = "//*[@id=\"runImportButton\"]")
    public WebElement DiscardandRerunLink;
    @FindBy(how = How.XPATH, using = "//*[text() = 'Submit']")
    public WebElement SubmitbuttonLink;
    @FindBy(how = How.XPATH, using = "//*[text() = 'OK']")
    public WebElement SubmitOkLink;
    @FindBy(how = How.XPATH, using = "//*[text() = 'Approve']")
    public WebElement ApproveLink;
    @FindBy(how = How.XPATH, using = "//*[text() = 'OK']")
    public WebElement ApproveOkLink;
    @FindBy(how = How.XPATH, using = "//*[text() = 'Run']")
    public WebElement RunLink;
    @FindBy(how = How.XPATH, using = "//*[text() = 'Discard']")
    public WebElement DiscardLink;

    @FindBy(how = How.XPATH, using = "/html/body/div[2]/div/div/div[2]/div/div/footer/div/button[1]")
    public WebElement OkDiscard;
    @FindBy(how = How.XPATH, using = "//*[text() = 'Withdraw']")
    public WebElement WithdrawLink;
    @FindBy(how = How.XPATH, using = "//*[text() = 'OK']")
    public WebElement OkWithdrawLink;
    @FindBy(how = How.XPATH, using = "/html/body/div[2]/div/div/div[3]/div/button[1]")
    public WebElement YestToDiscardandRunLink;
    @FindBy(how = How.XPATH, using = "//*[text() = 'Details']")
    public WebElement Newfeed16Details;

    public Importsandfeeds(WebDriver driver) {
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        actions = new Actions(driver);
        PageFactory.initElements(driver, this);

    }

    public void ClickImportMonitor() {
        try {

        actions.click(ImportMonitorLink).build().perform();
            Thread.sleep(5000);
            businessBankingHelper.takeSnapShot("UntickLastdayrunLink");
        actions.click(UntickLastdayrunLink).build().perform();
            Thread.sleep(2000);

        actions.click(ClickMyfeedsLink).build().perform();
            Thread.sleep(1000);

        actions.click(FeedsihaverunLink).build().perform();
            Thread.sleep(3000);

        actions.click(TestfeedLink).build().perform();
            Thread.sleep(2000);
            businessBankingHelper.takeSnapShot("RunChosenFeed");
        actions.click(RunLiink).build().perform();
            Thread.sleep(1000);
            actions.click(YestToDiscardandRunLink).build().perform();
            Thread.sleep(60000);
        actions.click(BacktoImportMonitorLink).build().perform();
            Thread.sleep(2000);
        actions.click(FeedsLink).build().perform();
            Thread.sleep(2000);
            businessBankingHelper.takeSnapShot("AddnewFeed");
        actions.click(AddnewLink).build().perform();
            Thread.sleep(2000);
        actions.click(ExcelLink).build().perform();
            businessBankingHelper.takeSnapShot("SelectExcelAndNext");
        actions.click(NextLink).build().perform();
            Thread.sleep(2000);
        actions.click(StandardExcelImportLink).build().perform();
            Thread.sleep(2000);
            businessBankingHelper.takeSnapShot("SelectStandardExcelImportAndNext");
        actions.click(StandardNextLink).build().perform();
            Thread.sleep(2000);

        actions.click(GiveFeedNameLink).build().perform();
        actions.sendKeys(GiveFeedNameLink,"TestFeeed").build().perform();
            Thread.sleep(2000);
            businessBankingHelper.takeSnapShot("NameYourReport");
        actions.click(FinishLink).build().perform();
            Thread.sleep(10000);

        actions.click(ImportMonitorLink).build().perform();
            Thread.sleep(2000);
        actions.click(Last30daysLink).build().perform();
            Thread.sleep(2000);
        actions.click(NewFeddDembe30Link).build().perform();
            Thread.sleep(2000);
            businessBankingHelper.takeSnapShot("ChooseFeedAndDetails");
            actions.click(DetailsNewfeedLink).build().perform();
            Thread.sleep(8000);
        actions.click(SubmitbuttonLink).build().perform();
            Thread.sleep(1000);
            businessBankingHelper.takeSnapShot("SubmitFeedAndOK");
        actions.click(SubmitOkLink).build().perform();
            Thread.sleep(3000);
            businessBankingHelper.takeSnapShot("WithdrawFeedAndOK");
        actions.click(WithdrawLink).build().perform();
            Thread.sleep(3000);
        actions.click(OkWithdrawLink).build().perform();
            Thread.sleep(3000);
            businessBankingHelper.takeSnapShot("SubmitButtonAndOK");
        actions.click(SubmitbuttonLink).build().perform();
            Thread.sleep(1000);
        actions.click(SubmitOkLink).build().perform();
            Thread.sleep(3000);
            businessBankingHelper.takeSnapShot("ApproveButtonAndOK");
        actions.click(ApproveLink).build().perform();
            Thread.sleep(1000);
        actions.click(ApproveOkLink).build().perform();
            Thread.sleep(3000);
            businessBankingHelper.takeSnapShot("RunFeed");
        actions.click(RunLink).build().perform();
            Thread.sleep(60000);
            businessBankingHelper.takeSnapShot("DiscardAndOK");
        actions.click(DiscardLink).build().perform();
            Thread.sleep(1000);
        actions.click(OkDiscard).build().perform();
            Thread.sleep(10000);
            businessBankingHelper.takeSnapShot("RunFeed");
        actions.click(RunLink).build().perform();
            Thread.sleep(60000);
            businessBankingHelper.takeSnapShot("DiscardandRerunFeed");
        actions.click(DiscardandRerunLink).build().perform();
            Thread.sleep(1000);
            businessBankingHelper.takeSnapShot("YesToDiscardandRerunFeed");
        actions.click(YestToDiscardandRunLink).build().perform();
            Thread.sleep(20000);
            businessBankingHelper.takeSnapShot("Feeddiscarded");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


}
