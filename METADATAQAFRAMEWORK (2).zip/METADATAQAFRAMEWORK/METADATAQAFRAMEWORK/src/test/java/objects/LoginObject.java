package objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LoginObject {
    public final WebDriver driver;

    BusinessBankingHelper businessBankingHelper;
    Actions actions;


    @FindBy(how = How.ID, using = "loginUsername")
    public WebElement usernameLabel;

    @FindBy(how = How.ID, using = "loginPassword")
    public WebElement loginPassword;

    @FindBy(how = How.ID, using = "loginOK")
    public WebElement loginOK;

//    @FindBy(how = How.XPATH, using = "//*[@id=\"abDropdownAnchor\"]")
//    public WebElement abDropdownAnchor;


    public LoginObject(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(this.driver);
        actions = new Actions(driver);
        PageFactory.initElements(driver, this);
    }

    public void login(String username, String password){
        try {
            usernameLabel.clear();
            usernameLabel.sendKeys(username);
            loginPassword.clear();
            loginPassword.sendKeys(password);
            businessBankingHelper.takeSnapShot("LoginAccess");
            loginOK.click();


        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

}
