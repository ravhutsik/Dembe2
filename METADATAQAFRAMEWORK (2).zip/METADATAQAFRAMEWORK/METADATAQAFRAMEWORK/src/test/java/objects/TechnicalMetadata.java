package objects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import cm_utils.BusinessBankingHelper;

public class TechnicalMetadata {

    public WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    Actions actions;


    @FindBy(how = How.XPATH, using = "//*[text() = 'Technical Metadata']")
    public WebElement TechnicalMetadataLink;

    @FindBy(how = How.XPATH, using = "//*[text() = 'Data Asset Catalogue']")
    public WebElement DataAssetCatalogueLink;

    @FindBy(how = How.XPATH, using = "//*[@id=\"grid\"]/div[3]/table/tbody/tr[1]/td[1]/div[1]/span/a")
    public WebElement BA300Report;
    @FindBy(how = How.XPATH, using = "//*[text() = 'Details']")
    public WebElement DatasetDetailsLink;


    @FindBy(how = How.XPATH, using = "//*[text() = 'Data Elements']")
    public WebElement DataElementsLink;
    @FindBy(how = How.XPATH, using = "/html/body/div[1]/section/div/div[3]/div/div/div/div/div/div/div[2]/div/div/div[2]/div/div/div/div[2]/div[3]/div[3]/table/tbody/tr[1]/td[1]/div[1]/span/a")
    public WebElement NDM110B_DISCOUNT_CODE;
    @FindBy(how = How.XPATH, using = "//*[text() = 'Details']")
    public WebElement DataElementsDetailsLink;

    @FindBy(how = How.XPATH, using = "//*[text() = 'Executables']")
    public WebElement ExecutableLink;
    @FindBy(how = How.XPATH, using = "//*[@id=\"grid\"]/div[3]/table/tbody/tr[2]/td[1]/div[1]/span/a")
    public WebElement ExecutablesaiblkLink;
    @FindBy(how = How.XPATH, using = "//*[text() = 'Details']")
    public WebElement ExecutableDetailsLink;

    @FindBy(how = How.XPATH, using = "//*[text() = 'Tasks']")
    public WebElement TasksLink;
    @FindBy(how = How.XPATH, using = "//*[@id=\"grid\"]/div[3]/table/tbody/tr[1]/td[1]/div[1]/span/a")
    public WebElement AccountsLink;
    @FindBy(how = How.XPATH, using = "//*[text() = 'Details']")
    public WebElement TasksDetailsLink;

    @FindBy(how = How.XPATH, using = "//*[text() = 'IT Applications']")
    public WebElement ITApplicationsLink;
    @FindBy(how = How.XPATH, using = "//*[@id=\"grid\"]/div[3]/table/tbody/tr[1]/td[1]/div[1]/span/a")
    public WebElement ITApplicationsSASLink;
    @FindBy(how = How.XPATH, using = "//*[text() = 'Details']")
    public WebElement ITApplicationsDetailsLink;

    @FindBy(how = How.XPATH, using = "//*[@id=\"systems\"]")
    public WebElement ITSystemLink;
    @FindBy(how = How.XPATH, using = "//*[@id=\"grid\"]/div[3]/table/tbody/tr[1]/td/div[1]/span/a")
    public WebElement SASLink;
    @FindBy(how = How.XPATH, using = "//*[text() = 'Details']")
    public WebElement ITSystemDetailsLink;

    @FindBy(how = How.XPATH, using = "//*[text() = 'Repositories']")
    public WebElement ChosenRepositoryLink;
    @FindBy(how = How.XPATH, using = "//*[@id=\"grid\"]/div[3]/table/tbody/tr[1]/td/div[1]/span/a")
    public WebElement DIXSystemLink;
    @FindBy(how = How.XPATH, using = "//*[text() = 'Details']")
    public WebElement RepositoryDetailsLink;

    @FindBy(how = How.XPATH, using = "/html/body/div[1]/section/div/div[3]/div/div/div/div/div/div/div[2]/div/div/div[1]/ul/li[8]/a/span/span")
    public WebElement SchemasAndDirectoriesLink;
    @FindBy(how = How.XPATH, using = "//*[@id=\"grid\"]/div[3]/table/tbody/tr[3]/td[1]/div[1]/span/a")
    public WebElement SchemasAndDirectoriescustomLink;
    @FindBy(how = How.XPATH, using = "//*[text() = 'Details']")
    public WebElement SchemasAndDirectoriesDetailsLink;

    @FindBy(how = How.XPATH, using = "/html/body/div[2]/div/div[2]/div/div[3]/div/div/div/div[3]/div/a/span/span")
    public WebElement LeniagePrinterLink;

    @FindBy(how = How.XPATH, using = "/html/body/div[1]/section/div/div[3]/div/div/div/div/div[2]/div/div/div/div/div[1]/div/div/div[1]/div[3]/div[1]/button[1]")
    public WebElement PrintButtonLink;

    @FindBy(how = How.XPATH, using = "//*[text() = 'Save as PDF']")
    public WebElement SaveAsPDFLink;

    @FindBy(how = How.XPATH, using = "//*[@id=\"divSearchSettingsRoot\"]/div/div/div[2]/div/input")
    public WebElement SearchButtonLink;

    @FindBy(how = How.XPATH, using = "//*[@id=\"searchButton\"]")
    public WebElement SearchbuttonLink;

    public TechnicalMetadata(WebDriver driver) {
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        actions = new Actions(driver);
        PageFactory.initElements(driver, this);

    }

    public void DataAssetDetails() {
        try {

            actions.click(TechnicalMetadataLink).build().perform();
            actions.click(DataAssetCatalogueLink).build().perform();
            Thread.sleep(3000);

            actions.sendKeys(SearchButtonLink,"sapbpc_bsm_audittrail_master_m").build().perform();
            Thread.sleep(1000);
            actions.click(SearchbuttonLink).build().perform();
            Thread.sleep(5000);

            actions.click(NDM110B_DISCOUNT_CODE).build().perform();
            Thread.sleep(5000);
            actions.click(DataElementsDetailsLink).build().perform();
            Thread.sleep(25000);
            businessBankingHelper.takeSnapShot("DataElementsDetails");
            actions.click(TechnicalMetadataLink).build().perform();
            actions.click(DataAssetCatalogueLink).build().perform();
            Thread.sleep(5000);

        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
    public void clickDataElements() {
        try {

            actions.click(TechnicalMetadataLink).build().perform();
            actions.click(DataAssetCatalogueLink).build().perform();
            Thread.sleep(3000);

            actions.click(DataElementsLink).build().perform();
            actions.sendKeys(SearchButtonLink,"NDM110B_DISCOUNT_CODE").build().perform();
            Thread.sleep(1000);
            actions.click(SearchbuttonLink).build().perform();
            Thread.sleep(4000);

            actions.click(NDM110B_DISCOUNT_CODE).build().perform();
            Thread.sleep(2000);

            actions.click(DataElementsDetailsLink).build().perform();
            Thread.sleep(10000);
            businessBankingHelper.takeSnapShot("DataElementsDetails");
            actions.click(TechnicalMetadataLink).build().perform();
            actions.click(DataAssetCatalogueLink).build().perform();
            Thread.sleep(5000);

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
            public void clickExecutable() {
        try {

            actions.click(ExecutableLink).build().perform();

            actions.sendKeys(SearchButtonLink,"SAS").build().perform();
            Thread.sleep(3000);
            actions.click(SearchbuttonLink).build().perform();
            Thread.sleep(7000);

            actions.click(ExecutablesaiblkLink).build().perform();
            Thread.sleep(2000);
            actions.click(ExecutableDetailsLink).build().perform();
            Thread.sleep(10000);
            businessBankingHelper.takeSnapShot("ExecutablesDetails");
            actions.click(TechnicalMetadataLink).build().perform();
            actions.click(DataAssetCatalogueLink).build().perform();
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void clickTasks() {
        try {

            actions.click(TasksLink).build().perform();
            Thread.sleep(5000);

            actions.sendKeys(SearchButtonLink,"Accounts").build().perform();
            Thread.sleep(3000);
            actions.click(SearchbuttonLink).build().perform();
            Thread.sleep(7000);

            actions.click(AccountsLink).build().perform();
            Thread.sleep(2000);

            actions.click(TasksDetailsLink).build().perform();
            Thread.sleep(10000);
            businessBankingHelper.takeSnapShot("TasksDetails");

            actions.click(TechnicalMetadataLink).build().perform();
            actions.click(DataAssetCatalogueLink).build().perform();
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void clickITApplications() {
        try {

            actions.click(ITApplicationsLink).build().perform();
            Thread.sleep(5000);

            actions.sendKeys(SearchButtonLink,"SAS").build().perform();
            Thread.sleep(3000);
            actions.click(SearchbuttonLink).build().perform();
            Thread.sleep(7000);

            actions.click(ITApplicationsSASLink).build().perform();
            Thread.sleep(2000);
            actions.click(ITApplicationsDetailsLink).build().perform();
            Thread.sleep(10000);
            businessBankingHelper.takeSnapShot("ITApplicationDetails");
            actions.click(TechnicalMetadataLink).build().perform();
            actions.click(DataAssetCatalogueLink).build().perform();
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void clickITSystem() {
        try {

            actions.click(ITSystemLink).build().perform();
            Thread.sleep(5000);

            actions.sendKeys(SearchButtonLink,"SAS").build().perform();
            Thread.sleep(3000);
            actions.click(SearchbuttonLink).build().perform();
            Thread.sleep(7000);

            actions.click(SASLink).build().perform();
            Thread.sleep(2000);
            actions.click(ITSystemDetailsLink).build().perform();
            Thread.sleep(10000);
            businessBankingHelper.takeSnapShot("ITSystemDetails");
            actions.click(TechnicalMetadataLink).build().perform();
            Thread.sleep(2000);
            actions.click(DataAssetCatalogueLink).build().perform();
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void clickRepositories() {
        try {

            actions.click(ChosenRepositoryLink).build().perform();
            Thread.sleep(5000);

            actions.sendKeys(SearchButtonLink,"DIX System").build().perform();
            Thread.sleep(3000);
            actions.click(SearchbuttonLink).build().perform();
            Thread.sleep(7000);

            actions.click(DIXSystemLink).build().perform();
            Thread.sleep(2000);
            actions.click(RepositoryDetailsLink).build().perform();
            Thread.sleep(10000);
            businessBankingHelper.takeSnapShot("RepositoriesDetails");
            actions.click(TechnicalMetadataLink).build().perform();
            actions.click(DataAssetCatalogueLink).build().perform();
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void clickSchemasAndDirectories() {
        try {

            actions.click(SchemasAndDirectoriesLink).build().perform();
            Thread.sleep(3000);

            actions.sendKeys(SearchButtonLink,"SAS").build().perform();
            Thread.sleep(3000);
            actions.click(SearchbuttonLink).build().perform();
            Thread.sleep(7000);

            actions.click(SchemasAndDirectoriescustomLink).build().perform();
            Thread.sleep(2000);
            actions.click(SchemasAndDirectoriesDetailsLink).build().perform();
            Thread.sleep(10000);
            businessBankingHelper.takeSnapShot("SchemasAndDirectoriesDetails");

            actions.click(TechnicalMetadataLink).build().perform();
            actions.click(DataAssetCatalogueLink).build().perform();
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void PrintDataElementLineage() {
        try {

            actions.click(TechnicalMetadataLink).build().perform();
            actions.click(DataAssetCatalogueLink).build().perform();
            Thread.sleep(3000);

            actions.click(DataElementsLink).build().perform();
            actions.sendKeys(SearchButtonLink,"NDM110B_DISCOUNT_CODE").build().perform();
            Thread.sleep(3000);
            actions.click(SearchbuttonLink).build().perform();
            Thread.sleep(7000);

            actions.click(NDM110B_DISCOUNT_CODE).build().perform();
            Thread.sleep(5000);
            actions.click(LeniagePrinterLink).build().perform();
            Thread.sleep(5000);
            businessBankingHelper.takeSnapShot("PrintReport");
            actions.click(PrintButtonLink).build().perform();
            Thread.sleep(5000);
            businessBankingHelper.takeSnapShot("SaveAsPDF");
            actions.click(SaveAsPDFLink).build().perform();

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void matricsanddimension() {
        try {
            Thread.sleep(5000);
            actions.click(TechnicalMetadataLink).build().perform();
            actions.click(DataAssetCatalogueLink).build().perform();
            Thread.sleep(5000);

            actions.click(DataElementsLink).build().perform();

            actions.sendKeys(SearchButtonLink,"Foreign Currency Mismatch").build().perform();
            Thread.sleep(3000);
            businessBankingHelper.takeSnapShot("InsertMetricsAndDimension");
            actions.click(SearchbuttonLink).build().perform();
            Thread.sleep(15000);
            businessBankingHelper.takeSnapShot("SearchMetricsAndDimension");

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}



