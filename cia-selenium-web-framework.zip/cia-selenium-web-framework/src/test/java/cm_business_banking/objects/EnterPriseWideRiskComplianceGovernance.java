package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class EnterPriseWideRiskComplianceGovernance {


    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String EnterprisewideRiskManagementLabel = "Enterprisewide Risk Management";
    final String ClusterRiskSupportServicesLabel = "Cluster Risk Support Services";
    final String ComplianceAndGovernanceLabel = "Compliance and Governance";
    
    final String OperationalRiskLabel = "Operational Risk";
    final String FInancialCrimeLabel = "FInancial Crime";
    final String AntiMoneyLaunderingLabel = "Anti Money Laundering";
    final String RegulatorNoticesLabel = "Regulator Notices";
    final String EnvironmentalSociaLandTransformationRiskLabel = "Environmental Social and Transformation Risk";
    final String BusinessAndStrategicRiskLabel = "Business and Strategic Risk";
    final String InformationTechnologyRiskLabel = "Information Technology Risk";
    final String PeopleRiskLabel = "People Risk";
    final String ReputationalRiskLabel = "Reputational Risk";
    final String CommunicationsLabel = "Communications";
    final String PRIVACYLabel = "PRIVACY";

    String [] OperationalRisk = {"Notice deposit cheatsheet","Investments Training Presentation","Investment client presentation"};
    String [] FInancialCrime  = {"Term deposit cheatsheet","Investments Training Presentation","Investment client presentation"};
    String [] AntiMoneyLaundering  = {"Call account cheatsheet","Investments Training Presentation","Investment client presentation"};

    public EnterPriseWideRiskComplianceGovernance(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getOperationalRisk() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(OperationalRiskLabel), OperationalRiskLabel);
        businessBankingHelper.performOperation(OperationalRisk);
    }

    public void getFInancialCrime() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(FInancialCrimeLabel), FInancialCrimeLabel);
        businessBankingHelper.performOperation(FInancialCrime);
    }

    public void getAntiMoneyLaundering() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(AntiMoneyLaunderingLabel), AntiMoneyLaunderingLabel);
        businessBankingHelper.performOperation(AntiMoneyLaundering);
    }

}
