package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PodcastsAndTestimonialVideos {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String howNedbanksHelpsNewBusinessesLabel = "How Nedbanks helps new businesses";
    final String consumerProtectionActAndTheImpactThereofLabel = "The Consumer Protection Act and the impact thereof";
    final String LuciaNonkweloBPFranchiseeLabel = "Lucia Nonkwelo - BP franchisee";
    final String NedbankFranchisingKrispyKremeLabel = "Nedbank Franchising - Krispy Kreme";
    final String NedbankFranchisingSalesToolLabel = "Nedbank Franchising - Sales Tool";
    final String FranchisingVideoDaleneRoweLabel = "Franchising Video - Dalene Rowe";
    final String FranchisingVideoMarkRoseLabel = "Franchising Video - Mark Rose";
    final String NedbankFranchisingNareshBabuLabel = "Nedbank Franchising - Naresh Babu";
    final String NedbankFranchisingSachaDuPlessisLabel = "Nedbank Franchising - Sacha Du Plessis";
    final String NedbankFranchisingEngenLabel = "Nedbank Franchising - Engen";
    final String entrepreneursShouldAttendNedbankSeminarsLabel = "Why entrepreneurs should attend Nedbank Seminars";

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ howNedbanksHelpsNewBusinessesLabel +"']")
    public WebElement howNedbanksHelpsNewBusinesses;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ consumerProtectionActAndTheImpactThereofLabel +"']")
    public WebElement consumerProtectionActAndTheImpactThereof;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ LuciaNonkweloBPFranchiseeLabel +"']")
    public WebElement LuciaNonkweloBPFranchisee;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ NedbankFranchisingKrispyKremeLabel +"']")
    public WebElement NedbankFranchisingKrispyKreme;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ NedbankFranchisingSalesToolLabel +"']")
    public WebElement NedbankFranchisingSalesTool;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ FranchisingVideoDaleneRoweLabel +"']")
    public WebElement FranchisingVideoDaleneRowe;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ FranchisingVideoMarkRoseLabel +"']")
    public WebElement FranchisingVideoMarkRose;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ NedbankFranchisingNareshBabuLabel +"']")
    public WebElement NedbankFranchisingNareshBabu;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ NedbankFranchisingSachaDuPlessisLabel +"']")
    public WebElement NedbankFranchisingSachaDuPlessis;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ NedbankFranchisingEngenLabel +"']")
    public WebElement NedbankFranchisingEngen;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ entrepreneursShouldAttendNedbankSeminarsLabel +"']")
    public WebElement entrepreneursShouldAttendNedbankSeminars;

    public PodcastsAndTestimonialVideos(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getHowNedbanksHelpsNewBusinesses() {
        businessBankingHelper.verifyAndClickElement(howNedbanksHelpsNewBusinesses, howNedbanksHelpsNewBusinessesLabel);
    }
    public void verifyHowNedbanksHelpsNewBusinesses()  {
        businessBankingHelper.verifyPage(howNedbanksHelpsNewBusinessesLabel, howNedbanksHelpsNewBusinesses);
        businessBankingHelper.takeSnapShot(howNedbanksHelpsNewBusinessesLabel +" Page");
    }
    public void getConsumerProtectionActAndTheImpactThereof() {
        businessBankingHelper.verifyAndClickElement(consumerProtectionActAndTheImpactThereof, consumerProtectionActAndTheImpactThereofLabel);
    }
    public void verifyConsumerProtectionActAndTheImpactThereof()  {
        businessBankingHelper.verifyPage(consumerProtectionActAndTheImpactThereofLabel, consumerProtectionActAndTheImpactThereof);
        businessBankingHelper.takeSnapShot(consumerProtectionActAndTheImpactThereofLabel +" Page");
    }
    public void getLuciaNonkweloBPFranchisee() {
        businessBankingHelper.verifyAndClickElement( LuciaNonkweloBPFranchisee, LuciaNonkweloBPFranchiseeLabel);
    }
    public void verifyLuciaNonkweloBPFranchisee()  {
        businessBankingHelper.verifyPage(LuciaNonkweloBPFranchiseeLabel, LuciaNonkweloBPFranchisee);
        businessBankingHelper.takeSnapShot(LuciaNonkweloBPFranchiseeLabel +" Page");
    }
    public void getNedbankFranchisingKrispyKreme() {
        businessBankingHelper.verifyAndClickElement(NedbankFranchisingKrispyKreme, NedbankFranchisingKrispyKremeLabel);
    }
    public void verifyNedbankFranchisingKrispyKreme()  {
        businessBankingHelper.verifyPage(NedbankFranchisingKrispyKremeLabel, NedbankFranchisingKrispyKreme);
        businessBankingHelper.takeSnapShot(NedbankFranchisingKrispyKremeLabel +" Page");
    }
    public void getNedbankFranchisingSalesTool() {
        businessBankingHelper.verifyAndClickElement( NedbankFranchisingSalesTool, NedbankFranchisingSalesToolLabel);
    }
    public void verifyNedbankFranchisingSalesTool()  {
        businessBankingHelper.verifyPage(NedbankFranchisingSalesToolLabel, NedbankFranchisingSalesTool);
        businessBankingHelper.takeSnapShot(NedbankFranchisingSalesToolLabel +" Page");
    }
    public void getTigerFranchisingVideoDaleneRowe() {
        businessBankingHelper.verifyAndClickElement(FranchisingVideoDaleneRowe, FranchisingVideoDaleneRoweLabel);
    }
    public void verifyFranchisingVideoDaleneRowe()  {
        businessBankingHelper.verifyPage(FranchisingVideoDaleneRoweLabel, FranchisingVideoDaleneRowe);
        businessBankingHelper.takeSnapShot(FranchisingVideoDaleneRoweLabel +" Page");
    }
    public void getFranchisingVideoMarkRose() {
        businessBankingHelper.verifyAndClickElement( FranchisingVideoMarkRose, FranchisingVideoMarkRoseLabel);
    }
    public void verifyFranchisingVideoMarkRose()  {
        businessBankingHelper.verifyPage(FranchisingVideoMarkRoseLabel, FranchisingVideoMarkRose);
        businessBankingHelper.takeSnapShot(FranchisingVideoMarkRoseLabel +" Page");
    }
    public void getNedbankFranchisingNareshBabu() {
        businessBankingHelper.verifyAndClickElement(NedbankFranchisingNareshBabu, NedbankFranchisingNareshBabuLabel);
    }
    public void verifyNedbankFranchisingNareshBabu()  {
        businessBankingHelper.verifyPage(NedbankFranchisingNareshBabuLabel, NedbankFranchisingNareshBabu);
        businessBankingHelper.takeSnapShot(NedbankFranchisingNareshBabuLabel +" Page");
    }
    public void getNedbankFranchisingSachaDuPlessis() {
        businessBankingHelper.verifyAndClickElement(NedbankFranchisingSachaDuPlessis, NedbankFranchisingSachaDuPlessisLabel);
    }
    public void verifyNedbankFranchisingSachaDuPlessis()  {
        businessBankingHelper.verifyPage(NedbankFranchisingSachaDuPlessisLabel, NedbankFranchisingSachaDuPlessis);
        businessBankingHelper.takeSnapShot(NedbankFranchisingSachaDuPlessisLabel +" Page");
    }
    public void getNedbankFranchisingEngen() {
        businessBankingHelper.verifyAndClickElement(NedbankFranchisingEngen, NedbankFranchisingEngenLabel);
    }
    public void verifyNedbankFranchisingEngen()  {
        businessBankingHelper.verifyPage(NedbankFranchisingEngenLabel, NedbankFranchisingEngen);
        businessBankingHelper.takeSnapShot(NedbankFranchisingEngenLabel +" Page");
    }
    public void getEntrepreneursShouldAttendNedbankSeminars() {
        businessBankingHelper.verifyAndClickElement(entrepreneursShouldAttendNedbankSeminars, entrepreneursShouldAttendNedbankSeminarsLabel);
    }
    public void verifyEntrepreneursShouldAttendNedbankSeminars()  {
        businessBankingHelper.verifyPage(entrepreneursShouldAttendNedbankSeminarsLabel, entrepreneursShouldAttendNedbankSeminars);
        businessBankingHelper.takeSnapShot(entrepreneursShouldAttendNedbankSeminarsLabel +" Page");
    }


}
