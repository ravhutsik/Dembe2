package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class FrameworkAndCharters {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String badDebtWriteOffImpairmentCommitteeCharterLabel = "Bad Debt Write-off & Impairment Committee Charter";
    final String BUCCCharterLabel = "BUCC CHARTER";
    final String buscramCharterLabel = "BUSCRAM CHARTER";
    final String creditRiskFrameworkLabel = "CREDIT RISK FRAMEWORK";
    final String CPPCCharterLabel = "CPPC Charter";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ badDebtWriteOffImpairmentCommitteeCharterLabel +"']")
    public WebElement badDebtWriteOffImpairmentCommitteeCharter;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BUCCCharterLabel +"']")
    public WebElement BUCCCharter;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ buscramCharterLabel +"']")
    public WebElement buscramCharter;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ creditRiskFrameworkLabel +"']")
    public WebElement creditRiskFramework;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ CPPCCharterLabel +"']")
    public WebElement CPPCCharter;

    public FrameworkAndCharters(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getBadDebtWriteOffImpairmentCommitteeCharter() {
        businessBankingHelper.verifyAndClickElement( badDebtWriteOffImpairmentCommitteeCharter, badDebtWriteOffImpairmentCommitteeCharterLabel);
    }
    public void verifyBadDebtWriteOffImpairmentCommitteeCharter()  {
        businessBankingHelper.verifyPage(badDebtWriteOffImpairmentCommitteeCharterLabel, badDebtWriteOffImpairmentCommitteeCharter);
        businessBankingHelper.takeSnapShot(badDebtWriteOffImpairmentCommitteeCharterLabel +" Page");
    }
    public void getBUCCCharter() {
        businessBankingHelper.verifyAndClickElement( BUCCCharter, BUCCCharterLabel);
    }
    public void verifyBUCCCharter()  {
        businessBankingHelper.verifyPage(BUCCCharterLabel, BUCCCharter);
        businessBankingHelper.takeSnapShot(BUCCCharterLabel +" Page");
    }
    public void getBuscramCharter() {
        businessBankingHelper.verifyAndClickElement( buscramCharter, buscramCharterLabel);
    }
    public void verifyBuscramCharter()  {
        businessBankingHelper.verifyPage(buscramCharterLabel, buscramCharter);
        businessBankingHelper.takeSnapShot(buscramCharterLabel+" Page");
    }
    public void getCreditRiskFramework() {
        businessBankingHelper.verifyAndClickElement( creditRiskFramework, creditRiskFrameworkLabel);
    }
    public void verifyCreditRiskFramework()  {
        businessBankingHelper.verifyPage(creditRiskFrameworkLabel, creditRiskFramework);
        businessBankingHelper.takeSnapShot(creditRiskFrameworkLabel +" Page");
    }
    public void getCPPCCharter() {
        businessBankingHelper.verifyAndClickElement( CPPCCharter, CPPCCharterLabel);
    }
    public void verifyCPPCCharter()  {
        businessBankingHelper.verifyPage(CPPCCharterLabel, CPPCCharter);
        businessBankingHelper.takeSnapShot(CPPCCharterLabel +" Page");
    }
}
