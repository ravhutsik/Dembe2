package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class RecoveryCategory {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String recoverySheetLabel = "RECOVERIES TAKE ON SHEET";
    final String writeOffTemplateLabel = "Write-off Template";
    final String TNTestArticleLabel = "TN Test Article 2503";
    final String wholeViewBBEditorialLabel = "Whole-view Business Banking Afrikaans editorial";
    final String PBREngLawyerLabel = "Nedbank PRB ENG Lawyer Mix";
    final String boxerCampaignLabel = "Boxer Campaign";
    final String wholeViewDigitalBannerProductLabel = "Wholeview Digital banners – product";
    final String debtorManagementCampaignLabel = "Debtor Management Campaign radio advert";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ recoverySheetLabel +"']")
    public WebElement recoverySheet;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ writeOffTemplateLabel +"']")
    public WebElement writeOffTemplate;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ TNTestArticleLabel +"']")
    public WebElement TNTestArticle;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ wholeViewBBEditorialLabel +"']")
    public WebElement wholeViewBBEditorial;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ PBREngLawyerLabel +"']")
    public WebElement PBREngLawyer;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ boxerCampaignLabel +"']")
    public WebElement boxerCampaign;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ wholeViewDigitalBannerProductLabel +"']")
    public WebElement wholeViewDigitalBannerProduct;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ debtorManagementCampaignLabel +"']")
    public WebElement debtorManagementCampaign;


    public RecoveryCategory(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getRecoverySheet() {
        businessBankingHelper.verifyAndClickElement( recoverySheet, recoverySheetLabel);
    }
    public void verifyRecoverySheet() {
        businessBankingHelper.verifyPage(recoverySheetLabel, recoverySheet);
        businessBankingHelper.takeSnapShot(recoverySheetLabel+" Page");
    }


    public void getWriteOffTemplate() {
        businessBankingHelper.verifyAndClickElement( writeOffTemplate, writeOffTemplateLabel);
    }
    public void verifyWriteOffTemplate()  {
        businessBankingHelper.verifyPage(writeOffTemplateLabel, writeOffTemplate);
        businessBankingHelper.takeSnapShot(writeOffTemplateLabel+" Page");
    }

    public void getTNTestArticle() {
        businessBankingHelper.verifyAndClickElement( TNTestArticle, TNTestArticleLabel);
    }
    public void verifyTNTestArticle()  {
        businessBankingHelper.verifyPage(TNTestArticleLabel, TNTestArticle);
        businessBankingHelper.takeSnapShot(TNTestArticleLabel+" Page");
    }

    public void getWholeViewBBEditorial() {
        businessBankingHelper.verifyAndClickElement( wholeViewBBEditorial, wholeViewBBEditorialLabel);
    }
    public void verifyWholeViewBBEditorial()  {
        businessBankingHelper.verifyPage(wholeViewBBEditorialLabel, wholeViewBBEditorial);
        businessBankingHelper.takeSnapShot(wholeViewBBEditorialLabel+" Page");
    }
    public void getPBREngLawyer() {
        businessBankingHelper.verifyAndClickElement( PBREngLawyer, PBREngLawyerLabel);
    }
    public void verifyPBREngLawyer()  {
        businessBankingHelper.verifyPage(PBREngLawyerLabel, PBREngLawyer);
        businessBankingHelper.takeSnapShot(PBREngLawyerLabel+" Page");
    }
    public void getBoxerCampaign() {
        businessBankingHelper.verifyAndClickElement( boxerCampaign, boxerCampaignLabel);
    }
    public void verifyBoxerCampaign()  {
        businessBankingHelper.verifyPage(boxerCampaignLabel, boxerCampaign);
        businessBankingHelper.takeSnapShot(boxerCampaignLabel+" Page");
    }
    public void getWholeViewDigitalBannerProduct() {
        businessBankingHelper.verifyAndClickElement( wholeViewDigitalBannerProduct, wholeViewDigitalBannerProductLabel);
    }
    public void verifyWholeViewDigitalBannerProduct()  {
        businessBankingHelper.verifyPage(wholeViewDigitalBannerProductLabel, wholeViewDigitalBannerProduct);
        businessBankingHelper.takeSnapShot(wholeViewDigitalBannerProductLabel+" Page");
    }
    public void getDebtorManagementCampaign() {
        businessBankingHelper.verifyAndClickElement( debtorManagementCampaign, debtorManagementCampaignLabel);
    }
    public void verifyDebtorManagementCampaign()  {
        businessBankingHelper.verifyPage(debtorManagementCampaignLabel, debtorManagementCampaign);
        businessBankingHelper.takeSnapShot(debtorManagementCampaignLabel+" Page");
    }


}
