package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PolicyProcedures {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String businessBankingCreditPolicyUpdatesJuly2019Label = "BUSINESS BANKING CREDIT POLICY Updates: JULY 2019";
    final String businessBankingCreditPolicyUpdatesJune2019Label = "BUSINESS BANKING CREDIT POLICY Updates: JUNE 2019";
    final String april2019CreditPolicyChangesLabel = "APRIL 2019 CREDIT POLICY CHANGES";
    final String november2018CreditPolicyChangesLabel = "NOVEMBER 2018 CREDIT POLICY CHANGES";
    final String ratingModelPolicyChangesLabel = "RATING MODEL POLICY CHANGES";
    final String february2018CreditPolicyChangesLabel = "FEBRUARY 2018 CREDIT POLICY CHANGES";
    final String riskRestructureCreditPolicyChanges1Dec2018Label = "RISK RESTRUCTURE CREDIT POLICY CHANGES 1 Dec 2018";
    final String january2018CreditPolicyUpdatesLabel = "JANUARY 2018 CREDIT POLICY UPDATES";
    final String annualCreditPolicyReviewLabel = "2017 Annual Credit Policy Review";
    final String RBBIntegrationCreditPolicyChangesLabel = "RBB INTEGRATION CREDIT POLICY CHANGES";
    final String collateralManagementAndSecurityDocumentationLabel = "Collateral Management and Security Documentation";

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ businessBankingCreditPolicyUpdatesJuly2019Label +"']")
    public WebElement businessBankingCreditPolicyUpdatesJuly2019;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ businessBankingCreditPolicyUpdatesJune2019Label +"']")
    public WebElement businessBankingCreditPolicyUpdatesJune2019;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ april2019CreditPolicyChangesLabel +"']")
    public WebElement april2019CreditPolicyChanges;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ november2018CreditPolicyChangesLabel +"']")
    public WebElement november2018CreditPolicyChanges;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ ratingModelPolicyChangesLabel +"']")
    public WebElement ratingModelPolicyChanges;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ february2018CreditPolicyChangesLabel +"']")
    public WebElement february2018CreditPolicyChanges;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ riskRestructureCreditPolicyChanges1Dec2018Label +"']")
    public WebElement riskRestructureCreditPolicyChanges1Dec2018;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ january2018CreditPolicyUpdatesLabel +"']")
    public WebElement january2018CreditPolicyUpdates;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ annualCreditPolicyReviewLabel +"']")
    public WebElement annualCreditPolicyReview;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ RBBIntegrationCreditPolicyChangesLabel +"']")
    public WebElement RBBIntegrationCreditPolicyChanges;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ collateralManagementAndSecurityDocumentationLabel +"']")
    public WebElement collateralManagementAndSecurityDocumentation;

    public PolicyProcedures(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getBusinessBankingCreditPolicyUpdatesJuly2019() {
        businessBankingHelper.verifyAndClickElement( businessBankingCreditPolicyUpdatesJuly2019, businessBankingCreditPolicyUpdatesJuly2019Label);
    }
    public void verifyBusinessBankingCreditPolicyUpdatesJuly2019()  {
        businessBankingHelper.verifyPage(businessBankingCreditPolicyUpdatesJuly2019Label, businessBankingCreditPolicyUpdatesJuly2019);
        businessBankingHelper.takeSnapShot(businessBankingCreditPolicyUpdatesJuly2019Label+" Page");
    }

    public void getBusinessBankingCreditPolicyUpdatesJune2019() {
        businessBankingHelper.verifyAndClickElement( businessBankingCreditPolicyUpdatesJune2019, businessBankingCreditPolicyUpdatesJune2019Label);
    }
    public void verifyBusinessBankingCreditPolicyUpdatesJune2019()  {
        businessBankingHelper.verifyPage(businessBankingCreditPolicyUpdatesJune2019Label, businessBankingCreditPolicyUpdatesJune2019);
        businessBankingHelper.takeSnapShot(businessBankingCreditPolicyUpdatesJune2019Label+" Page");
    }

    public void getApril2019CreditPolicyChanges() {
        businessBankingHelper.verifyAndClickElement( april2019CreditPolicyChanges, april2019CreditPolicyChangesLabel);
    }
    public void verifyApril2019CreditPolicyChanges()  {
        businessBankingHelper.verifyPage(april2019CreditPolicyChangesLabel, april2019CreditPolicyChanges);
        businessBankingHelper.takeSnapShot(april2019CreditPolicyChangesLabel+" Page");
    }

    public void getNovember2018CreditPolicyChanges() {
        businessBankingHelper.verifyAndClickElement( november2018CreditPolicyChanges, november2018CreditPolicyChangesLabel);
    }
    public void verifyNovember2018CreditPolicyChanges()  {
        businessBankingHelper.verifyPage(november2018CreditPolicyChangesLabel, november2018CreditPolicyChanges);
        businessBankingHelper.takeSnapShot(november2018CreditPolicyChangesLabel+" Page");
    }

    public void getRatingModelPolicyChanges() {
        businessBankingHelper.verifyAndClickElement( ratingModelPolicyChanges, ratingModelPolicyChangesLabel);
    }
    public void verifyRatingModelPolicyChanges()  {
        businessBankingHelper.verifyPage(ratingModelPolicyChangesLabel, ratingModelPolicyChanges);
        businessBankingHelper.takeSnapShot(ratingModelPolicyChangesLabel+" Page");
    }

    public void getFebruary2018CreditPolicyChanges() {
        businessBankingHelper.verifyAndClickElement( february2018CreditPolicyChanges, february2018CreditPolicyChangesLabel);
    }
    public void verifyFebruary2018CreditPolicyChanges()  {
        businessBankingHelper.verifyPage(february2018CreditPolicyChangesLabel, february2018CreditPolicyChanges);
        businessBankingHelper.takeSnapShot(february2018CreditPolicyChangesLabel+" Page");
    }

    public void getRiskRestructureCreditPolicyChanges1Dec2018() {
        businessBankingHelper.verifyAndClickElement( riskRestructureCreditPolicyChanges1Dec2018, riskRestructureCreditPolicyChanges1Dec2018Label);
    }
    public void verifyRiskRestructureCreditPolicyChanges1Dec2018()  {
        businessBankingHelper.verifyPage(riskRestructureCreditPolicyChanges1Dec2018Label, riskRestructureCreditPolicyChanges1Dec2018);
        businessBankingHelper.takeSnapShot(riskRestructureCreditPolicyChanges1Dec2018Label+" Page");
    }

    public void getJanuary2018CreditPolicyUpdates() {
        businessBankingHelper.verifyAndClickElement( january2018CreditPolicyUpdates, january2018CreditPolicyUpdatesLabel);
    }
    public void verifyJanuary2018CreditPolicyUpdates()  {
        businessBankingHelper.verifyPage(january2018CreditPolicyUpdatesLabel, january2018CreditPolicyUpdates);
        businessBankingHelper.takeSnapShot(january2018CreditPolicyUpdatesLabel+" Page");
    }

    public void getAnnualCreditPolicyReview() {
        businessBankingHelper.verifyAndClickElement( annualCreditPolicyReview, annualCreditPolicyReviewLabel);
    }
    public void verifyAnnualCreditPolicyReview()  {
        businessBankingHelper.verifyPage(annualCreditPolicyReviewLabel, annualCreditPolicyReview);
        businessBankingHelper.takeSnapShot(annualCreditPolicyReviewLabel+" Page");
    }

    public void getRBBIntegrationCreditPolicyChanges() {
        businessBankingHelper.verifyAndClickElement( RBBIntegrationCreditPolicyChanges, RBBIntegrationCreditPolicyChangesLabel);
    }
    public void verifyRBBIntegrationCreditPolicyChanges()  {
        businessBankingHelper.verifyPage(RBBIntegrationCreditPolicyChangesLabel, RBBIntegrationCreditPolicyChanges);
        businessBankingHelper.takeSnapShot(RBBIntegrationCreditPolicyChangesLabel+" Page");
    }

    public void getCollateralManagementAndSecurityDocumentation() {
        businessBankingHelper.verifyAndClickElement(collateralManagementAndSecurityDocumentation, collateralManagementAndSecurityDocumentationLabel);
    }
    public void verifyCollateralManagementAndSecurityDocumentation()  {
        businessBankingHelper.verifyPage(collateralManagementAndSecurityDocumentationLabel, collateralManagementAndSecurityDocumentation);
        businessBankingHelper.takeSnapShot(collateralManagementAndSecurityDocumentationLabel + " Page");
    }

}
