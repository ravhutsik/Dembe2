package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import cm_utils.DriverFactory;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class DocumentLibrary {
    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;

    @FindBy(how = How.XPATH, using = "//*[@id=\"ArticlesDiv\"]")
    public WebElement docLibrary;

    public final String credit_Report_Templates_Label = "Credit Report Templates";
    public final String general_label = "General";
    public final String credit_Template_and_forms_label= "CREDIT TEMPLATES and FORMS";
    public final String recoveries_label = "Recoveries";
    public final String debtor_Management_Templates_label = "Debtor Management (NDM) Templates";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ credit_Report_Templates_Label +"']")
    public WebElement creditReportTemplates;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ general_label +"']")
    public WebElement general;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ credit_Template_and_forms_label +"']")
    public WebElement creditTemplatesAndForms;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ recoveries_label +"']")
    public WebElement recoveries;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ debtor_Management_Templates_label +"']")
    public WebElement debtorManagementTemplates;
    

        
    public DocumentLibrary(WebDriver driver) {
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getCreditReportTemplates() {
        businessBankingHelper.verifyAndClickElement(creditReportTemplates, credit_Report_Templates_Label);
    }

    public void getGeneral() {
        businessBankingHelper.verifyAndClickElement(general_label, general, general_label);
    }

    public void getCreditTemplatesAndForms() {
        businessBankingHelper.verifyAndClickElement(creditTemplatesAndForms, credit_Template_and_forms_label);
    }

    public void getRecoveries() {
        businessBankingHelper.verifyAndClickElement(recoveries_label, recoveries, recoveries_label);
    }

    public void getDebtorManagementTemplates() {
        businessBankingHelper.verifyAndClickElement(debtorManagementTemplates, debtor_Management_Templates_label);
    }


}
