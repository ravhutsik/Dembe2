package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Specialisation {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String publicSectorLabel = "Public Sector";
    final String enterpriseDevelopmentLabel = "Enterprise Development";
    final String franchisingLabel = "Franchising";
    final String agricultureLabel = "Agriculture";
    final String schoolsLabel = "Schools";
    final String professionalLabel = "Professional";
    final String sustainabilityLabel  = "Sustainability ";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ publicSectorLabel +"']")
    public WebElement publicSector;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ enterpriseDevelopmentLabel +"']")
    public WebElement enterpriseDevelopment;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ franchisingLabel +"']")
    public WebElement franchising;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ agricultureLabel +"']")
    public WebElement agriculture;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ schoolsLabel +"']")
    public WebElement schools;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ professionalLabel +"']")
    public WebElement professional;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ sustainabilityLabel +"']")
    public WebElement sustainability;

    public Specialisation(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getPublicSector() {
        businessBankingHelper.verifyAndClickElement( publicSector, publicSectorLabel);
    }

    public void getEnterpriseDevelopment() {
        businessBankingHelper.verifyAndClickElement( enterpriseDevelopment, enterpriseDevelopmentLabel);
    }

    public void getFranchising() {
        businessBankingHelper.verifyAndClickElement( franchising, franchisingLabel);
    }

    public void getAgriculture() {
        businessBankingHelper.verifyAndClickElement( agriculture, agricultureLabel);
    }

    public void getSchools() {
        businessBankingHelper.verifyAndClickElement( schools, schoolsLabel);
    }

    public void getProfessional() {
        businessBankingHelper.verifyAndClickElement( professional, professionalLabel);
    }
    public void getSustainability() {
        businessBankingHelper.verifyAndClickElement( sustainability, sustainabilityLabel);
    }

}
