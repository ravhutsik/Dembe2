package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class ClientExperience {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String strategyAndApproachLabel  = "Strategy and Approach ";
    final String clientStoriesLabel  = "Client Stories ";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ strategyAndApproachLabel +"']")
    public WebElement strategyAndApproach;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ clientStoriesLabel +"']")
    public WebElement clientStories;

    public ClientExperience(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getStrategyAndApproach() {
        businessBankingHelper.verifyAndClickElement( strategyAndApproach, strategyAndApproachLabel);
    }
    public void getClientStories() {
        businessBankingHelper.verifyAndClickElement( clientStories, clientStoriesLabel);
    }
}
