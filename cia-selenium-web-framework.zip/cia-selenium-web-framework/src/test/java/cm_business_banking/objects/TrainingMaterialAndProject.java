package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class TrainingMaterialAndProject {
    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String economicsLabel = "Economics";
    final String clientReviewLabel = "Client Review";
    final String NCALabel = "NCA";
    final String EWatchlistLabel = "E-Watchlist";
    final String ETDBLabel = "ETDB";
    final String ETDCLabel = "ETDC";
    final String projectBlitzLabel = "Project Blitz";
    final String PocketPOSLabel = "Pocket POS";
    final String ThinkLikeBusinessManageVideosLabel = "Think Like a Business Manager Videos";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ economicsLabel +"']")
    public WebElement economics;


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ clientReviewLabel +"']")
    public WebElement clientReview;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ NCALabel +"']")
    public WebElement NCA;


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ EWatchlistLabel +"']")
    public WebElement EWatchlist;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ ETDBLabel +"']")
    public WebElement ETDB;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ ETDCLabel +"']")
    public WebElement ETDC;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ projectBlitzLabel +"']")
    public WebElement projectBlitz;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ PocketPOSLabel +"']")
    public WebElement PocketPOS;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ ThinkLikeBusinessManageVideosLabel +"']")
    public WebElement ThinkLikeBusinessManageVideos;


    public TrainingMaterialAndProject(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void verifyEconomics()  {
        businessBankingHelper.verifyPage(economicsLabel, economics);
        businessBankingHelper.takeSnapShot(economicsLabel +" Page");
    }
    public void verifyCredit()  {
        businessBankingHelper.verifyPage(clientReviewLabel, clientReview);
        businessBankingHelper.takeSnapShot(clientReviewLabel +" Page");
    }
    public void verifyNCA()  {
        businessBankingHelper.verifyPage(NCALabel, NCA);
        businessBankingHelper.takeSnapShot(NCALabel +" Page");
    }
    public void verifyEWatchlist()  {
        businessBankingHelper.verifyPage(EWatchlistLabel, EWatchlist);
        businessBankingHelper.takeSnapShot(EWatchlistLabel +" Page");
    }
    public void verifyAuthorisation()  {
        businessBankingHelper.verifyPage(ETDBLabel, ETDB);
        businessBankingHelper.takeSnapShot(ETDBLabel +" Page");
    }
    public void verifyETDC()  {
        businessBankingHelper.verifyPage(ETDCLabel, ETDC);
        businessBankingHelper.takeSnapShot(ETDCLabel +" Page");
    }
    public void verifyProjectBlitz()  {
        businessBankingHelper.verifyPage(projectBlitzLabel, projectBlitz);
        businessBankingHelper.takeSnapShot(projectBlitzLabel +" Page");
    }

    public void verifyPocketPOS()  {
        businessBankingHelper.verifyPage(PocketPOSLabel, PocketPOS);
        businessBankingHelper.takeSnapShot(PocketPOSLabel +" Page");
    }
    public void verifyThinkLikeBusinessManageVideosLabel()  {
        businessBankingHelper.verifyPage(ThinkLikeBusinessManageVideosLabel, ThinkLikeBusinessManageVideos);
        businessBankingHelper.takeSnapShot(ThinkLikeBusinessManageVideosLabel +" Page");
    }

}
