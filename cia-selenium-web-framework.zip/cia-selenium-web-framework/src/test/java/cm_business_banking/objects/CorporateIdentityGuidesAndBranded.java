package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class CorporateIdentityGuidesAndBranded {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String guidesAndCheatSheetsLabel = "GUIDES AND CHEAT SHEETS";
    final String brandedTemplatesLabel = "BRANDED TEMPLATES";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ guidesAndCheatSheetsLabel +"']")
    public WebElement guidesAndCheatSheets;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ brandedTemplatesLabel +"']")
    public WebElement brandedTemplates;

    public CorporateIdentityGuidesAndBranded(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getGuidesAndCheatSheets() {
        businessBankingHelper.verifyAndClickElement( guidesAndCheatSheets, guidesAndCheatSheetsLabel);
    }
    public void verifyGuidesAndCheatSheets()  {
        businessBankingHelper.verifyPage(guidesAndCheatSheetsLabel, guidesAndCheatSheets);
        businessBankingHelper.takeSnapShot(guidesAndCheatSheetsLabel+" Page");
    }
    public void getBrandedTemplates() {
        businessBankingHelper.verifyAndClickElement( brandedTemplates, brandedTemplatesLabel);
    }
    public void verifyBrandedTemplates()  {
        businessBankingHelper.verifyPage(brandedTemplatesLabel, brandedTemplates);
        businessBankingHelper.takeSnapShot(brandedTemplatesLabel+" Page");
    }
}
