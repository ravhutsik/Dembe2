package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Agriculture {


    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String overviewLabel = "Overview";
    final String clientValuePropositionsLabel = "Client Value Propositions";
    final String marketingMaterialAndSalesSupportLabel = "Marketing Material and Sales Support";
    final String keyContactsLabel = "Key Contacts";
    final String agricultureIndustryInformationLabel = "Agriculture Industry Information";
    final String sustainabilityLabel = "Sustainability";
    final String agricultureCreditGuidelinesLabel = "Agriculture Credit Guidelines";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ overviewLabel +"']")
    public WebElement overview;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ clientValuePropositionsLabel +"']")
    public WebElement clientValuePropositions;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ marketingMaterialAndSalesSupportLabel +"']")
    public WebElement marketingMaterialAndSalesSupport;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ keyContactsLabel +"']")
    public WebElement keyContacts;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ agricultureIndustryInformationLabel +"']")
    public WebElement agricultureIndustryInformation;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ sustainabilityLabel +"']")
    public WebElement sustainability;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ agricultureCreditGuidelinesLabel +"']")
    public WebElement agricultureCreditGuidelines;



    public Agriculture(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getOverview() {
        businessBankingHelper.verifyAndClickElement( overview, overviewLabel);
    }
    public void getClientValuePropositions() {
        businessBankingHelper.verifyAndClickElement(clientValuePropositions, clientValuePropositionsLabel);
    }
    public void getMarketingMaterialAndSalesSupport() {
        businessBankingHelper.verifyAndClickElement(marketingMaterialAndSalesSupport, marketingMaterialAndSalesSupportLabel);
    }
    public void getKeyContacts() {
        businessBankingHelper.verifyAndClickElement(keyContacts, keyContactsLabel);
    }
    public void getAgricultureIndustryInformation() {
        businessBankingHelper.verifyAndClickElement(agricultureIndustryInformation, agricultureIndustryInformationLabel);
    }
    public void getSustainability() {
        businessBankingHelper.verifyAndClickElement(sustainability, sustainabilityLabel);
    }
    public void getAgricultureCreditGuidelines() {
        businessBankingHelper.verifyAndClickElement(agricultureCreditGuidelines, agricultureCreditGuidelinesLabel);
    }


}
