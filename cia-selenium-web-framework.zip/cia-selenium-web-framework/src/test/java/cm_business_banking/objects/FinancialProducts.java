package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class FinancialProducts {
    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String core1Label = "Core 1";
    final String core2Label = "Core 2";
    final String presentationLabel = "Presentations";
    final String vehicleAndAssetFinanceLabel = "Vehicle and Asset Finance";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ core1Label +"']")
    public WebElement core1;


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ core2Label +"']")
    public WebElement core2;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ presentationLabel +"']")
    public WebElement presentation;


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ vehicleAndAssetFinanceLabel +"']")
    public WebElement vehicleAndAssetFinance;



    public FinancialProducts(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getCore1() {
        businessBankingHelper.verifyAndClickElement(core1, core1Label);
    }
    public void getCore2() {
        businessBankingHelper.verifyAndClickElement(core2, core2Label);
    }
    public void getPresentation() {
        businessBankingHelper.verifyAndClickElement(presentation, presentationLabel);
    }
    public void getVehicleAndAssetFinance() {
        businessBankingHelper.verifyAndClickElement(vehicleAndAssetFinance, vehicleAndAssetFinanceLabel);
    }


    public void verifyCore1()  {
        businessBankingHelper.verifyPage(core1Label, core1);
        businessBankingHelper.takeSnapShot(core1Label +" Page");
    }
    public void verifyCore2()  {
        businessBankingHelper.verifyPage(core2Label, core2);
        businessBankingHelper.takeSnapShot(core2Label +" Page");
    }
    public void verifyPresentation()  {
        businessBankingHelper.verifyPage(presentationLabel, presentation);
        businessBankingHelper.takeSnapShot(presentationLabel +" Page");
    }
    public void verifyVehicleAndAssetFinance()  {
        businessBankingHelper.verifyPage(vehicleAndAssetFinanceLabel, vehicleAndAssetFinance);
        businessBankingHelper.takeSnapShot(vehicleAndAssetFinanceLabel +" Page");
    }

}
