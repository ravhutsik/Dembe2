package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class Processes {


    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String IndexCoreBankingProcessesLabel = "Index - Core Banking Processes";


    String [] IndexCoreBankingProcesses = {"Index - Core Banking Processes"};


    public Processes(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getIndexCoreBankingProcesses() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(IndexCoreBankingProcessesLabel), IndexCoreBankingProcessesLabel);
        businessBankingHelper.performOperation(IndexCoreBankingProcesses);
    }
}
