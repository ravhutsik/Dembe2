package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class CoreBankingTools {


    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String PreWorkCoreBankingLabel = "Pre-work Core Banking";
    final String SalesPitchToolLabel = "Sales Pitch tool";
    final String MasterClientProposalTemplateLabel = "Master Client Proposal Template";
    final String BankerToolkitLabel = "Banker Toolkit";

    String [] PreWorkCoreBanking = {"Pre-work Core Banking"};
    String [] SalesPitchTool  = {"Sales Pitch tool"};
    String [] MasterClientProposalTemplate  = {"Master Client Proposal Template"};
    String [] BankerToolkit = {"Banker Toolkit"};

    public CoreBankingTools(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getPreWorkCoreBanking() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(PreWorkCoreBankingLabel), PreWorkCoreBankingLabel);
        businessBankingHelper.performOperation(PreWorkCoreBanking);
    }

    public void getSalesPitchTool() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(SalesPitchToolLabel), SalesPitchToolLabel);
        businessBankingHelper.performOperation(SalesPitchTool);
    }

    public void getMasterClientProposalTemplate() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(MasterClientProposalTemplateLabel), MasterClientProposalTemplateLabel);
        businessBankingHelper.performOperation(MasterClientProposalTemplate);
    }
    public void getBankerToolkit() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(BankerToolkitLabel), BankerToolkitLabel);
        businessBankingHelper.performOperation(BankerToolkit);
    }

}
