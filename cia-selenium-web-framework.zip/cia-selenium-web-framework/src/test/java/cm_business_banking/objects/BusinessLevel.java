package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class BusinessLevel {
    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String businessUpdateLabel = "Business updates / performance";
    final String innovationLabel = "Innovation ";
    final String CikoDeskLabel = "Ciko's desk";
    final String deskLabel = "ME's Desk ";
    final String strategyLabel = "Strategy";
    final String businessBankingNewsLabel = "Business Banking News";
    final String staffEngagementsLabel = "Staff Engagements";
    final String aboutBusinessBankingLabel = "About Business Banking";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ businessUpdateLabel +"']")
    public WebElement businessUpdate;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ innovationLabel +"']")
    public WebElement innovation;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ CikoDeskLabel +"']")
    public WebElement CikoDeskL;


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ deskLabel +"']")
    public WebElement desk;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ strategyLabel +"']")
    public WebElement strategy;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ businessBankingNewsLabel +"']")
    public WebElement businessBanking;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ staffEngagementsLabel +"']")
    public WebElement staffEngagements;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ aboutBusinessBankingLabel +"']")
    public WebElement aboutBusinessBanking;



    public BusinessLevel(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getBusinessUpdate() {
        businessBankingHelper.verifyAndClickElement(businessUpdate, businessUpdateLabel);
    }
    public void getInnovation() {
        businessBankingHelper.verifyAndClickElement(innovation, innovationLabel);
    }
    public void getCikoDesk() {
        businessBankingHelper.verifyAndClickElement(CikoDeskL, CikoDeskLabel);
    }
    public void getDesk() {
        businessBankingHelper.verifyAndClickElement(desk, deskLabel);
    }
    public void getStrategy() {
        businessBankingHelper.verifyAndClickElement(strategy, strategyLabel);
    }
    public void getBusinessBankingNews() {
        businessBankingHelper.verifyAndClickElement(businessBanking, businessBankingNewsLabel);
    }
    public void getStaffEngagements() {
        businessBankingHelper.verifyAndClickElement(staffEngagements, staffEngagementsLabel);
    }

    public void getAboutBusinessBanking() {
        businessBankingHelper.verifyAndClickElement(aboutBusinessBanking, aboutBusinessBankingLabel);
    }



}
