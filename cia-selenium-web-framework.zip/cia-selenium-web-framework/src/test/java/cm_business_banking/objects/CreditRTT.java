package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class CreditRTT {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String CMRRLearningMatrixLabel = "CM RR Learning Matrix";
    final String experianManualLabel = "Experian Manual";
    final String CARRLearningMatrixLabel = "CA RR Learning Matrix";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ CMRRLearningMatrixLabel +"']")
    public WebElement CMRRLearningMatrix;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ experianManualLabel +"']")
    public WebElement experianManual;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ CARRLearningMatrixLabel +"']")
    public WebElement CARRLearningMatrix;

    public CreditRTT(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getCMRRLearningMatrix() {
        businessBankingHelper.verifyAndClickElement( CMRRLearningMatrix, CMRRLearningMatrixLabel);
    }
    public void verifyCMRRLearningMatrix()  {
        businessBankingHelper.verifyPage(CMRRLearningMatrixLabel, CMRRLearningMatrix);
        businessBankingHelper.takeSnapShot(CMRRLearningMatrixLabel +" Page");
    }
    public void getExperianManual() {
        businessBankingHelper.verifyAndClickElement( experianManual, experianManualLabel);
    }
    public void verifyExperianManual()  {
        businessBankingHelper.verifyPage(experianManualLabel, experianManual);
        businessBankingHelper.takeSnapShot(experianManualLabel +" Page");
    }
    public void getCARRLearningMatrix() {
        businessBankingHelper.verifyAndClickElement(CARRLearningMatrix, CARRLearningMatrixLabel);
    }
    public void verifyCARRLearningMatrix()  {
        businessBankingHelper.verifyPage(CARRLearningMatrixLabel, CARRLearningMatrix);
        businessBankingHelper.takeSnapShot(CARRLearningMatrixLabel +" Page");
    }
}
