package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class AgriMarketingMaterialAndSalesSupport {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String agricultureMarketingMaterialSalesSupportLabel = "Agriculture Marketing Material & Sales Support";
    final String blankSpaceTBCLabel = "Blank space tbc";
    final String mediaArticlesLabel = "Media Articles";
    final String interviewsWithWandileSihloboLabel = "Interviews with Wandile Sihlobo";
    final String clientTestimonialVideosLabel = "Client Testimonial Videos";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ agricultureMarketingMaterialSalesSupportLabel +"']")
    public WebElement agricultureMarketingMaterialSalesSupport;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ blankSpaceTBCLabel +"']")
    public WebElement blankSpaceTBC;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ mediaArticlesLabel +"']")
    public WebElement mediaArticles;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ interviewsWithWandileSihloboLabel +"']")
    public WebElement interviewsWithWandileSihlobo;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ clientTestimonialVideosLabel +"']")
    public WebElement clientTestimonialVideos;

    public AgriMarketingMaterialAndSalesSupport(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getAgricultureMarketingMaterialSalesSupport() {
        businessBankingHelper.verifyAndClickElement( agricultureMarketingMaterialSalesSupport, agricultureMarketingMaterialSalesSupportLabel);
    }
    public void verifyAgricultureMarketingMaterialSalesSupport()  {
        businessBankingHelper.verifyPage(agricultureMarketingMaterialSalesSupportLabel, agricultureMarketingMaterialSalesSupport);
        businessBankingHelper.takeSnapShot(agricultureMarketingMaterialSalesSupportLabel +" Page");
    }
    public void getBlankSpaceTBC() {
        businessBankingHelper.verifyAndClickElement( blankSpaceTBC, blankSpaceTBCLabel);
    }
    public void verifyBlankSpaceTBC()  {
        businessBankingHelper.verifyPage(blankSpaceTBCLabel, blankSpaceTBC);
        businessBankingHelper.takeSnapShot(blankSpaceTBCLabel +" Page");
    }
    public void getMediaArticles() {
        businessBankingHelper.verifyAndClickElement( mediaArticles, mediaArticlesLabel);
    }
    public void verifyMediaArticles()  {
        businessBankingHelper.verifyPage(mediaArticlesLabel, mediaArticles);
        businessBankingHelper.takeSnapShot(mediaArticlesLabel +" Page");
    }
    public void getInterviewsWithWandileSihlobo() {
        businessBankingHelper.verifyAndClickElement( interviewsWithWandileSihlobo, interviewsWithWandileSihloboLabel);
    }
    public void verifyInterviewsWithWandileSihlobo()  {
        businessBankingHelper.verifyPage(interviewsWithWandileSihloboLabel, interviewsWithWandileSihlobo);
        businessBankingHelper.takeSnapShot(interviewsWithWandileSihloboLabel +" Page");
    }
    public void getClientTestimonialVideos() {
        businessBankingHelper.verifyAndClickElement( clientTestimonialVideos, clientTestimonialVideosLabel);
    }
    public void verifyClientTestimonialVideos()  {
        businessBankingHelper.verifyPage(clientTestimonialVideosLabel, clientTestimonialVideos);
        businessBankingHelper.takeSnapShot(clientTestimonialVideosLabel +" Page");
    }
}
