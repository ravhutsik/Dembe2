package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class BBProductCommunications {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String smallSizedAgricClientsCreditAssessmentLabel = "SMALL SIZED AGRIC CLIENTS CREDIT ASSESSMENT";
    final String businessCreditCardLabel = "BUSINESS CREDIT CARD";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ smallSizedAgricClientsCreditAssessmentLabel +"']")
    public WebElement smallSizedAgricClientsCreditAssessment;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ businessCreditCardLabel +"']")
    public WebElement businessCreditCard;

    public BBProductCommunications(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getSmallSizedAgricClientsCreditAssessment() {
        businessBankingHelper.verifyAndClickElement( smallSizedAgricClientsCreditAssessment, smallSizedAgricClientsCreditAssessmentLabel);
    }
    public void verifySmallSizedAgricClientsCreditAssessment()  {
        businessBankingHelper.verifyPage(smallSizedAgricClientsCreditAssessmentLabel, smallSizedAgricClientsCreditAssessment);
        businessBankingHelper.takeSnapShot(smallSizedAgricClientsCreditAssessmentLabel+" Page");
    }
    public void getBusinessCreditCard() {
        businessBankingHelper.verifyAndClickElement( businessCreditCard, businessCreditCardLabel);
    }
    public void verifyBusinessCreditCard()  {
        businessBankingHelper.verifyPage(businessCreditCardLabel, businessCreditCard);
        businessBankingHelper.takeSnapShot(businessCreditCardLabel+" Page");
    }


}
