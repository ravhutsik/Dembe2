package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Training {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String ACMMitigantAndDocumentManagementProcedureLabel = "ACM MITIGANT and DOCUMENT MANAGEMENT PROCEDURE";
    final String ACMFacilityManagementProcedureLabel = "ACM FACILITY MANAGEMENT PROCEDURE";
    final String ACMEntityManagementProcedureLabel = "ACM ENTITY MANAGEMENT PROCEDURE";
    final String trainingHyperlinksLabel = "TRAINING HYPERLINKS";
    final String creditPipelineLabel = "CREDIT PIPELINE";
    final String RMMRiskManagementMeasureLabel = "RMM - RISK MANAGEMENT MEASURE";
    final String impairmentPortalIntroductionLabel = "IMPAIRMENT PORTAL INTRODUCTION";
    final String eSodaQuickTrainingGuideLabel = "eSODA QUICK TRAINING GUIDE";
    final String eCASQuickGuideLabel = "eCAS Quick Guide";
    final String PlugAndTransactTokenAfrRadioLabel = "Plug and Transact Token Afr Radio";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ ACMMitigantAndDocumentManagementProcedureLabel +"']")
    public WebElement ACMMitigantAndDocumentManagementProcedure;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ ACMFacilityManagementProcedureLabel +"']")
    public WebElement ACMFacilityManagementProcedure;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ ACMEntityManagementProcedureLabel +"']")
    public WebElement ACMEntityManagementProcedure;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ trainingHyperlinksLabel +"']")
    public WebElement trainingHyperlinks;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ creditPipelineLabel +"']")
    public WebElement creditPipeline;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ RMMRiskManagementMeasureLabel +"']")
    public WebElement RMMRiskManagementMeasure;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ impairmentPortalIntroductionLabel +"']")
    public WebElement impairmentPortalIntroduction;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ eSodaQuickTrainingGuideLabel +"']")
    public WebElement eSodaQuickTrainingGuide;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ eCASQuickGuideLabel +"']")
    public WebElement eCASQuickGuide;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ PlugAndTransactTokenAfrRadioLabel +"']")
    public WebElement PlugAndTransactTokenAfrRadio;



    public Training(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getACMMitigantAndDocumentManagementProcedure() {
        businessBankingHelper.verifyAndClickElement( ACMMitigantAndDocumentManagementProcedure, ACMMitigantAndDocumentManagementProcedureLabel);
    }
    public void verifyACMMitigantAndDocumentManagementProcedure()  {
        businessBankingHelper.verifyPage(ACMMitigantAndDocumentManagementProcedureLabel, ACMMitigantAndDocumentManagementProcedure);
        businessBankingHelper.takeSnapShot(ACMMitigantAndDocumentManagementProcedureLabel+" Page");
    }
    public void getACMFacilityManagementProcedure() {
        businessBankingHelper.verifyAndClickElement( ACMFacilityManagementProcedure, ACMFacilityManagementProcedureLabel);
    }
    public void verifyACMFacilityManagementProcedure()  {
        businessBankingHelper.verifyPage(ACMFacilityManagementProcedureLabel, ACMFacilityManagementProcedure);
        businessBankingHelper.takeSnapShot(ACMFacilityManagementProcedureLabel+" Page");
    }
    public void getACMEntityManagementProcedure() {
        businessBankingHelper.verifyAndClickElement( ACMEntityManagementProcedure, ACMEntityManagementProcedureLabel);
    }
    public void verifyACMEntityManagementProcedure()  {
        businessBankingHelper.verifyPage(ACMEntityManagementProcedureLabel, ACMEntityManagementProcedure);
        businessBankingHelper.takeSnapShot(ACMEntityManagementProcedureLabel+" Page");
    }
    public void getTrainingHyperlinks() {
        businessBankingHelper.verifyAndClickElement( trainingHyperlinks, trainingHyperlinksLabel);
    }
    public void verifyTrainingHyperlinks()  {
        businessBankingHelper.verifyPage(trainingHyperlinksLabel, trainingHyperlinks);
        businessBankingHelper.takeSnapShot(trainingHyperlinksLabel+" Page");
    }
    public void getCreditPipeline() {
        businessBankingHelper.verifyAndClickElement( creditPipeline, creditPipelineLabel);
    }
    public void verifyCreditPipeline()  {
        businessBankingHelper.verifyPage(creditPipelineLabel, creditPipeline);
        businessBankingHelper.takeSnapShot(creditPipelineLabel+" Page");
    }
    public void getRMMRiskManagementMeasure() {
        businessBankingHelper.verifyAndClickElement( RMMRiskManagementMeasure, RMMRiskManagementMeasureLabel);
    }
    public void verifyRMMRiskManagementMeasure()  {
        businessBankingHelper.verifyPage(RMMRiskManagementMeasureLabel, RMMRiskManagementMeasure);
        businessBankingHelper.takeSnapShot(RMMRiskManagementMeasureLabel+" Page");
    }

    public void getImpairmentPortalIntroduction() {
        businessBankingHelper.verifyAndClickElement( impairmentPortalIntroduction, impairmentPortalIntroductionLabel);
    }
    public void verifyImpairmentPortalIntroduction()  {
        businessBankingHelper.verifyPage(impairmentPortalIntroductionLabel, impairmentPortalIntroduction);
        businessBankingHelper.takeSnapShot(impairmentPortalIntroductionLabel+" Page");
    }
    public void getESodaQuickTrainingGuide() {
        businessBankingHelper.verifyAndClickElement( eSodaQuickTrainingGuide, eSodaQuickTrainingGuideLabel);
    }
    public void verifyESodaQuickTrainingGuide()  {
        businessBankingHelper.verifyPage(eSodaQuickTrainingGuideLabel, eSodaQuickTrainingGuide);
        businessBankingHelper.takeSnapShot(eSodaQuickTrainingGuideLabel+" Page");
    }
    public void getECASQuickGuide() {
        businessBankingHelper.verifyAndClickElement( eCASQuickGuide, eCASQuickGuideLabel);
    }
    public void verifyECASQuickGuide()  {
        businessBankingHelper.verifyPage(eCASQuickGuideLabel, eCASQuickGuide);
        businessBankingHelper.takeSnapShot(eCASQuickGuideLabel+" Page");
    }


    public void getPlugAndTransactTokenAfrRadio() {
        businessBankingHelper.verifyAndClickElement( PlugAndTransactTokenAfrRadio, PlugAndTransactTokenAfrRadioLabel);
    }
    public void verifyPlugAndTransactTokenAfrRadio()  {
        businessBankingHelper.verifyPage(PlugAndTransactTokenAfrRadioLabel, PlugAndTransactTokenAfrRadio);
        businessBankingHelper.takeSnapShot(PlugAndTransactTokenAfrRadioLabel +" Page");
    }
}
