package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class DebtorManagementTemplates {


    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String NDMTemplateLAbel = "NDM TEMPLATES";
    final String wholeViewBBEditorialLabel = "Whole-view Business Banking Afrikaans editorial";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ NDMTemplateLAbel +"']")
    public WebElement NDMTemplate;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ wholeViewBBEditorialLabel +"']")
    public WebElement wholeViewBBEditorial;

    public DebtorManagementTemplates(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getNDMTemplate() {
        businessBankingHelper.verifyAndClickElement( NDMTemplate, NDMTemplateLAbel);
    }
    public void verifyNDMTemplate(){
        businessBankingHelper.verifyPage(NDMTemplateLAbel, NDMTemplate);
        businessBankingHelper.takeSnapShot(NDMTemplateLAbel+" Page");
    }
        public void getWholeViewBBEditorial() {
        businessBankingHelper.verifyAndClickElement( wholeViewBBEditorial, wholeViewBBEditorialLabel);
    }
    public void verifyWholeViewBBEditorial(){
        businessBankingHelper.verifyPage(wholeViewBBEditorialLabel, wholeViewBBEditorial);
        businessBankingHelper.takeSnapShot(wholeViewBBEditorialLabel+" Page");
    }

}
