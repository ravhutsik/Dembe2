package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class EnterpriseDevelopment {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String EDPropositionLabel = "ED Proposition";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ EDPropositionLabel +"']")
    public WebElement EDProposition;

    public EnterpriseDevelopment(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getEDProposition() {
        businessBankingHelper.verifyAndClickElement( EDProposition, EDPropositionLabel);
    }
    public void verifyEDProposition()  {
        businessBankingHelper.verifyPage(EDPropositionLabel, EDProposition);
        businessBankingHelper.takeSnapShot(EDPropositionLabel +" Page");
    }
}
