package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Credit {

    public final WebDriver driver;

    final String documentLibraryLabel = "DOCUMENT LIBRARY";
    final String applicationToolsLabel = "APPLICATION TOOLS";
    final String performanceScorecardLabel = "PERFORMANCE SCORECARD";
    final String policiesLabel = "POLICIES";
    final String proceduralManualsLabel = "PROCEDURAL MANUALS";
    final String businessBankingProcessesLabel = "BUSINESS BANKING PROCESSES";
    final String standardsGuidelinesLabel = "STANDARDS & GUIDELINESSS";
    final String trainingLabel = "TRAINING";
    final String bbFinancialLabLabel = "BB FINANCIAL LAB";
    final String communicationsLabel = "COMMUNICATIONS";
    final String creditRiskGovernanceLabel = "CREDIT & RISK GOVERNANCE";
    final String newSubCategoryLabel = "New SubCategory";
    
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ documentLibraryLabel +"']")
    public WebElement documentLibrary;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ applicationToolsLabel +"']")
    public WebElement applicationTools;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ performanceScorecardLabel +"']")
    public WebElement performanceScorecard;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ policiesLabel +"']")
    public WebElement policies;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ proceduralManualsLabel +"']")
    public WebElement proceduralManuals;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ businessBankingProcessesLabel +"']")
    public WebElement businessBankingProcesses;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ standardsGuidelinesLabel +"']")
    public WebElement standardsGuidelines;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ trainingLabel +"']")
    public WebElement training;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ bbFinancialLabLabel +"']")
    public WebElement bbFinancialLad;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ communicationsLabel +"']")
    public WebElement communications;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ creditRiskGovernanceLabel +"']")
    public WebElement creditRiskGovernance;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ newSubCategoryLabel +"']")
    public WebElement newSubCategory;



    BusinessBankingHelper businessBankingHelper;

    public Credit(WebDriver driver){

        this.driver=driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getDocumentLibrary() {
        businessBankingHelper.verifyAndClickElement(documentLibrary, documentLibraryLabel);
    }

    public void getApplicationTools() {
        businessBankingHelper.verifyAndClickElement(applicationTools, applicationToolsLabel);
    }

    public void getPERFORMANCE_SCORECARD() {
        businessBankingHelper.verifyAndClickElement(performanceScorecard, performanceScorecardLabel);
    }

    public void getPolicies() {
        businessBankingHelper.verifyAndClickElement( policies, policiesLabel);
    }

    public void getProceduralManuals() {
        businessBankingHelper.verifyAndClickElement( proceduralManuals, proceduralManualsLabel);
    }

    public void getBusinessBankingProcesses() {
        businessBankingHelper.verifyAndClickElement( businessBankingProcesses, businessBankingProcessesLabel);
    }

    public void getStandardsGuidelines() {
        businessBankingHelper.verifyAndClickElement( standardsGuidelines, standardsGuidelinesLabel);
    }

    public void getTraining() {
        businessBankingHelper.verifyAndClickElement( training, trainingLabel);
    }

    public void getBBFinancialLad() {
        businessBankingHelper.verifyAndClickElement(bbFinancialLad, bbFinancialLabLabel);
    }

    public void getCommunications() {
        businessBankingHelper.verifyAndClickElement(communications, communicationsLabel);
    }

    public void getCreditRiskGovernance() {
        businessBankingHelper.verifyAndClickElement( creditRiskGovernance, creditRiskGovernanceLabel);
    }

    public void getNewSubCategory() {
        businessBankingHelper.verifyAndClickElement(newSubCategory, newSubCategoryLabel);
    }
}
