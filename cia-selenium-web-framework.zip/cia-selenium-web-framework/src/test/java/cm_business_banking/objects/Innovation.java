package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Innovation {
    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String ideoShopppingCartVideoLabel = "Ideo Shoppping Cart Video";
    final String blueOceanStrategiesLabel = "Blue Ocean Strategies";
    final String innovationApproachAtNestleLabel = "Innovation Approach at Nestle";
    final String innovationsLandedIn2015Label = "Innovations landed in 2015";
    final String marketEdgeVideoLabel = "Market Edge video";
    final String GapAccessClientVideoLabel = "Gap Access Client video";
    final String onlineBusinessRegistrationVideoLabel = "Online Business Registration Video";
    final String NedbankMarketEdgeDeliversLabel = "Nedbank Market Edge Delivers";
    final String ZAWebsiteLabel = "za website";
    final String PocketPOSVideoLabel = "PocketPOS video";
    final String PlugAndTransactTokenGettingStartedGuideLabel = "Plug and Transact Token - Getting Started guide";
    final String GlobalVideoBankingVideoLabel = "Global Video Banking video";
    final String NotificationsLaunchLabel = "Notifications Launch";
    final String BSTWorkflowDemoLabel = "BST Workflow Demo";
    final String BSTWorkflowDemDesignThinkingOurInnovationApproachLabel = "Design Thinking Our Innovation Approach";
    final String MarketEdgeBrochureLabel = "Market Edge Brochure";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ ideoShopppingCartVideoLabel +"']")
    public WebElement ideoShopppingCartVideo;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ blueOceanStrategiesLabel +"']")
    public WebElement blueOceanStrategies;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ innovationApproachAtNestleLabel +"']")
    public WebElement innovationApproachAtNestle;


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ innovationsLandedIn2015Label +"']")
    public WebElement innovationsLandedIn2015;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ marketEdgeVideoLabel +"']")
    public WebElement marketEdgeVideo;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ GapAccessClientVideoLabel +"']")
    public WebElement GapAccessClientVideo;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ onlineBusinessRegistrationVideoLabel +"']")
    public WebElement onlineBusinessRegistrationVideo;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ NedbankMarketEdgeDeliversLabel +"']")
    public WebElement NedbankMarketEdgeDelivers;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ ZAWebsiteLabel +"']")
    public WebElement ZAWebsite;


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ PocketPOSVideoLabel +"']")
    public WebElement PocketPOSVideo;


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ PlugAndTransactTokenGettingStartedGuideLabel +"']")
    public WebElement PlugAndTransactTokenGettingStartedGuide;


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ GlobalVideoBankingVideoLabel +"']")
    public WebElement GlobalVideoBankingVideo;


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ NotificationsLaunchLabel +"']")
    public WebElement NotificationsLaunch;


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BSTWorkflowDemoLabel +"']")
    public WebElement BSTWorkflowDemo;


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BSTWorkflowDemDesignThinkingOurInnovationApproachLabel +"']")
    public WebElement BSTWorkflowDemDesignThinkingOurInnovationApproach;


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ MarketEdgeBrochureLabel +"']")
    public WebElement MarketEdgeBrochure;



    public Innovation(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getVideoShopppingCartVideo() {
        businessBankingHelper.verifyAndClickElement(ideoShopppingCartVideo, ideoShopppingCartVideoLabel);
    }
    public void getblueOceanStrategies() {
        businessBankingHelper.verifyAndClickElement(blueOceanStrategies, blueOceanStrategiesLabel);
    }
    public void getInnovationApproachAtNestle() {
        businessBankingHelper.verifyAndClickElement(innovationApproachAtNestle, innovationApproachAtNestleLabel);
    }
    public void getInnovationsLandedIn2015() {
        businessBankingHelper.verifyAndClickElement(innovationsLandedIn2015, innovationsLandedIn2015Label);
    }
    public void getMarketEdgeVideo() {
        businessBankingHelper.verifyAndClickElement(marketEdgeVideo, marketEdgeVideoLabel);
    }
    public void getGapAccessClientVideo() {
        businessBankingHelper.verifyAndClickElement(GapAccessClientVideo, GapAccessClientVideoLabel);
    }
    public void getOnlineBusinessRegistrationVideo() {
        businessBankingHelper.verifyAndClickElement(onlineBusinessRegistrationVideo, onlineBusinessRegistrationVideoLabel);
    }

    public void getNedbankMarketEdgeDelivers() {
        businessBankingHelper.verifyAndClickElement(NedbankMarketEdgeDelivers, NedbankMarketEdgeDeliversLabel);
    }

    public void getZAWebsite() {
        businessBankingHelper.verifyAndClickElement(ZAWebsite, ZAWebsiteLabel);
    }


    public void getPocketPOSVideo() {
        businessBankingHelper.verifyAndClickElement(PocketPOSVideo, PocketPOSVideoLabel);
    }


    public void getPlugAndTransactTokenGettingStartedGuide() {
        businessBankingHelper.verifyAndClickElement(PlugAndTransactTokenGettingStartedGuide, PlugAndTransactTokenGettingStartedGuideLabel);
    }


    public void getGlobalVideoBankingVideo() {
        businessBankingHelper.verifyAndClickElement(GlobalVideoBankingVideo, GlobalVideoBankingVideoLabel);
    }


    public void getNotificationsLaunch() {
        businessBankingHelper.verifyAndClickElement(NotificationsLaunch, NotificationsLaunchLabel);
    }


    public void getBSTWorkflowDemo() {
        businessBankingHelper.verifyAndClickElement(BSTWorkflowDemo, BSTWorkflowDemoLabel);
    }


    public void getBSTWorkflowDemDesignThinkingOurInnovationApproach() {
        businessBankingHelper.verifyAndClickElement(BSTWorkflowDemDesignThinkingOurInnovationApproach, BSTWorkflowDemDesignThinkingOurInnovationApproachLabel);
    }


    public void getMarketEdgeBrochure() {
        businessBankingHelper.verifyAndClickElement(MarketEdgeBrochure, MarketEdgeBrochureLabel);
    }


    public void verifyVideoShopppingCartVideo()  {
        businessBankingHelper.verifyPage(ideoShopppingCartVideoLabel, ideoShopppingCartVideo);
        businessBankingHelper.takeSnapShot(ideoShopppingCartVideoLabel +" Page");
    }
    public void verifyBlueOceanStrategies()  {
        businessBankingHelper.verifyPage(blueOceanStrategiesLabel, blueOceanStrategies);
        businessBankingHelper.takeSnapShot(blueOceanStrategiesLabel +" Page");
    }
    public void verifyInnovationApproachAtNestle()  {
        businessBankingHelper.verifyPage(innovationApproachAtNestleLabel, innovationApproachAtNestle);
        businessBankingHelper.takeSnapShot(innovationApproachAtNestleLabel +" Page");
    }

    public void verifyinnovationsLandedIn2015()  {
        businessBankingHelper.verifyPage(innovationsLandedIn2015Label, innovationsLandedIn2015);
        businessBankingHelper.takeSnapShot(innovationsLandedIn2015Label +" Page");
    }
    public void verifyMarketEdgeVideo()  {
        businessBankingHelper.verifyPage(marketEdgeVideoLabel, marketEdgeVideo);
        businessBankingHelper.takeSnapShot(marketEdgeVideoLabel +" Page");
    }
    public void verifyGapAccessClientVideo()  {
        businessBankingHelper.verifyPage(GapAccessClientVideoLabel, GapAccessClientVideo);
        businessBankingHelper.takeSnapShot(GapAccessClientVideoLabel +" Page");
    }
    public void verifyOnlineBusinessRegistrationVideo()  {
        businessBankingHelper.verifyPage(onlineBusinessRegistrationVideoLabel, onlineBusinessRegistrationVideo);
        businessBankingHelper.takeSnapShot(onlineBusinessRegistrationVideoLabel +" Page");
    }
    public void verifyNedbankMarketEdgeDelivers()  {
        businessBankingHelper.verifyPage(marketEdgeVideoLabel, marketEdgeVideo);
        businessBankingHelper.takeSnapShot(marketEdgeVideoLabel +" Page");
    }
    public void verifyZAWebsiteLabel()  {
        businessBankingHelper.verifyPage(ZAWebsiteLabel, ZAWebsite);
        businessBankingHelper.takeSnapShot(ZAWebsiteLabel +" Page");
    }

    public void verifyPocketPOSVideo()  {
        businessBankingHelper.verifyPage(PocketPOSVideoLabel, PocketPOSVideo);
        businessBankingHelper.takeSnapShot(PocketPOSVideoLabel +" Page");
    }

    public void verifyPlugAndTransactTokenGettingStartedGuide()  {
        businessBankingHelper.verifyPage(PlugAndTransactTokenGettingStartedGuideLabel, PlugAndTransactTokenGettingStartedGuide);
        businessBankingHelper.takeSnapShot(PlugAndTransactTokenGettingStartedGuideLabel +" Page");
    }

    public void verifyGlobalVideoBankingVideo()  {
        businessBankingHelper.verifyPage(GlobalVideoBankingVideoLabel, GlobalVideoBankingVideo);
        businessBankingHelper.takeSnapShot(GlobalVideoBankingVideoLabel +" Page");
    }

    public void verifyNotificationsLaunch()  {
        businessBankingHelper.verifyPage(NotificationsLaunchLabel, NotificationsLaunch);
        businessBankingHelper.takeSnapShot(NotificationsLaunchLabel +" Page");
    }

    public void verifyBSTWorkflowDemo()  {
        businessBankingHelper.verifyPage(BSTWorkflowDemoLabel, BSTWorkflowDemo);
        businessBankingHelper.takeSnapShot(BSTWorkflowDemoLabel +" Page");
    }

    public void verifyBSTWorkflowDemDesignThinkingOurInnovationApproach()  {
        businessBankingHelper.verifyPage(BSTWorkflowDemDesignThinkingOurInnovationApproachLabel, BSTWorkflowDemDesignThinkingOurInnovationApproach);
        businessBankingHelper.takeSnapShot(BSTWorkflowDemDesignThinkingOurInnovationApproachLabel +" Page");
    }

    public void verifyMarketEdgeBrochure()  {
        businessBankingHelper.verifyPage(MarketEdgeBrochureLabel, MarketEdgeBrochure);
        businessBankingHelper.takeSnapShot(MarketEdgeBrochureLabel +" Page");
    }


}
