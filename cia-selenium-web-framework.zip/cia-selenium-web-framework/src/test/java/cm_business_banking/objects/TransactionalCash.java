package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class TransactionalCash {


    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String CashOnlineLabel = "Cash Online";
    final String cashVaultLabel = "CashVault";
    final String manualCashBankingLabel = "Manual Cash Banking";


    final String CashOnlineTBCheatSheetLabel = "Cash Online TB cheat sheet";
    final String ConsumableOrderFormsLabel = "Consumable order forms (cash)";
    final String NedbankCashOnlineTrainingMaterialLabel = "Nedbank Cash Online training material";

    final String cashVCheatSheetLabel = "CashVault 10 000 TB Cheat sheet";
    final String cashVaultCoinSidecarCheatSheetLabel = "CashVault Coin Sidecar cheat sheet";
    final String consumableOrderFormsLabel = "Consumable order forms (cash)";
    final String cashVaultTrainingLabel = "CashVault training";
    final String cashVaultCheatsheetLabel = "CashVault 4000 Cheatsheet";


    final String consumableOrderFormsCashLabel = "Consumable order forms (cash)";
    final String manualCashBankingCheatSheetLabel = "Manual Cash Banking Cheat sheet";
    final String manualCashHandlingTrainingLabel = "Manual Cash Handling training";



    @FindBy(how = How.XPATH, using = "//*[text() = '"+ CashOnlineLabel +"']")
    public WebElement CashOnline;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ cashVaultLabel +"']")
    public WebElement CashVault;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ manualCashBankingLabel +"']")
    public WebElement ManualCashBanking;


    public TransactionalCash(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getCashOnline() {
        businessBankingHelper.verifyAndClickElement( CashOnline, CashOnlineLabel);
        businessBankingHelper.verifyAndClickMultiElement( businessBankingHelper.getWebElement(CashOnlineTBCheatSheetLabel), CashOnlineTBCheatSheetLabel);
        businessBankingHelper.navigateBack();
        businessBankingHelper.verifyAndClickMultiElement( businessBankingHelper.getWebElement(ConsumableOrderFormsLabel), ConsumableOrderFormsLabel);
        businessBankingHelper.navigateBack();
        businessBankingHelper.verifyAndClickMultiElement( businessBankingHelper.getWebElement(NedbankCashOnlineTrainingMaterialLabel), NedbankCashOnlineTrainingMaterialLabel);
    }

    public void getCashVault() {
        businessBankingHelper.verifyAndClickElement( CashVault, cashVaultLabel);
        businessBankingHelper.verifyAndClickMultiElement( businessBankingHelper.getWebElement(cashVCheatSheetLabel), cashVCheatSheetLabel);
        businessBankingHelper.navigateBack();
        businessBankingHelper.verifyAndClickMultiElement( businessBankingHelper.getWebElement(cashVaultCoinSidecarCheatSheetLabel), cashVaultCoinSidecarCheatSheetLabel);
        businessBankingHelper.navigateBack();
        businessBankingHelper.verifyAndClickMultiElement( businessBankingHelper.getWebElement(consumableOrderFormsLabel), consumableOrderFormsLabel);
        businessBankingHelper.navigateBack();
        businessBankingHelper.verifyAndClickMultiElement( businessBankingHelper.getWebElement(cashVaultTrainingLabel), cashVaultTrainingLabel);
        businessBankingHelper.navigateBack();
        businessBankingHelper.verifyAndClickMultiElement( businessBankingHelper.getWebElement(cashVaultCheatsheetLabel), cashVaultCheatsheetLabel);

    }

    public void getManualCashBanking() {
        businessBankingHelper.verifyAndClickElement( ManualCashBanking, manualCashBankingLabel);
        businessBankingHelper.verifyAndClickMultiElement( businessBankingHelper.getWebElement(consumableOrderFormsCashLabel), consumableOrderFormsCashLabel);
        businessBankingHelper.navigateBack();
        businessBankingHelper.verifyAndClickMultiElement( businessBankingHelper.getWebElement(manualCashBankingCheatSheetLabel), manualCashBankingCheatSheetLabel);
        businessBankingHelper.navigateBack();
        businessBankingHelper.verifyAndClickMultiElement( businessBankingHelper.getWebElement(manualCashHandlingTrainingLabel), manualCashHandlingTrainingLabel);
    }

}
