package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Retail {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String OKCVPLabel = "OK CVP";
    final String ACDCExpressLabel = "ACDC Express";
    final String buildItLabel = "Build It";
    final String bakersBinLabel = "Bakers Bin";
    final String foodLoversMarketLabel = "Food Lover's Market";
    final String cellCLabel = "Cell C";
    final String dreamNailsLabel = "Dream Nails";
    final String freshStopLabel = "Fresh Stop";
    final String iFixLabel = "IFix";
    final String eliteStarTradingLabel = "Elite Star Trading";
    final String cashConvertersLabel = "Cash Converters";
    final String cashCrusadersLabel = "Cash Crusaders";
    final String micaLabel = "Mica";
    final String NWJLabel = "NWJ";
    final String essentialGroupLabel = "Essential Group";
    final String overlandLabel = "Overland";

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ OKCVPLabel +"']")
    public WebElement OKCVP;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ ACDCExpressLabel +"']")
    public WebElement ACDCExpress;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ buildItLabel +"']")
    public WebElement buildIt;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ bakersBinLabel +"']")
    public WebElement bakersBin;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ foodLoversMarketLabel +"']")
    public WebElement foodLoversMarket;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ cellCLabel +"']")
    public WebElement cellC;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ dreamNailsLabel +"']")
    public WebElement dreamNails;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ freshStopLabel +"']")
    public WebElement freshStop;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ iFixLabel +"']")
    public WebElement iFix;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ eliteStarTradingLabel +"']")
    public WebElement eliteStarTrading;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ cashConvertersLabel +"']")
    public WebElement cashConverters;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ cashCrusadersLabel +"']")
    public WebElement cashCrusaders;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ micaLabel +"']")
    public WebElement mica;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ NWJLabel +"']")
    public WebElement NWJ;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ essentialGroupLabel +"']")
    public WebElement essentialGroup;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ overlandLabel +"']")
    public WebElement overland;

    public Retail(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getOKCVP() {
        businessBankingHelper.verifyAndClickElement(OKCVP, OKCVPLabel);
    }
    public void verifyOKCVP()  {
        businessBankingHelper.verifyPage(OKCVPLabel, OKCVP);
        businessBankingHelper.takeSnapShot(OKCVPLabel +" Page");
    }
    public void getTexanACDCExpress() {
        businessBankingHelper.verifyAndClickElement(ACDCExpress, ACDCExpressLabel);
    }
    public void verifyTexanACDCExpress()  {
        businessBankingHelper.verifyPage(ACDCExpressLabel, ACDCExpress);
        businessBankingHelper.takeSnapShot(ACDCExpressLabel +" Page");
    }
    public void getBakersBin() {
        businessBankingHelper.verifyAndClickElement(bakersBin, bakersBinLabel);
    }
    public void verifyBakersBin()  {
        businessBankingHelper.verifyPage(bakersBinLabel, bakersBin);
        businessBankingHelper.takeSnapShot(bakersBinLabel +" Page");
    }
    public void getBuildIt() {
        businessBankingHelper.verifyAndClickElement(buildIt, bakersBinLabel);
    }
    public void verifyBuildIt()  {
        businessBankingHelper.verifyPage(buildItLabel, buildIt);
        businessBankingHelper.takeSnapShot(buildItLabel +" Page");
    }
    public void getFoodLoversMarket() {
        businessBankingHelper.verifyAndClickElement(foodLoversMarket, foodLoversMarketLabel);
    }
    public void verifyFoodLoversMarket()  {
        businessBankingHelper.verifyPage(foodLoversMarketLabel, foodLoversMarket);
        businessBankingHelper.takeSnapShot(foodLoversMarketLabel +" Page");
    }
    public void getCellC() {
        businessBankingHelper.verifyAndClickElement(cellC, cellCLabel);
    }
    public void verifyCellC()  {
        businessBankingHelper.verifyPage(cellCLabel, cellC);
        businessBankingHelper.takeSnapShot(cellCLabel +" Page");
    }
    public void getDreamNails() {
        businessBankingHelper.verifyAndClickElement(dreamNails, dreamNailsLabel);
    }
    public void verifyDreamNails()  {
        businessBankingHelper.verifyPage(dreamNailsLabel, dreamNails);
        businessBankingHelper.takeSnapShot(dreamNailsLabel +" Page");
    }
    public void getFreshStop() {
        businessBankingHelper.verifyAndClickElement(freshStop, freshStopLabel);
    }
    public void verifyFreshStop()  {
        businessBankingHelper.verifyPage(freshStopLabel, freshStop);
        businessBankingHelper.takeSnapShot(freshStopLabel +" Page");
    }
    public void getIFix() {
        businessBankingHelper.verifyAndClickElement(iFix, iFixLabel);
    }
    public void verifyIFix()  {
        businessBankingHelper.verifyPage(iFixLabel, iFix);
        businessBankingHelper.takeSnapShot(iFixLabel +" Page");
    }
    public void getEliteStarTrading() {
        businessBankingHelper.verifyAndClickElement(eliteStarTrading, eliteStarTradingLabel);
    }
    public void verifyEliteStarTrading()  {
        businessBankingHelper.verifyPage(eliteStarTradingLabel, eliteStarTrading);
        businessBankingHelper.takeSnapShot(eliteStarTradingLabel +" Page");
    }
    public void getCashConverters() {
        businessBankingHelper.verifyAndClickElement(cashConverters, cashConvertersLabel);
    }
    public void verifyCashConverters()  {
        businessBankingHelper.verifyPage(cashConvertersLabel, cashConverters);
        businessBankingHelper.takeSnapShot(cashConvertersLabel +" Page");
    }
    public void getCashCrusaders() {
        businessBankingHelper.verifyAndClickElement(cashCrusaders, cashCrusadersLabel);
    }
    public void verifyCashCrusaders()  {
        businessBankingHelper.verifyPage(cashCrusadersLabel, cashCrusaders);
        businessBankingHelper.takeSnapShot(cashCrusadersLabel +" Page");
    }
    public void getMica() {
        businessBankingHelper.verifyAndClickElement(mica, micaLabel);
    }
    public void verifyMica()  {
        businessBankingHelper.verifyPage(micaLabel, mica);
        businessBankingHelper.takeSnapShot(micaLabel +" Page");
    }
    public void getNWJ() {
        businessBankingHelper.verifyAndClickElement(NWJ, NWJLabel);
    }
    public void verifyNWJ()  {
        businessBankingHelper.verifyPage(NWJLabel, NWJ);
        businessBankingHelper.takeSnapShot(NWJLabel +" Page");
    }
    public void getEssentialGroup() {
        businessBankingHelper.verifyAndClickElement(essentialGroup, essentialGroupLabel);
    }
    public void verifyEssentialGroup()  {
        businessBankingHelper.verifyPage(essentialGroupLabel, essentialGroup);
        businessBankingHelper.takeSnapShot(essentialGroupLabel +" Page");
    }
    public void getOverland() {
        businessBankingHelper.verifyAndClickElement(overland, overlandLabel);
    }
    public void verifyOverland()  {
        businessBankingHelper.verifyPage(overlandLabel, overland);
        businessBankingHelper.takeSnapShot(overlandLabel +" Page");
    }
}
