package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Newsletter {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String newsletterAugust2015Label = "Newsletter - August 2015";
    final String newsletterApril2015Label = "Newsletter - April 2015";
    final String newsletterMarch2016Label = "Newsletter - March 2016";
    final String SAFranchiseLandscapeAugust2018Label = "SA Franchise Landscape - August 2018";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ newsletterAugust2015Label +"']")
    public WebElement newsletterAugust2015;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ newsletterApril2015Label +"']")
    public WebElement newsletterApril2015;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ newsletterMarch2016Label +"']")
    public WebElement newsletterMarch2016;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ SAFranchiseLandscapeAugust2018Label +"']")
    public WebElement SAFranchiseLandscapeAugust2018;

    public Newsletter(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getNewsletterAugust2015() {
        businessBankingHelper.verifyAndClickElement(newsletterAugust2015, newsletterAugust2015Label);
    }
    public void verifyNewsletterAugust2015()  {
        businessBankingHelper.verifyPage(newsletterAugust2015Label, newsletterAugust2015);
        businessBankingHelper.takeSnapShot(newsletterAugust2015Label +" Page");
    }
    public void getNewsletterApril2015() {
        businessBankingHelper.verifyAndClickElement(newsletterApril2015, newsletterApril2015Label);
    }
    public void verifyNewsletterApril2015()  {
        businessBankingHelper.verifyPage(newsletterApril2015Label, newsletterApril2015);
        businessBankingHelper.takeSnapShot(newsletterApril2015Label +" Page");
    }
    public void getNewsletterMarch2016() {
        businessBankingHelper.verifyAndClickElement(newsletterMarch2016, newsletterMarch2016Label);
    }
    public void verifyNewsletterMarch2016()  {
        businessBankingHelper.verifyPage(newsletterMarch2016Label, newsletterMarch2016);
        businessBankingHelper.takeSnapShot(newsletterMarch2016Label +" Page");
    }
    public void getSAFranchiseLandscapeAugust2018() {
        businessBankingHelper.verifyAndClickElement(SAFranchiseLandscapeAugust2018, SAFranchiseLandscapeAugust2018Label);
    }
    public void verifySAFranchiseLandscapeAugust2018()  {
        businessBankingHelper.verifyPage(SAFranchiseLandscapeAugust2018Label, SAFranchiseLandscapeAugust2018);
        businessBankingHelper.takeSnapShot(SAFranchiseLandscapeAugust2018Label +" Page");
    }
}
