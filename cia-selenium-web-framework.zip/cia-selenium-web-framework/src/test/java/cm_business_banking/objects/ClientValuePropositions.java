package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class ClientValuePropositions {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String automotiveLabel = "Automotive";
    final String foodLabel = "Food";
    final String fuelLabel = "Fuel";
    final String retailLabel = "retail";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ automotiveLabel +"']")
    public WebElement automotive;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ foodLabel +"']")
    public WebElement food;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ fuelLabel +"']")
    public WebElement fuel;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ retailLabel +"']")
    public WebElement retail;

    public ClientValuePropositions(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getAutomotive() {
        businessBankingHelper.verifyAndClickElement( automotive, automotiveLabel);
    }
    public void getFood() {
        businessBankingHelper.verifyAndClickElement( food, foodLabel);
    }
    public void getFuel() {
        businessBankingHelper.verifyAndClickElement( fuel, fuelLabel);
    }
    public void getRetail() {
        businessBankingHelper.verifyAndClickElement( retail, retailLabel);
    }

}
