package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class InternalTemplateCategory {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String operationalManagementLabel = "OPERATIONAL MANAGEMENT";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ operationalManagementLabel +"']")
    public WebElement operationalManagement;

    public InternalTemplateCategory(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getOperationalManagement() {
        businessBankingHelper.verifyAndClickElement( operationalManagement, operationalManagementLabel);
    }
    public void verifyOperationalManagement()  {
        businessBankingHelper.verifyPage(operationalManagementLabel, operationalManagement);
        businessBankingHelper.takeSnapShot(operationalManagementLabel+" Page");
    }
}
