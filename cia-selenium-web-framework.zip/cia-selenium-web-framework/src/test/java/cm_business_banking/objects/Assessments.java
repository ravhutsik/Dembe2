package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class Assessments {


    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String TrainingLabel = "Training";
    final String CoreBankingActionLearningLabel = "Core Banking Action Learning ";


    String [] Training = {"Training"};
    String [] CoreBankingActionLearning   = {"Core Banking Action Learning "};


    public Assessments(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getTraining() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(TrainingLabel), TrainingLabel);
        businessBankingHelper.performOperation(Training);
    }

    public void getCoreBankingActionLearning () {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(CoreBankingActionLearningLabel), CoreBankingActionLearningLabel);
        businessBankingHelper.performOperation(CoreBankingActionLearning );
    }


}
