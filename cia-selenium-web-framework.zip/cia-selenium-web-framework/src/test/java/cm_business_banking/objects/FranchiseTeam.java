package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class FranchiseTeam {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String contactDetailsForTheFranchisingTeamLabel = "Contact Details for the Franchising Team";

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ contactDetailsForTheFranchisingTeamLabel +"']")
    public WebElement contactDetailsForTheFranchisingTeam;

    public FranchiseTeam(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getContactDetailsForTheFranchisingTeam() {
        businessBankingHelper.verifyAndClickElement(contactDetailsForTheFranchisingTeam, contactDetailsForTheFranchisingTeamLabel);
    }
    public void verifyContactDetailsForTheFranchisingTeam()  {
        businessBankingHelper.verifyPage(contactDetailsForTheFranchisingTeamLabel, contactDetailsForTheFranchisingTeam);
        businessBankingHelper.takeSnapShot(contactDetailsForTheFranchisingTeamLabel +" Page");
    }
}
