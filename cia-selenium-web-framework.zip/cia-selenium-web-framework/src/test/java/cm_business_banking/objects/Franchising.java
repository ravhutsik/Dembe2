package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Franchising {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String clientValuePropositionsLabel = "Client Value Propositions";
    final String CoSigningBySBUCreditLabel  = "Co-signing by SBU Credit ";
    final String newslettersLabel = "Newsletters";
    final String franchiseTeamLabel = "Franchise Team";
    final String marketingMaterialLabel  = "Marketing Material ";
    final String podcastsAndTestimonialVideosLabel = "Podcasts and Testimonial Videos";
    final String fuelAndRentalGuaranteesLabel = "Fuel and Rental Guarantees";
    final String franchiseEventsLabel = "Franchise Events";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ clientValuePropositionsLabel +"']")
    public WebElement clientValuePropositions;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ CoSigningBySBUCreditLabel +"']")
    public WebElement CoSigningBySBUCredit;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ newslettersLabel +"']")
    public WebElement newsletters;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ franchiseTeamLabel +"']")
    public WebElement franchiseTeam;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ marketingMaterialLabel +"']")
    public WebElement marketingMaterial;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ podcastsAndTestimonialVideosLabel +"']")
    public WebElement podcastsAndTestimonialVideos;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ fuelAndRentalGuaranteesLabel +"']")
    public WebElement fuelAndRentalGuarantees;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ franchiseEventsLabel +"']")
    public WebElement franchiseEvents;

    public Franchising(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getClientValuePropositions() {
        businessBankingHelper.verifyAndClickElement( clientValuePropositions, clientValuePropositionsLabel);
    }
    public void getCoSigningBySBUCredit() {
        businessBankingHelper.verifyAndClickElement( CoSigningBySBUCredit, CoSigningBySBUCreditLabel);
    }
    public void getNewsletters() {
        businessBankingHelper.verifyAndClickElement( newsletters, newslettersLabel);
    }
    public void getFranchiseTeam() {
        businessBankingHelper.verifyAndClickElement( franchiseTeam, franchiseTeamLabel);
    }
    public void getMarketingMaterial() {
        businessBankingHelper.verifyAndClickElement( marketingMaterial, marketingMaterialLabel);
    }
    public void getPodcastsAndTestimonialVideos() {
        businessBankingHelper.verifyAndClickElement( podcastsAndTestimonialVideos, podcastsAndTestimonialVideosLabel);
    }
    public void getFuelAndRentalGuarantees() {
        businessBankingHelper.verifyAndClickElement( fuelAndRentalGuarantees, fuelAndRentalGuaranteesLabel);
    }
    public void getFranchiseEvents() {
        businessBankingHelper.verifyAndClickElement( franchiseEvents, franchiseEventsLabel);
    }

}
