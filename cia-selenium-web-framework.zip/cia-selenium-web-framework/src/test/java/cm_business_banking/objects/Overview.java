package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Overview {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String publicSectorOverviewLabel = "Public Sector Overview";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ publicSectorOverviewLabel +"']")
    public WebElement publicSectorOverview;

    public Overview(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getPublicSectorOverview() {
        businessBankingHelper.verifyAndClickElement( publicSectorOverview, publicSectorOverviewLabel);
    }
    public void verifyPublicSectorOverview()  {
        businessBankingHelper.verifyPage(publicSectorOverviewLabel, publicSectorOverview);
        businessBankingHelper.takeSnapShot(publicSectorOverviewLabel+" Page");
    }
}
