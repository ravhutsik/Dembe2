package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import cm_utils.DriverFactory;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class HomePageObject {

    private final WebDriver driver;
    public String businessBankingURL = "http://biscorpmemqa/BB/Home";
    BusinessBankingHelper businessBankingHelper = new BusinessBankingHelper(DriverFactory.getDriver(businessBankingURL));


    @FindBy(how = How.XPATH, using = "//*[@id=\"CategoriesDiv\"]/a[1]/div/div[4]/label")
    public WebElement biggerPictureElement;

    @FindBy(how = How.XPATH, using = "//*[@id=\"CategoriesDiv\"]/a[2]/div/div[4]/label")
    public WebElement coreBankingSolution;

    @FindBy(how = How.XPATH, using = "//*[@id=\"CategoriesDiv\"]/a[3]/div/div[4]/label")
    public WebElement enterpriseRiskGovernanceAndManagement;

    @FindBy(how = How.XPATH, using = "//*[@id=\"CategoriesDiv\"]/a[4]/div/div[4]/label")
    public WebElement credit;

    @FindBy(how = How.XPATH, using = "//*[@id=\"CategoriesDiv\"]/a[5]/div/div[4]/label")
    public WebElement specialisation;

    @FindBy(how = How.XPATH, using = "//*[@id=\"CategoriesDiv\"]/a[6]/div/div[4]/label")
    public WebElement products;

    @FindBy(how = How.XPATH, using = "//*[@id=\"CategoriesDiv\"]/a[7]/div/div[4]/label")
    public WebElement marketingCommunication;

    @FindBy(how = How.XPATH, using = "//*[@id=\"CategoriesDiv\"]/a[8]/div/div[4]/label")
    public WebElement learningAndDevelopment;

    @FindBy(how = How.XPATH, using = "//*[@id=\"CategoriesDiv\"]/a[9]/div/div[4]/label")
    public WebElement pricing;

    @FindBy(how = How.XPATH, using = "//*[@id=\"CategoriesDiv\"]/a[10]/div/div[4]/label")
    public WebElement managedEvolution;

    @FindBy(how = How.XPATH, using = "//*[@id=\"CategoriesDiv\"]/a[11]/div/div[4]/label")
    public WebElement moreCategories;

    @FindBy(how = How.XPATH, using = "//*[@id=\"CategoriesDiv\"]/a[12]/div/div[4]/label")
    public WebElement topLevelCategory;


    public HomePageObject(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void getBiggerPictureElement() {
         businessBankingHelper.clickElement(biggerPictureElement);
    }

    public void getCoreBankingSolution() {
        businessBankingHelper.clickElement(coreBankingSolution) ;
    }

    public void getEnterpriseRiskGovernanceAndManagement() {
        businessBankingHelper.clickElement(enterpriseRiskGovernanceAndManagement);
    }

    public void getCredit() {
        businessBankingHelper.clickElement(credit);
    }

    public void getSpecialisation() {
        businessBankingHelper.clickElement(specialisation);
    }

    public void getProducts() {
        businessBankingHelper.clickElement(products);
    }

    public void getMarketingCommunication() {
        businessBankingHelper.clickElement(marketingCommunication);
    }

    public void getLearningAndDevelopment() {
        businessBankingHelper.clickElement(learningAndDevelopment);
    }

    public void getPricing() {
        businessBankingHelper.clickElement(pricing);
    }

    public void getManagedEvolution() {
        businessBankingHelper.clickElement(managedEvolution);
    }

    public void getMoreCategories() {
        businessBankingHelper.clickElement(moreCategories);
    }

    public void getTopLevelCategory() {
        businessBankingHelper.clickElement(topLevelCategory);
    }



}
