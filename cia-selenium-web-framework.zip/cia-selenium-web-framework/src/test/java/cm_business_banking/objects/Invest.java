package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class Invest {


    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String NoticeDepositLabel = "Notice Deposit";
    final String TermDepositLabel = "Term Deposit";
    final String CallAccountLabel = "Call Account";

    String [] NoticeDeposit = {"Notice deposit cheatsheet","Investments Training Presentation","Investment client presentation"};
    String [] TermDeposit  = {"Term deposit cheatsheet","Investments Training Presentation","Investment client presentation"};
    String [] CallAccount  = {"Call account cheatsheet","Investments Training Presentation","Investment client presentation"};

    public Invest(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getNoticeDeposit() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(NoticeDepositLabel), NoticeDepositLabel);
        businessBankingHelper.performOperation(NoticeDeposit);
    }

    public void getTermDeposit() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(TermDepositLabel), TermDepositLabel);
        businessBankingHelper.performOperation(TermDeposit);
    }

    public void getCallAccount() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(CallAccountLabel), CallAccountLabel);
        businessBankingHelper.performOperation(CallAccount);
    }

}
