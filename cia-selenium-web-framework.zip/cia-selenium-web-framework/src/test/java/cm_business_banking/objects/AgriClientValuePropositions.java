package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class AgriClientValuePropositions {
    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String primaryAgricultureClientValuePropositionLabel = "Primary Agriculture Client Value Proposition";
    final String secondaryAgricultureClientValuePropositionLabel = "Primary Agriculture Client Value Proposition";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ primaryAgricultureClientValuePropositionLabel +"']")
    public WebElement primaryAgricultureClientValueProposition;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ secondaryAgricultureClientValuePropositionLabel +"']")
    public WebElement secondaryAgricultureClientValueProposition;

    public AgriClientValuePropositions(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getPrimaryAgricultureClientValueProposition() {
        businessBankingHelper.verifyAndClickElement( primaryAgricultureClientValueProposition, primaryAgricultureClientValuePropositionLabel);
    }

    public void getSecondaryAgricultureClientValueProposition() {
        businessBankingHelper.verifyAndClickElement( secondaryAgricultureClientValueProposition, secondaryAgricultureClientValuePropositionLabel);
    }

}
