package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class MarketingMaterial {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String franchiseBrochureLabel = "Franchise Brochure";
    final String franchiseLeafletLabel = "Franchise Leaflet";
    final String financingRenewableEnergyLabel = "Financing Renewable Energy";
    final String consumerProtectionLabel = "Consumer Protection: Know your rights";
    final String franchiseBrochureAutomotiveLabel = "Franchise Brochure - Automotive";
    final String franchiseBrochureFuelLabel = "Franchise Brochure - Fuel ";
    final String infographicLabel = "Infographic - How to apply for franchise finance";
    final String GAPAccessBrochureLabel = "GAP Access Brochure";
    final String marketEdgeBrochureLabel = "Market Edge Brochure";
    final String franchiseBrochureRetailLabel = "Franchise Brochure - Retail";
    final String whatIsFranchisingLabel = "What is franchising?";

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ franchiseBrochureLabel +"']")
    public WebElement franchiseBrochure;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ franchiseLeafletLabel +"']")
    public WebElement franchiseLeaflet;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ financingRenewableEnergyLabel +"']")
    public WebElement financingRenewableEnergy;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ consumerProtectionLabel +"']")
    public WebElement consumerProtection;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ franchiseBrochureAutomotiveLabel +"']")
    public WebElement franchiseBrochureAutomotive;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ franchiseBrochureFuelLabel +"']")
    public WebElement franchiseBrochureFuel;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ infographicLabel +"']")
    public WebElement infographic;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ GAPAccessBrochureLabel +"']")
    public WebElement GAPAccessBrochure;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ marketEdgeBrochureLabel +"']")
    public WebElement marketEdgeBrochure;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ franchiseBrochureRetailLabel +"']")
    public WebElement franchiseBrochureRetail;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ whatIsFranchisingLabel +"']")
    public WebElement whatIsFranchising;

    public MarketingMaterial(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getFranchiseBrochure() {
        businessBankingHelper.verifyAndClickElement( franchiseBrochure, franchiseBrochureLabel);
    }
    public void verifyFranchiseBrochure()  {
        businessBankingHelper.verifyPage(franchiseBrochureLabel, franchiseBrochure);
        businessBankingHelper.takeSnapShot(franchiseBrochureLabel +" Page");
    }
    public void getFranchiseLeaflet() {
        businessBankingHelper.verifyAndClickElement( franchiseLeaflet, franchiseLeafletLabel);
    }
    public void verifyFranchiseLeaflet()  {
        businessBankingHelper.verifyPage(franchiseLeafletLabel, franchiseLeaflet);
        businessBankingHelper.takeSnapShot(franchiseLeafletLabel +" Page");
    }
    public void getFinancingRenewableEnergy() {
        businessBankingHelper.verifyAndClickElement( financingRenewableEnergy, financingRenewableEnergyLabel);
    }
    public void verifyFinancingRenewableEnergy()  {
        businessBankingHelper.verifyPage(financingRenewableEnergyLabel, financingRenewableEnergy);
        businessBankingHelper.takeSnapShot(financingRenewableEnergyLabel +" Page");
    }
    public void getConsumerProtection() {
        businessBankingHelper.verifyAndClickElement(consumerProtection, consumerProtectionLabel);
    }
    public void verifyConsumerProtection()  {
        businessBankingHelper.verifyPage(consumerProtectionLabel, consumerProtection);
        businessBankingHelper.takeSnapShot(consumerProtectionLabel +" Page");
    }
    public void getFranchiseBrochureAutomotive() {
        businessBankingHelper.verifyAndClickElement( franchiseBrochureAutomotive, franchiseBrochureAutomotiveLabel);
    }
    public void verifyFranchiseBrochureAutomotive()  {
        businessBankingHelper.verifyPage(franchiseBrochureAutomotiveLabel, franchiseBrochureAutomotive);
        businessBankingHelper.takeSnapShot(franchiseBrochureAutomotiveLabel +" Page");
    }
    public void getFranchiseBrochureFuel() {
        businessBankingHelper.verifyAndClickElement(franchiseBrochureFuel, franchiseBrochureFuelLabel);
    }
    public void verifyFranchiseBrochureFuel()  {
        businessBankingHelper.verifyPage(franchiseBrochureFuelLabel, franchiseBrochureFuel);
        businessBankingHelper.takeSnapShot(franchiseBrochureFuelLabel +" Page");
    }
    public void getInfographic() {
        businessBankingHelper.verifyAndClickElement( infographic, infographicLabel);
    }
    public void verifyInfographic()  {
        businessBankingHelper.verifyPage(infographicLabel, infographic);
        businessBankingHelper.takeSnapShot(infographicLabel +" Page");
    }
    public void getGAPAccessBrochure() {
        businessBankingHelper.verifyAndClickElement(GAPAccessBrochure, GAPAccessBrochureLabel);
    }
    public void verifyGAPAccessBrochure()  {
        businessBankingHelper.verifyPage(GAPAccessBrochureLabel, GAPAccessBrochure);
        businessBankingHelper.takeSnapShot(GAPAccessBrochureLabel +" Page");
    }
    public void getMarketEdgeBrochure() {
        businessBankingHelper.verifyAndClickElement(marketEdgeBrochure, marketEdgeBrochureLabel);
    }
    public void verifyMarketEdgeBrochure()  {
        businessBankingHelper.verifyPage(marketEdgeBrochureLabel, marketEdgeBrochure);
        businessBankingHelper.takeSnapShot(marketEdgeBrochureLabel +" Page");
    }
    public void getFranchiseBrochureRetail() {
        businessBankingHelper.verifyAndClickElement(franchiseBrochureRetail, franchiseBrochureRetailLabel);
    }
    public void verifyFranchiseBrochureRetail()  {
        businessBankingHelper.verifyPage(franchiseBrochureRetailLabel, franchiseBrochureRetail);
        businessBankingHelper.takeSnapShot(franchiseBrochureRetailLabel +" Page");
    }
    public void getWhatIsFranchising() {
        businessBankingHelper.verifyAndClickElement(whatIsFranchising, whatIsFranchisingLabel);
    }
    public void verifyWhatIsFranchising()  {
        businessBankingHelper.verifyPage(whatIsFranchisingLabel, whatIsFranchising);
        businessBankingHelper.takeSnapShot(whatIsFranchisingLabel +" Page");
    }
}
