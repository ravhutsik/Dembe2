package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Automotive {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String goldwagenLabel = "Goldwagen";
    final String kwikFitLabel = "Kwik-Fit";
    final String mandarinPartsLabel = "Mandarin Parts";
    final String tyremartLabel = "Tyremart";
    final String HiQLabel = "Hi-Q";
    final String tigerWheelAndTyreLabel = "Tiger Wheel and Tyre";
    final String tyrePlusLabel = "Tyre Plus";
    final String tyresAndMoreLabel = "Tyres and More";
    final String pointsLabel = "POINT S";
    final String carServiceCityLabel = "Car Service City";

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ goldwagenLabel +"']")
    public WebElement goldwagen;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ kwikFitLabel +"']")
    public WebElement kwikFit;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ mandarinPartsLabel +"']")
    public WebElement mandarinParts;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ tyremartLabel +"']")
    public WebElement tyremart;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ HiQLabel +"']")
    public WebElement HiQ;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ tigerWheelAndTyreLabel +"']")
    public WebElement tigerWheelAndTyre;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ tyrePlusLabel +"']")
    public WebElement tyrePlus;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ tyresAndMoreLabel +"']")
    public WebElement tyresAndMore;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ pointsLabel +"']")
    public WebElement points;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ carServiceCityLabel +"']")
    public WebElement carServiceCity;

    public Automotive(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getGoldwagen() {
        businessBankingHelper.verifyAndClickElement( goldwagen, goldwagenLabel);
    }
    public void verifyGoldwagen()  {
        businessBankingHelper.verifyPage(goldwagenLabel, goldwagen);
        businessBankingHelper.takeSnapShot(goldwagenLabel+" Page");
    }
    public void getKwikFit() {
        businessBankingHelper.verifyAndClickElement( kwikFit, kwikFitLabel);
    }
    public void verifyKwikFit()  {
        businessBankingHelper.verifyPage(kwikFitLabel, kwikFit);
        businessBankingHelper.takeSnapShot(kwikFitLabel+" Page");
    }
    public void getMandarinParts() {
        businessBankingHelper.verifyAndClickElement( mandarinParts, mandarinPartsLabel);
    }
    public void verifyMandarinParts()  {
        businessBankingHelper.verifyPage(mandarinPartsLabel, mandarinParts);
        businessBankingHelper.takeSnapShot(mandarinPartsLabel+" Page");
    }
    public void getTyremart() {
        businessBankingHelper.verifyAndClickElement( tyremart, tyremartLabel);
    }
    public void verifyTyremart()  {
        businessBankingHelper.verifyPage(tyremartLabel, tyremart);
        businessBankingHelper.takeSnapShot(tyremartLabel+" Page");
    }
    public void getHiQ() {
        businessBankingHelper.verifyAndClickElement( HiQ, HiQLabel);
    }
    public void verifyHiQ()  {
        businessBankingHelper.verifyPage(HiQLabel, HiQ);
        businessBankingHelper.takeSnapShot(HiQLabel+" Page");
    }
    public void getTigerWheelAndTyre() {
        businessBankingHelper.verifyAndClickElement( tigerWheelAndTyre, tigerWheelAndTyreLabel);
    }
    public void verifyTigerWheelAndTyre()  {
        businessBankingHelper.verifyPage(tigerWheelAndTyreLabel, tigerWheelAndTyre);
        businessBankingHelper.takeSnapShot(tigerWheelAndTyreLabel+" Page");
    }
    public void getTyrePlus() {
        businessBankingHelper.verifyAndClickElement( tyrePlus, tyrePlusLabel);
    }
    public void verifyTyrePlus()  {
        businessBankingHelper.verifyPage(tyrePlusLabel, tyrePlus);
        businessBankingHelper.takeSnapShot(tyrePlusLabel+" Page");
    }
    public void getTyresAndMore() {
        businessBankingHelper.verifyAndClickElement( tyresAndMore, tyresAndMoreLabel);
    }
    public void verifyTyresAndMore()  {
        businessBankingHelper.verifyPage(tyresAndMoreLabel, tyresAndMore);
        businessBankingHelper.takeSnapShot(tyresAndMoreLabel+" Page");
    }
    public void getPoints() {
        businessBankingHelper.verifyAndClickElement( points, pointsLabel);
    }
    public void verifyPoints()  {
        businessBankingHelper.verifyPage(pointsLabel, points);
        businessBankingHelper.takeSnapShot(pointsLabel +" Page");
    }
    public void getCarServiceCity() {
        businessBankingHelper.verifyAndClickElement( carServiceCity, carServiceCityLabel);
    }
    public void verifyCarServiceCity()  {
        businessBankingHelper.verifyPage(carServiceCityLabel, carServiceCity);
        businessBankingHelper.takeSnapShot(carServiceCityLabel+" Page");
    }
}
