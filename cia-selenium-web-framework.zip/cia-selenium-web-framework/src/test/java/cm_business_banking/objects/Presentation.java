package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Presentation {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String sustainableDevelopmentGoalsLabel = "Sustainable Development Goals (SDG'S)";
    final String financingSustainableSolutionsInternalGuideLabel = "Financing Sustainable Solutions - Internal guide";
    final String sustainableSolutionsClientDocumentLabel = "Sustainable Solutions Client Document";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ sustainableDevelopmentGoalsLabel +"']")
    public WebElement sustainableDevelopmentGoals;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ financingSustainableSolutionsInternalGuideLabel +"']")
    public WebElement financingSustainableSolutionsInternalGuide;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ sustainableSolutionsClientDocumentLabel +"']")
    public WebElement sustainableSolutionsClientDocument;

    public Presentation(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getSustainableDevelopmentGoals() {
        businessBankingHelper.verifyAndClickElement( sustainableDevelopmentGoals, sustainableDevelopmentGoalsLabel);
    }
    public void verifySustainableDevelopmentGoals()  {
        businessBankingHelper.verifyPage(sustainableDevelopmentGoalsLabel, sustainableDevelopmentGoals);
        businessBankingHelper.takeSnapShot(sustainableDevelopmentGoalsLabel+" Page");
    }
    public void getFinancingSustainableSolutionsInternalGuide() {
        businessBankingHelper.verifyAndClickElement( financingSustainableSolutionsInternalGuide, financingSustainableSolutionsInternalGuideLabel);
    }
    public void verifyFinancingSustainableSolutionsInternalGuide()  {
        businessBankingHelper.verifyPage(financingSustainableSolutionsInternalGuideLabel, financingSustainableSolutionsInternalGuide);
        businessBankingHelper.takeSnapShot(financingSustainableSolutionsInternalGuideLabel+" Page");
    }
    public void getSustainableSolutionsClientDocument() {
        businessBankingHelper.verifyAndClickElement( sustainableSolutionsClientDocument, sustainableSolutionsClientDocumentLabel);
    }
    public void verifySustainableSolutionsClientDocument()  {
        businessBankingHelper.verifyPage(sustainableSolutionsClientDocumentLabel, sustainableSolutionsClientDocument);
        businessBankingHelper.takeSnapShot(sustainableSolutionsClientDocumentLabel+" Page");
    }
}
