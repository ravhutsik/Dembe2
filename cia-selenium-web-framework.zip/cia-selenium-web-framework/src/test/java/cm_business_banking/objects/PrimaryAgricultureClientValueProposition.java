package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PrimaryAgricultureClientValueProposition {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String shadeNettingFinancingLabel = "Shade-netting Financing";
    final String NedbankAgriBusinessCVPLabel = "Nedbank Agri Business (Primary sector) CVP";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ shadeNettingFinancingLabel +"']")
    public WebElement shadeNettingFinancing;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ NedbankAgriBusinessCVPLabel +"']")
    public WebElement NedbankAgriBusinessCVP;

    public PrimaryAgricultureClientValueProposition(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getShadeNettingFinancing() {
        businessBankingHelper.verifyAndClickElement( shadeNettingFinancing, shadeNettingFinancingLabel);
    }
    public void verifyShadeNettingFinancing()  {
        businessBankingHelper.verifyPage(shadeNettingFinancingLabel, shadeNettingFinancing);
        businessBankingHelper.takeSnapShot(shadeNettingFinancingLabel +" Page");
    }
    public void getNedbankAgriBusinessCVP() {
        businessBankingHelper.verifyAndClickElement( NedbankAgriBusinessCVP, NedbankAgriBusinessCVPLabel);
    }
    public void verifyNedbankAgriBusinessCVP()  {
        businessBankingHelper.verifyPage(NedbankAgriBusinessCVPLabel, NedbankAgriBusinessCVP);
        businessBankingHelper.takeSnapShot(NedbankAgriBusinessCVPLabel +" Page");
    }
}
