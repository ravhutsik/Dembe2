package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class StrategyAndApproach {
    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String BBPurposeAndClientExperienceLabel = "BB Purpose and Client Experience ";
    final String BBValuePropositionLabel  = "BB Value Proposition";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BBPurposeAndClientExperienceLabel +"']")
    public WebElement BBPurposeAndClientExperience;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BBValuePropositionLabel +"']")
    public WebElement BBValueProposition;

    public StrategyAndApproach(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getBBPurposeAndClientExperience() {
        businessBankingHelper.verifyAndClickElement(BBPurposeAndClientExperience, BBPurposeAndClientExperienceLabel);
    }
    public void getBBValueProposition() {
        businessBankingHelper.verifyAndClickElement(BBValueProposition, BBValuePropositionLabel);
    }
    public void verifyAPurposeAndClientExperience()  {
        businessBankingHelper.verifyPage(BBPurposeAndClientExperienceLabel, BBPurposeAndClientExperience);
        businessBankingHelper.takeSnapShot(BBPurposeAndClientExperienceLabel+" Page");
    }
    public void verifyBBValueProposition()  {
        businessBankingHelper.verifyPage(BBValuePropositionLabel, BBValueProposition);
        businessBankingHelper.takeSnapShot(BBValuePropositionLabel+" Page");
    }
}
