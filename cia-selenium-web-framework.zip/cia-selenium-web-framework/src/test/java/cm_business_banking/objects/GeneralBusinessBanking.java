package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import cm_utils.DriverFactory;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class GeneralBusinessBanking {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;

    public final String DAY_TAKE_OVER_REPORT_label = "DAY TAKE OVER REPORT";
    public final String COMMON_FRAUD_DATABASE_CHECKLIST_Label = " COMMON FRAUD DATABASE CHECKLIST";
    public final String testing_Label = "Testing";
    public final String TN_Test_Video_Label= "TN Test Video 2503";
    public final String TIE_TEMPLATE_Label = "TIER 2 & 3 TEMPLATE";
    public final String PRECCA_REPORTING_TEMPLATE_Label = "PRECCA REPORTING TEMPLATE";
    public final String FACILITY_LETTERS_Label = "FACILITY LETTERS";
    public final String TN_Test_Audio_Label= "TN Test Audio 2503";
    public final String Handover_Checklist_Label = "Handover Checklist";

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ DAY_TAKE_OVER_REPORT_label +"']")
    public WebElement takeOverReport;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ COMMON_FRAUD_DATABASE_CHECKLIST_Label +"']")
    public WebElement commonFraudDBChecklist;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ testing_Label +"']")
    public WebElement testing;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ TN_Test_Video_Label +"']")
    public WebElement TN_Test_Video;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ TIE_TEMPLATE_Label +"']")
    public WebElement TIER_TEMPLATE;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ PRECCA_REPORTING_TEMPLATE_Label +"']")
    public WebElement PRECCA_REPORTING_TEMPLATE;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ FACILITY_LETTERS_Label +"']")
    public WebElement FACILITY_LETTERS;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ TN_Test_Audio_Label +"']")
    public WebElement  TN_Test_Audio;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ Handover_Checklist_Label +"']")
    public WebElement Handover_Checklist;



    public GeneralBusinessBanking(WebDriver driver) {
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void verifyDayTakeOverReportPage() throws Exception{
        businessBankingHelper.verifyPage(DAY_TAKE_OVER_REPORT_label, takeOverReport);
        businessBankingHelper.takeSnapShot(DAY_TAKE_OVER_REPORT_label+" Page");
    }

    public void verifyCommonFraudDatabaseChecklistPage()  throws Exception{
        businessBankingHelper.verifyPage(COMMON_FRAUD_DATABASE_CHECKLIST_Label, commonFraudDBChecklist);
        businessBankingHelper.takeSnapShot(COMMON_FRAUD_DATABASE_CHECKLIST_Label+" Page");       }

    public void verifyTestingPage()  throws Exception{
        businessBankingHelper.verifyPage(testing_Label, testing);
        businessBankingHelper.takeSnapShot(testing_Label+" Page");       }

    public void verifyTNTestVideoPage()  throws Exception{
        businessBankingHelper.verifyPage(TN_Test_Video_Label, TN_Test_Video);
        businessBankingHelper.takeSnapShot(TN_Test_Video_Label+" Page");       }

    public void verifyTieTemplatePage()  throws Exception{
        businessBankingHelper.verifyPage(TIE_TEMPLATE_Label, TIER_TEMPLATE);
        businessBankingHelper.takeSnapShot(TIE_TEMPLATE_Label+" Page");       }

    public void verifyPRECCAReportingTemplatePage() throws Exception {
        businessBankingHelper.verifyPage(PRECCA_REPORTING_TEMPLATE_Label, PRECCA_REPORTING_TEMPLATE);
        businessBankingHelper.takeSnapShot(PRECCA_REPORTING_TEMPLATE_Label+" Page");       }

    public void verifyFacilityLetterPage() throws Exception {
        businessBankingHelper.verifyPage(FACILITY_LETTERS_Label, FACILITY_LETTERS);
        businessBankingHelper.takeSnapShot(FACILITY_LETTERS_Label+" Page");       }

    public void verifyTNTestAudioPage() {
        try {
            businessBankingHelper.verifyPage(TN_Test_Audio_Label, TN_Test_Audio);
            businessBankingHelper.takeSnapShot(TN_Test_Audio_Label+" Page");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void verifyHandoverChecklistPage() throws Exception {
        businessBankingHelper.verifyPage(Handover_Checklist_Label, Handover_Checklist);
        businessBankingHelper.takeSnapShot(Handover_Checklist_Label+" Page");       }

    public void getTakeOverReport() {
        businessBankingHelper.verifyAndClickElement(DAY_TAKE_OVER_REPORT_label, takeOverReport, DAY_TAKE_OVER_REPORT_label);
    }

    public void getCommonFraudDBChecklist() {
        businessBankingHelper.verifyAndClickElement(COMMON_FRAUD_DATABASE_CHECKLIST_Label, commonFraudDBChecklist, COMMON_FRAUD_DATABASE_CHECKLIST_Label);
    }

    public void getTesting() {
        businessBankingHelper.verifyAndClickElement(testing_Label, testing, testing_Label);
    }

    public void getTN_Test_Video() {
        businessBankingHelper.verifyAndClickElement(TN_Test_Video_Label, TN_Test_Video, TN_Test_Video_Label);
    }

    public void getTIER_TEMPLATE() {
        businessBankingHelper.verifyAndClickElement(TIE_TEMPLATE_Label, TIER_TEMPLATE, TIE_TEMPLATE_Label);
    }

    public void getPRECCA_REPORTING_TEMPLATE() {
        businessBankingHelper.verifyAndClickElement(PRECCA_REPORTING_TEMPLATE_Label, PRECCA_REPORTING_TEMPLATE, PRECCA_REPORTING_TEMPLATE_Label);
    }

    public void getFACILITY_LETTERS() {
        businessBankingHelper.verifyAndClickElement(FACILITY_LETTERS_Label, FACILITY_LETTERS, FACILITY_LETTERS_Label);
    }

    public void getTN_Test_Audio() {
        businessBankingHelper.verifyAndClickElement(TN_Test_Audio_Label, TN_Test_Audio, TN_Test_Audio_Label);
    }
    public void getHandover_Checklist() {
        businessBankingHelper.verifyAndClickElement(Handover_Checklist_Label, Handover_Checklist, Handover_Checklist_Label);
    }
}
