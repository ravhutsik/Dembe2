package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Sustainability {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String presentationLabel = "Agriculture Team";
    final String marketingMaterialLabel = "Marketing Material";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ presentationLabel +"']")
    public WebElement presentation;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ marketingMaterialLabel +"']")
    public WebElement marketingMaterial;

    public Sustainability(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getPresentation() {
        businessBankingHelper.verifyAndClickElement( presentation, presentationLabel);
    }

    public void getMarketingMaterial() {
        businessBankingHelper.verifyAndClickElement( marketingMaterial, marketingMaterialLabel);
    }

}
