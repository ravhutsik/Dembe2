package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class TransactionalGlobal {


    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String CFCAccountLabel = "CFC Account";
    final String NedTreasuryLabel = "NedTreasury";
    final String ForexLabel = "Forex";
    final String GEMSLabel = "GEMS";

    String [] CFCAccount = {"Customer Foreign Currency Account TB Cheatsheet","CFC Training presentation"};
    String [] NedTreasury  = {"NedTreasury TB cheatsheet","NedTreasury training material","NedTreasury infographics"};
    String [] Forex  = {"Foreign Exchange Cheat sheet"};
    String[] GEMS = {"GEMS cheatsheet"};

    public TransactionalGlobal(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getCFCAccount() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(CFCAccountLabel), CFCAccountLabel);
        businessBankingHelper.performOperation(CFCAccount);
    }

    public void getNedTreasury() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(NedTreasuryLabel), NedTreasuryLabel);
        businessBankingHelper.performOperation(NedTreasury);
    }

    public void getForex() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(ForexLabel), ForexLabel);
        businessBankingHelper.performOperation(Forex);
    }
    public void getGEMS() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(GEMSLabel), GEMSLabel);
        businessBankingHelper.performOperation(GEMS);
    }

}
