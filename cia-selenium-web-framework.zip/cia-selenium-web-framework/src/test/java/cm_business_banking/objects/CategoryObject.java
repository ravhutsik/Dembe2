package cm_business_banking.objects;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class CategoryObject {

    private WebDriver driver;

    @FindBy(how = How.XPATH, using = "//*[@id=\"jsddm\"]/li[1]/a")
    public WebElement homeText;

    public CategoryObject (WebDriver driver){
        this.driver=driver;
        PageFactory.initElements(driver, this);
    }

    public void verifyPage() throws IOException {
        String text = homeText.getText();
        Assert.assertEquals("Home",text);
    }
}
