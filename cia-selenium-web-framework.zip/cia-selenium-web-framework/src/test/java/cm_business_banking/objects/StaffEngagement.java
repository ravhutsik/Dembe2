package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class StaffEngagement {
    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String StaffEngagementsFebMar2016Label = "Staff Engagements Feb/Mar 2016";
    final String BBStaffRoadshowsSeptember2015Label = "BB Staff Roadshows September 2015";
    final String bendHighPerformanceTeamsLabel = "Bend - High Performance Teams";
    final String BBRoadshowsAugust2015Label = "BB Roadshows August 2015";
    final String PhilipStaffConversationsLabel = "Philip's Staff Conversations";
    final String BBRoadshowsAugust2014Label = "BB Roadshows August 2014";
    final String BBRoadshowsAugust2013Label = "BB Roadshows August 2013";
    final String CikoRBBRoadshowLabel = "Ciko RBB Roadshow";
    final String SandileRoadshowsAugust2016Label = "Sandile's Roadshows August 2016";
    final String StaffEngagementSessionsLabel = "Staff Engagement sessions ";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ StaffEngagementsFebMar2016Label +"']")
    public WebElement StaffEngagementsFebMar2016;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BBStaffRoadshowsSeptember2015Label +"']")
    public WebElement BBStaffRoadshowsSeptember2015;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ bendHighPerformanceTeamsLabel +"']")
    public WebElement bendHighPerformanceTeams;


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BBRoadshowsAugust2015Label +"']")
    public WebElement BBRoadshowsAugust2015;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ PhilipStaffConversationsLabel +"']")
    public WebElement PhilipStaffConversations;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BBRoadshowsAugust2014Label +"']")
    public WebElement BBRoadshowsAugust2014;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BBRoadshowsAugust2013Label +"']")
    public WebElement BBRoadshowsAugust2013;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ CikoRBBRoadshowLabel +"']")
    public WebElement CikoRBBRoadshow;


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ SandileRoadshowsAugust2016Label +"']")
    public WebElement SandileRoadshowsAugust2016;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ StaffEngagementSessionsLabel +"']")
    public WebElement StaffEngagementSessions;



    public StaffEngagement(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getStaffEngagementsFebMar2016() {
        businessBankingHelper.verifyAndClickElement(StaffEngagementsFebMar2016, StaffEngagementsFebMar2016Label);
    }
    public void getBBStaffRoadshowsSeptember2015() {
        businessBankingHelper.verifyAndClickElement(BBStaffRoadshowsSeptember2015, BBStaffRoadshowsSeptember2015Label);
    }
    public void getbendHighPerformanceTeams() {
        businessBankingHelper.verifyAndClickElement(bendHighPerformanceTeams, bendHighPerformanceTeamsLabel);
    }
    public void getBBRoadshowsAugust2015() {
        businessBankingHelper.verifyAndClickElement(BBRoadshowsAugust2015, BBRoadshowsAugust2015Label);
    }
    public void getPhilipStaffConversations() {
        businessBankingHelper.verifyAndClickElement(PhilipStaffConversations, PhilipStaffConversationsLabel);
    }
    public void getBBRoadshowsAugust2014() {
        businessBankingHelper.verifyAndClickElement(BBRoadshowsAugust2014, BBRoadshowsAugust2014Label);
    }
    public void getBBRoadshowsAugust2013() {
        businessBankingHelper.verifyAndClickElement(BBRoadshowsAugust2013, BBRoadshowsAugust2013Label);
    }

    public void getCikoRBBRoadshow() {
        businessBankingHelper.verifyAndClickElement(CikoRBBRoadshow, CikoRBBRoadshowLabel);
    }

    public void getSandileRoadshowsAugust2016() {
        businessBankingHelper.verifyAndClickElement(SandileRoadshowsAugust2016, SandileRoadshowsAugust2016Label);
    }


    public void getStaffEngagementSessions() {
        businessBankingHelper.verifyAndClickElement(StaffEngagementSessions, StaffEngagementSessionsLabel);
    }

    public void verifyStaffEngagementsFebMar2016()  {
        businessBankingHelper.verifyPage(StaffEngagementsFebMar2016Label, StaffEngagementsFebMar2016);
        businessBankingHelper.takeSnapShot(StaffEngagementsFebMar2016Label +" Page");
    }
    public void verifyBBStaffRoadshowsSeptember2015()  {
        businessBankingHelper.verifyPage(BBStaffRoadshowsSeptember2015Label, BBStaffRoadshowsSeptember2015);
        businessBankingHelper.takeSnapShot(BBStaffRoadshowsSeptember2015Label +" Page");
    }
    public void verifybendHighPerformanceTeams()  {
        businessBankingHelper.verifyPage(bendHighPerformanceTeamsLabel, bendHighPerformanceTeams);
        businessBankingHelper.takeSnapShot(bendHighPerformanceTeamsLabel +" Page");
    }

    public void verifyBBRoadshowsAugust2015()  {
        businessBankingHelper.verifyPage(BBRoadshowsAugust2015Label, BBRoadshowsAugust2015);
        businessBankingHelper.takeSnapShot(BBRoadshowsAugust2015Label +" Page");
    }
    public void verifyPhilipStaffConversations()  {
        businessBankingHelper.verifyPage(PhilipStaffConversationsLabel, PhilipStaffConversations);
        businessBankingHelper.takeSnapShot(PhilipStaffConversationsLabel +" Page");
    }
    public void verifyBBRoadshowsAugust2014()  {
        businessBankingHelper.verifyPage(BBRoadshowsAugust2014Label, BBRoadshowsAugust2014);
        businessBankingHelper.takeSnapShot(BBRoadshowsAugust2014Label +" Page");
    } public void verifyBBRoadshowsAugust2013()  {
        businessBankingHelper.verifyPage(BBRoadshowsAugust2013Label, BBRoadshowsAugust2013);
        businessBankingHelper.takeSnapShot(BBRoadshowsAugust2013Label +" Page");
    }
    public void verifyCikoRBBRoadshow()  {
        businessBankingHelper.verifyPage(PhilipStaffConversationsLabel, PhilipStaffConversations);
        businessBankingHelper.takeSnapShot(PhilipStaffConversationsLabel +" Page");
    }
    public void verifySandileRoadshowsAugust2016()  {
        businessBankingHelper.verifyPage(SandileRoadshowsAugust2016Label, SandileRoadshowsAugust2016);
        businessBankingHelper.takeSnapShot(SandileRoadshowsAugust2016Label +" Page");
    }

    public void verifyStaffEngagementSessions()  {
        businessBankingHelper.verifyPage(StaffEngagementSessionsLabel, StaffEngagementSessions);
        businessBankingHelper.takeSnapShot(StaffEngagementSessionsLabel +" Page");
    }


}
