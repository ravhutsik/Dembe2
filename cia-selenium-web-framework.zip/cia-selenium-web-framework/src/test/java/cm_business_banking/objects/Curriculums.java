package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Curriculums {
    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String salesLabel = "Sales";
    final String creditLabel = "Credit";
    final String serviceLabel = "Service";
    final String leadershipLabel = "Leadership";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ salesLabel +"']")
    public WebElement sales;


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ creditLabel +"']")
    public WebElement credit;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ serviceLabel +"']")
    public WebElement service;


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ leadershipLabel +"']")
    public WebElement leadership;



    public Curriculums(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getSales() {
        businessBankingHelper.verifyAndClickElement(sales, salesLabel);
    }
    public void getCredit() {
        businessBankingHelper.verifyAndClickElement(credit, creditLabel);
    }
    public void getService() {
        businessBankingHelper.verifyAndClickElement(service, serviceLabel);
    }
    public void getLeadership() {
        businessBankingHelper.verifyAndClickElement(leadership, leadershipLabel);
    }


    public void verifySales()  {
        businessBankingHelper.verifyPage(salesLabel, sales);
        businessBankingHelper.takeSnapShot(salesLabel+" Page");
    }
    public void verifyCredit()  {
        businessBankingHelper.verifyPage(creditLabel, credit);
        businessBankingHelper.takeSnapShot(creditLabel+" Page");
    }
    public void verifyService()  {
        businessBankingHelper.verifyPage(serviceLabel, service);
        businessBankingHelper.takeSnapShot(serviceLabel+" Page");
    }
    public void verifyLeadership()  {
        businessBankingHelper.verifyPage(leadershipLabel, leadership);
        businessBankingHelper.takeSnapShot(leadershipLabel+" Page");
    }

}
