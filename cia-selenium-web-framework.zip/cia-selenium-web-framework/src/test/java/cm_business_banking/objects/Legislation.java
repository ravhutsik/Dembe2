package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Legislation {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String MFMALabel = "MFMA";
    final String municipalSystemsActLabel = "Municipal Systems Act 2000";
    final String PFMALabel = "PFMA";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ MFMALabel +"']")
    public WebElement MFMA;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ municipalSystemsActLabel +"']")
    public WebElement municipalSystemsAct;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ PFMALabel +"']")
    public WebElement PFMA;

    public Legislation(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getMFMA() {
        businessBankingHelper.verifyAndClickElement(MFMA, MFMALabel);
    }
    public void verifyMFMA()  {
        businessBankingHelper.verifyPage(MFMALabel, MFMA);
        businessBankingHelper.takeSnapShot(MFMALabel +" Page");
    }
    public void getFXDerivativesByNedbank() {
        businessBankingHelper.verifyAndClickElement(municipalSystemsAct, municipalSystemsActLabel);
    }
    public void verifyFXDerivativesByNedbank()  {
        businessBankingHelper.verifyPage(municipalSystemsActLabel, municipalSystemsAct);
        businessBankingHelper.takeSnapShot(municipalSystemsActLabel +" Page");
    }
    public void getPFMA() {
        businessBankingHelper.verifyAndClickElement(PFMA, PFMALabel);
    }
    public void verifyPFMA()  {
        businessBankingHelper.verifyPage(PFMALabel, PFMA);
        businessBankingHelper.takeSnapShot(PFMALabel +" Page");
    }
}
