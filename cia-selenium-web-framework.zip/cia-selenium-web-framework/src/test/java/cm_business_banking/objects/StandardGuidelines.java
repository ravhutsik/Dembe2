package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class StandardGuidelines {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String agricultureFinanceGuidelineLabel = "AGRICULTURE FINANCE GUIDELINE";
    final String autoReviewCreditStandardLabel = "AUTO REVIEW CREDIT STANDARD";
    final String capitalMovableAssetsSuppliersCreditStandardsLabel = "CAPITAL MOVABLE ASSETS SUPPLIERS CREDIT STANDARDS";
    final String creditRiskGuidelineLabel = "CREDIT RISK GUIDELINE";
    final String debtorManagementCreditStandardsLabel = "DEBTOR MANAGEMENT CREDIT STANDARDS";
    final String electronicBankingGuidelinesLabel = "ELECTRONIC BANKING GUIDELINES";
    final String emeraldCreditStandardsLabel = "EMERALD CREDIT STANDARDS";
    final String immovablePropertyValuationsStandardsLabel = "IMMOVABLE PROPERTY VALUATIONS STANDARDS";
    final String nationalCreditActCreditStandardsLabel = "NATIONAL CREDIT ACT (NCA) CREDIT STANDARDS ";
    final String perfectionOfNotarialBondProceduralGuidelineLabel = "PERFECTION OF NOTARIAL BOND PROCEDURAL GUIDELINE";
    final String publicSectorGuidelinesProcedureslabel = "PUBLIC SECTOR GUIDELINES & PROCEDURES";
    final String rentalDiscountingCreditStandardsLabel = "RENTAL DISCOUNTING CREDIT STANDARDS";
    final String socialAndEnvironmentalRiskCreditStandardsLabel = "SOCIAL AND ENVIRONMENTAL RISK CREDIT STANDARDS";
    final String specialisedFinanceCreditStandardsLabel = "SPECIALISED FINANCE CREDIT STANDARDS";
    final String stockFinanceCreditStandardLabel = "STOCK FINANCE CREDIT STANDARD";
    final String timberFinanceCreditStandardLabel = "TIMBER FINANCE CREDIT STANDARD";
    final String tradeFinanceCreditStandardLabel = "TRADE FINANCE CREDIT STANDARD";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ agricultureFinanceGuidelineLabel +"']")
    public WebElement agricultureFinanceGuideline;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ autoReviewCreditStandardLabel +"']")
    public WebElement autoReviewCreditStandard;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ capitalMovableAssetsSuppliersCreditStandardsLabel +"']")
    public WebElement capitalMovableAssetsSuppliersCreditStandards;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ creditRiskGuidelineLabel +"']")
    public WebElement creditRiskGuideline;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ debtorManagementCreditStandardsLabel +"']")
    public WebElement debtorManagementCreditStandards;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ electronicBankingGuidelinesLabel +"']")
    public WebElement electronicBankingGuidelines;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ emeraldCreditStandardsLabel +"']")
    public WebElement emeraldCreditStandards;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ immovablePropertyValuationsStandardsLabel +"']")
    public WebElement immovablePropertyValuationsStandards;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ nationalCreditActCreditStandardsLabel +"']")
    public WebElement nationalCreditActCreditStandards;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ perfectionOfNotarialBondProceduralGuidelineLabel +"']")
    public WebElement perfectionOfNotarialBondProceduralGuideline;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ publicSectorGuidelinesProcedureslabel +"']")
    public WebElement publicSectorGuidelinesProcedures;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ rentalDiscountingCreditStandardsLabel +"']")
    public WebElement rentalDiscountingCreditStandards;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ socialAndEnvironmentalRiskCreditStandardsLabel +"']")
    public WebElement socialAndEnvironmentalRiskCreditStandards;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ specialisedFinanceCreditStandardsLabel +"']")
    public WebElement specialisedFinanceCreditStandards;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ stockFinanceCreditStandardLabel +"']")
    public WebElement stockFinanceCreditStandard;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ timberFinanceCreditStandardLabel +"']")
    public WebElement timberFinanceCreditStandard;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ tradeFinanceCreditStandardLabel +"']")
    public WebElement tradeFinanceCreditStandard;


    public StandardGuidelines(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getAgricultureFinanceGuideline() {
        businessBankingHelper.verifyAndClickElement( agricultureFinanceGuideline, agricultureFinanceGuidelineLabel);
    }
    public void verifyAgricultureFinanceGuideline()  {
        businessBankingHelper.verifyPage(agricultureFinanceGuidelineLabel, agricultureFinanceGuideline);
        businessBankingHelper.takeSnapShot(agricultureFinanceGuidelineLabel+" Page");
    }

    public void getAutoReviewCreditStandard() {
        businessBankingHelper.verifyAndClickElement( autoReviewCreditStandard, autoReviewCreditStandardLabel);
    }
    public void verifyAutoReviewCreditStandard()  {
        businessBankingHelper.verifyPage(autoReviewCreditStandardLabel, autoReviewCreditStandard);
        businessBankingHelper.takeSnapShot(autoReviewCreditStandardLabel+" Page");
    }

    public void getCapitalMovableAssetsSuppliersCreditStandards() {
        businessBankingHelper.verifyAndClickElement( capitalMovableAssetsSuppliersCreditStandards, capitalMovableAssetsSuppliersCreditStandardsLabel
        );
    }
    public void verifyCapitalMovableAssetsSuppliersCreditStandards()  {
        businessBankingHelper.verifyPage(capitalMovableAssetsSuppliersCreditStandardsLabel, capitalMovableAssetsSuppliersCreditStandards);
        businessBankingHelper.takeSnapShot(capitalMovableAssetsSuppliersCreditStandardsLabel+" Page");
    }

    public void getCreditRiskGuideline() {
        businessBankingHelper.verifyAndClickElement( creditRiskGuideline, creditRiskGuidelineLabel
        );
    }
    public void verifyCreditRiskGuideline()  {
        businessBankingHelper.verifyPage(creditRiskGuidelineLabel, creditRiskGuideline);
        businessBankingHelper.takeSnapShot(creditRiskGuidelineLabel+" Page");
    }


    public void getDebtorManagementCreditStandards() {
        businessBankingHelper.verifyAndClickElement( debtorManagementCreditStandards, debtorManagementCreditStandardsLabel
        );
    }
    public void verifyDebtorManagementCreditStandards()  {
        businessBankingHelper.verifyPage(debtorManagementCreditStandardsLabel, debtorManagementCreditStandards);
        businessBankingHelper.takeSnapShot(debtorManagementCreditStandardsLabel+" Page");
    }


    public void getElectronicBankingGuidelines() {
        businessBankingHelper.verifyAndClickElement( electronicBankingGuidelines, electronicBankingGuidelinesLabel
        );
    }
    public void verifyElectronicBankingGuidelines()  {
        businessBankingHelper.verifyPage(electronicBankingGuidelinesLabel, electronicBankingGuidelines);
        businessBankingHelper.takeSnapShot(electronicBankingGuidelinesLabel+" Page");
    }

    public void getEmeraldCreditStandards() {
        businessBankingHelper.verifyAndClickElement( emeraldCreditStandards, emeraldCreditStandardsLabel
        );
    }
    public void verifyEmeraldCreditStandards()  {
        businessBankingHelper.verifyPage(emeraldCreditStandardsLabel, emeraldCreditStandards);
        businessBankingHelper.takeSnapShot(emeraldCreditStandardsLabel+" Page");
    }

    public void getImmovablePropertyValuationsStandards() {
        businessBankingHelper.verifyAndClickElement( immovablePropertyValuationsStandards, immovablePropertyValuationsStandardsLabel
        );
    }
    public void verifyImmovablePropertyValuationsStandards()  {
        businessBankingHelper.verifyPage(immovablePropertyValuationsStandardsLabel, immovablePropertyValuationsStandards);
        businessBankingHelper.takeSnapShot(immovablePropertyValuationsStandardsLabel+" Page");
    }

    public void getNationalCreditActCreditStandards() {
        businessBankingHelper.verifyAndClickElement( nationalCreditActCreditStandards, nationalCreditActCreditStandardsLabel
        );
    }
    public void verifyNationalCreditActCreditStandards()  {
        businessBankingHelper.verifyPage(nationalCreditActCreditStandardsLabel, nationalCreditActCreditStandards);
        businessBankingHelper.takeSnapShot(nationalCreditActCreditStandardsLabel+" Page");
    }

    public void getPerfectionOfNotarialBondProceduralGuideline() {
        businessBankingHelper.verifyAndClickElement( perfectionOfNotarialBondProceduralGuideline, perfectionOfNotarialBondProceduralGuidelineLabel
        );
    }
    public void verifyPerfectionOfNotarialBondProceduralGuideline()  {
        businessBankingHelper.verifyPage(perfectionOfNotarialBondProceduralGuidelineLabel, perfectionOfNotarialBondProceduralGuideline);
        businessBankingHelper.takeSnapShot(perfectionOfNotarialBondProceduralGuidelineLabel+" Page");
    }

    public void getPublicSectorGuidelinesProcedures() {
        businessBankingHelper.verifyAndClickElement( publicSectorGuidelinesProcedures, publicSectorGuidelinesProcedureslabel
        );
    }
    public void verifyPublicSectorGuidelinesProcedures()  {
        businessBankingHelper.verifyPage(publicSectorGuidelinesProcedureslabel, publicSectorGuidelinesProcedures);
        businessBankingHelper.takeSnapShot(publicSectorGuidelinesProcedureslabel+" Page");
    }

    public void getRentalDiscountingCreditStandards() {
        businessBankingHelper.verifyAndClickElement( rentalDiscountingCreditStandards, rentalDiscountingCreditStandardsLabel
        );
    }
    public void verifyRentalDiscountingCreditStandards()  {
        businessBankingHelper.verifyPage(rentalDiscountingCreditStandardsLabel, rentalDiscountingCreditStandards);
        businessBankingHelper.takeSnapShot(rentalDiscountingCreditStandardsLabel+" Page");
    }

    public void getSocialAndEnvironmentalRiskCreditStandards() {
        businessBankingHelper.verifyAndClickElement( socialAndEnvironmentalRiskCreditStandards, socialAndEnvironmentalRiskCreditStandardsLabel
        );
    }
    public void verifySocialAndEnvironmentalRiskCreditStandards()  {
        businessBankingHelper.verifyPage(socialAndEnvironmentalRiskCreditStandardsLabel, socialAndEnvironmentalRiskCreditStandards);
        businessBankingHelper.takeSnapShot(socialAndEnvironmentalRiskCreditStandardsLabel+" Page");
    }

    public void getSpecialisedFinanceCreditStandards() {
        businessBankingHelper.verifyAndClickElement( specialisedFinanceCreditStandards, specialisedFinanceCreditStandardsLabel
        );
    }
    public void verifySpecialisedFinanceCreditStandards()  {
        businessBankingHelper.verifyPage(specialisedFinanceCreditStandardsLabel, specialisedFinanceCreditStandards);
        businessBankingHelper.takeSnapShot(specialisedFinanceCreditStandardsLabel+" Page");
    }

    public void getStockFinanceCreditStandard() {
        businessBankingHelper.verifyAndClickElement( stockFinanceCreditStandard, stockFinanceCreditStandardLabel
        );
    }
    public void verifyStockFinanceCreditStandard()  {
        businessBankingHelper.verifyPage(stockFinanceCreditStandardLabel, stockFinanceCreditStandard);
        businessBankingHelper.takeSnapShot(stockFinanceCreditStandardLabel+" Page");
    }
   public void getTimberFinanceCreditStandard() {
        businessBankingHelper.verifyAndClickElement( timberFinanceCreditStandard, timberFinanceCreditStandardLabel
        );
    }
    public void verifyTimberFinanceCreditStandard()  {
        businessBankingHelper.verifyPage(timberFinanceCreditStandardLabel, timberFinanceCreditStandard);
        businessBankingHelper.takeSnapShot(timberFinanceCreditStandardLabel+" Page");
    }

   public void getTradeFinanceCreditStandard() {
        businessBankingHelper.verifyAndClickElement( tradeFinanceCreditStandard, tradeFinanceCreditStandardLabel
        );
    }
    public void verifyTradeFinanceCreditStandard()  {
        businessBankingHelper.verifyPage(tradeFinanceCreditStandardLabel, tradeFinanceCreditStandard);
        businessBankingHelper.takeSnapShot(tradeFinanceCreditStandardLabel+" Page");
    }
}
