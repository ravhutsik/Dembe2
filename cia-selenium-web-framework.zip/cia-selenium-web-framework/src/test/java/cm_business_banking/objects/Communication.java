package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Communication {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String bedreshKeyCommunicationsLabel = "BEDRESHS KEY COMMUNICATIONS";
    final String auditConfirmationLabel = "AUDIT CONFIRMATION";
    final String NCANationalCreditActLabel = "NCA_National Credit Act";
    final String creditSystemsLabel = "Credit Systems";
    final String generalLabel = "General";
    final String policyProceduresLabel = "POLICY & PROCEDURES";
    final String archiveLabel = "Archive";
    final String BBProductCommunicationsLabel = "BB PRODUCT COMMUNICATIONS";

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ bedreshKeyCommunicationsLabel +"']")
    public WebElement bedreshKeyCommunications;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ auditConfirmationLabel +"']")
    public WebElement auditConfirmation;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ NCANationalCreditActLabel +"']")
    public WebElement NCANationalCreditAct;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ creditSystemsLabel +"']")
    public WebElement creditSystems;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ generalLabel +"']")
    public WebElement general;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ policyProceduresLabel +"']")
    public WebElement policyProcedures;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ archiveLabel +"']")
    public WebElement archive;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BBProductCommunicationsLabel +"']")
    public WebElement BBProductCommunications;

    public Communication(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getBedreshKeyCommunications() {
        businessBankingHelper.verifyAndClickElement( bedreshKeyCommunications, bedreshKeyCommunicationsLabel);
    }

    public void getAuditConfirmation() {
        businessBankingHelper.verifyAndClickElement( auditConfirmation, auditConfirmationLabel);
    }

    public void getNCANationalCreditAct() {
        businessBankingHelper.verifyAndClickElement( NCANationalCreditAct, NCANationalCreditActLabel);
    }

    public void getCreditSystems() {
        businessBankingHelper.verifyAndClickElement( creditSystems, creditSystemsLabel);
    }

    public void getGeneral() {
        businessBankingHelper.verifyAndClickElement( general, generalLabel);
    }

    public void getPolicyProcedures() {
        businessBankingHelper.verifyAndClickElement( policyProcedures, policyProceduresLabel);
    }

    public void getArchive() {
        businessBankingHelper.verifyAndClickElement( archive, archiveLabel);
    }

    public void getBBProductCommunications() {
        businessBankingHelper.verifyAndClickElement( BBProductCommunications, BBProductCommunicationsLabel);
    }

}
