package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class TransactionalCAAndEB {


    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String currentAccountLabel = "Current Account";
    final String AVSLabel = "AVS";
    final String eStatementsLabel = "e-Statements";
    final String NotifcationsLabel = "Notifcations";
    final String NBBLabel = "NBB";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ currentAccountLabel +"']")
    public WebElement currentAccount;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ AVSLabel +"']")
    public WebElement AVS;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ eStatementsLabel +"']")
    public WebElement eStatements;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ NotifcationsLabel +"']")
    public WebElement notifications;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ NBBLabel +"']")
    public WebElement NBB;

    public TransactionalCAAndEB(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getCurrentAccount() {
        businessBankingHelper.verifyAndClickElement( currentAccount, currentAccountLabel);
    }

    public void getAVS() {
        businessBankingHelper.verifyAndClickElement( AVS, AVSLabel);
    }

    public void getEStatements() {
        businessBankingHelper.verifyAndClickElement( eStatements, eStatementsLabel);
    }

    public void getNotifications() {
        businessBankingHelper.verifyAndClickElement( notifications, NotifcationsLabel);
    }

    public void getNBB() {
        businessBankingHelper.verifyAndClickElement( NBB, NBBLabel);
    }


    public void verifyCurrentAccount()  {
        businessBankingHelper.verifyPage(currentAccountLabel, currentAccount);
        businessBankingHelper.takeSnapShot(currentAccountLabel +" Page");
    }
    public void verifyAVS()  {
        businessBankingHelper.verifyPage(AVSLabel, AVS);
        businessBankingHelper.takeSnapShot(AVSLabel +" Page");
    }

    public void verifyEStatements()  {
        businessBankingHelper.verifyPage(eStatementsLabel, eStatements);
        businessBankingHelper.takeSnapShot(eStatementsLabel +" Page");
    }
    public void verifyNotifications()  {
        businessBankingHelper.verifyPage(NotifcationsLabel, notifications);
        businessBankingHelper.takeSnapShot(NotifcationsLabel +" Page");
    }
    public void verifyNBB()  {
        businessBankingHelper.verifyPage(NBBLabel, NBB);
        businessBankingHelper.takeSnapShot(NBBLabel +" Page");
    }

}
