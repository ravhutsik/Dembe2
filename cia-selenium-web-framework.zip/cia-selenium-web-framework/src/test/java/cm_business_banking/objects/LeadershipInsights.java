package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LeadershipInsights {
    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String greatLeadersInspireActionLabel = "How Great Leaders Inspire Action";
    final String bendHighPerformanceTeamsLabel = "Bend - High Performance Teams";
    final String voicesOfBankTransformationLabel = "Voices of Bank Transformation";
    final String commercialInsightAsTheNewSalesCurrencyLabel = "Commercial Insight As the New Sales Currency";
    final String NedbankRBBInductionVideoLabel = "Nedbank RBB Induction Video";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ greatLeadersInspireActionLabel +"']")
    public WebElement greatLeadersInspireAction;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ bendHighPerformanceTeamsLabel +"']")
    public WebElement bendHighPerformanceTeams;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ voicesOfBankTransformationLabel +"']")
    public WebElement voicesOfBankTransformation;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ commercialInsightAsTheNewSalesCurrencyLabel +"']")
    public WebElement commercialInsightAsTheNewSalesCurrency;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ NedbankRBBInductionVideoLabel +"']")
    public WebElement NedbankRBBInductionVideo;

    public LeadershipInsights(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getGreatLeadersInspireAction() {
        businessBankingHelper.verifyAndClickElement(greatLeadersInspireAction, greatLeadersInspireActionLabel);
    }

    public void getVoicesOfBankTransformation() {
        businessBankingHelper.verifyAndClickElement( voicesOfBankTransformation, voicesOfBankTransformationLabel);
    }
    public void getBendHighPerformanceTeams() {
        businessBankingHelper.verifyAndClickElement(bendHighPerformanceTeams, bendHighPerformanceTeamsLabel);
    }
    public void getCommercialInsightAsTheNewSalesCurrency() {
        businessBankingHelper.verifyAndClickElement( commercialInsightAsTheNewSalesCurrency, commercialInsightAsTheNewSalesCurrencyLabel);
    }
    public void getNedbankRBBInductionVideo() {
        businessBankingHelper.verifyAndClickElement( NedbankRBBInductionVideo, NedbankRBBInductionVideoLabel);
    }
    public void verifyGreatLeadersInspireAction()  {
        businessBankingHelper.verifyPage(greatLeadersInspireActionLabel, greatLeadersInspireAction);
        businessBankingHelper.takeSnapShot(greatLeadersInspireActionLabel +" Page");
    } public void verifyVoicesOfBankTransformation()  {
        businessBankingHelper.verifyPage(voicesOfBankTransformationLabel, voicesOfBankTransformation);
        businessBankingHelper.takeSnapShot(voicesOfBankTransformationLabel +" Page");
    } public void verifyBendHighPerformanceTeams()  {
        businessBankingHelper.verifyPage(bendHighPerformanceTeamsLabel, bendHighPerformanceTeams);
        businessBankingHelper.takeSnapShot(bendHighPerformanceTeamsLabel +" Page");
    } public void verifyCommercialInsightAsTheNewSalesCurrency()  {
        businessBankingHelper.verifyPage(commercialInsightAsTheNewSalesCurrencyLabel, commercialInsightAsTheNewSalesCurrency);
        businessBankingHelper.takeSnapShot(commercialInsightAsTheNewSalesCurrencyLabel +" Page");
    } public void verifyNedbankRBBInductionVideoLabel()  {
        businessBankingHelper.verifyPage(NedbankRBBInductionVideoLabel, NedbankRBBInductionVideo);
        businessBankingHelper.takeSnapShot(NedbankRBBInductionVideoLabel +" Page");
    }
}
