package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PrincipleClientPortfolio {
    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String PCPServicePledgeLabel = "PCP Service Pledge";
    final String PCPClientHandoverDocumentLabel = "PCP Client Handover document";
    final String PCPScriptForClientMovingToPCPLabel = "PCP - Script for client moving to PCP";
    final String PCPScriptForRelationshipChangesLabel = "PCP - Script for relationship changes";
    final String PCPServicePledgePresentationsLabel = "PCP Service Pledge presentations";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ PCPServicePledgeLabel +"']")
    public WebElement PCPServicePledge;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ PCPClientHandoverDocumentLabel +"']")
    public WebElement PCPClientHandoverDocument;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ PCPScriptForClientMovingToPCPLabel +"']")
    public WebElement PCPScriptForClientMovingToPCP;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ PCPScriptForRelationshipChangesLabel +"']")
    public WebElement PCPScriptForRelationshipChanges;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ PCPServicePledgePresentationsLabel +"']")
    public WebElement PCPServicePledgePresentations;

    public PrincipleClientPortfolio(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getPCPServicePledge() {
        businessBankingHelper.verifyAndClickElement(PCPServicePledge, PCPServicePledgeLabel);
    }

    public void getPCPScriptForClientMovingToPCP() {
        businessBankingHelper.verifyAndClickElement( PCPScriptForClientMovingToPCP, PCPScriptForClientMovingToPCPLabel);
    }
    public void getPCPClientHandoverDocument() {
        businessBankingHelper.verifyAndClickElement(PCPClientHandoverDocument, PCPClientHandoverDocumentLabel);
    }
    public void getPCPScriptForRelationshipChanges() {
        businessBankingHelper.verifyAndClickElement( PCPScriptForRelationshipChanges, PCPScriptForRelationshipChangesLabel);
    }
    public void getPCPServicePledgePresentations() {
        businessBankingHelper.verifyAndClickElement( PCPServicePledgePresentations, PCPServicePledgePresentationsLabel);
    }
    public void verifyPCPServicePledge()  {
        businessBankingHelper.verifyPage(PCPServicePledgeLabel, PCPServicePledge);
        businessBankingHelper.takeSnapShot(PCPServicePledgeLabel +" Page");
    } public void verifyPCPScriptForClientMovingToPCP()  {
        businessBankingHelper.verifyPage(PCPScriptForClientMovingToPCPLabel, PCPScriptForClientMovingToPCP);
        businessBankingHelper.takeSnapShot(PCPScriptForClientMovingToPCPLabel +" Page");
    } public void verifyPCPClientHandoverDocument()  {
        businessBankingHelper.verifyPage(PCPClientHandoverDocumentLabel, PCPClientHandoverDocument);
        businessBankingHelper.takeSnapShot(PCPClientHandoverDocumentLabel +" Page");
    } public void verifyPCPScriptForRelationshipChanges()  {
        businessBankingHelper.verifyPage(PCPScriptForRelationshipChangesLabel, PCPScriptForRelationshipChanges);
        businessBankingHelper.takeSnapShot(PCPScriptForRelationshipChangesLabel +" Page");
    } public void verifyPCPServicePledgePresentationsLabel()  {
        businessBankingHelper.verifyPage(PCPServicePledgePresentationsLabel, PCPServicePledgePresentations);
        businessBankingHelper.takeSnapShot(PCPServicePledgePresentationsLabel +" Page");
    }
}
