package cm_business_banking.objects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class BusinessBankingObjects {

    private final WebDriver driver;

    @FindBy(how = How.XPATH, using = "//*[@id=\"CategoriesDiv\"]/a[3]/div/div[2]")
    public WebElement enterpriseWideRiskComplianceAndGovernance;

    @FindBy(how = How.XPATH, using = "//*[@id=\"jsddm\"]/li[1]/a")
    public WebElement homeText;

    @FindBy(how = How.XPATH, using = "//*[@id=\"CategoriesDiv\"]/a[3]/div/div[1]")
    public WebElement categoriesDiv;

    @FindBy(how = How.XPATH, using = "//*[@id=\"CategoriesDiv\"]/a[1]/div/div[4]/label")
    public WebElement erm;

    @FindBy(how = How.XPATH, using = "//*[@id=\"CategoriesDiv\"]/a[2]/div/div[4]/label")
    public WebElement oldCategory;

    @FindBy(how = How.XPATH, using = "//*[@id=\"CategoriesDiv\"]/a[3]/div/div[4]/label")
    public WebElement clusterRiskSupport;

    @FindBy(how = How.XPATH, using = "//*[@id=\"CategoriesDiv\"]/a[4]/div/div[4]/label")
    public WebElement compliance;

    @FindBy(how = How.XPATH, using = "//*[@id=\"CategoriesDiv\"]/a[1]/div/div[4]/label")
    public WebElement mandate;

    @FindBy(how = How.XPATH, using = "//*[@id=\"CategoriesDiv\"]/a[1]/div/div[4]/label")
    public WebElement riskOperation;

    @FindBy(how = How.XPATH, using = "//*[@id=\"ArticlesDiv\"]/a[1]/div/div[5]/label")
    public WebElement mandateManagement;

    @FindBy(how = How.XPATH, using = "//*[@id=\"content\"]/div[4]/div[2]/h3")
    public WebElement mandateManagementLabel;

    @FindBy(how = How.XPATH, using = "//*[@id=\"ArticlesDiv\"]/a[2]/div/div[5]/label")
    public WebElement authorityToAct;

    @FindBy(how = How.XPATH, using = "//*[@id=\"content\"]/div[4]/div[2]/h3")
    public WebElement authorityToActLabel;

    @FindBy(how = How.XPATH, using = "//*[@id=\"CategoriesDiv\"]/a[3]/div/div[4]/label")
    public WebElement riskEventReportLabel;

    @FindBy(how = How.XPATH, using = "//*[@id=\"ArticlesDiv\"]/a/div/div[5]/label")
    public WebElement riskEventEscalation;

    @FindBy(how = How.XPATH, using = "//*[@id=\"CategoriesDiv\"]/a[2]/div/div[4]/label")
    public WebElement rbbPolicies;

    @FindBy(how = How.XPATH, using = "//*[@id=\"CategoriesDiv\"]/a/div/div[4]/label")
    public WebElement financialAccountingLabel;





    public BusinessBankingObjects(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

}
