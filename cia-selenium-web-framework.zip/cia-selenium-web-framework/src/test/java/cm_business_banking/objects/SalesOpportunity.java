package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class SalesOpportunity {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String salesLeversLabel = "Sales Levers";
    final String salesInitiativesLabel = "Sales Initiatives";
    final String BBRRBAcquisitionLabel = "BB RRB Acquisition";
    final String MFCCollaborationLabel = "Sales Initiatives";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ salesLeversLabel +"']")
    public WebElement salesLevers;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ salesInitiativesLabel +"']")
    public WebElement salesInitiatives;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BBRRBAcquisitionLabel +"']")
    public WebElement BBRRBAcquisition;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ MFCCollaborationLabel +"']")
    public WebElement MFCCollaboration;

    public SalesOpportunity(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getSalesLevers() {
        businessBankingHelper.verifyAndClickElement( salesLevers, salesLeversLabel);
    }

    public void getSalesInitiatives() {
        businessBankingHelper.verifyAndClickElement( salesInitiatives, salesInitiativesLabel);
    }

    public void verifyBBRRBAcquisition()  {
        businessBankingHelper.verifyPage(BBRRBAcquisitionLabel, BBRRBAcquisition);
        businessBankingHelper.takeSnapShot(BBRRBAcquisitionLabel +" Page");
    }
    public void verifyMFCCollaboration()  {
        businessBankingHelper.verifyPage(MFCCollaborationLabel, MFCCollaboration);
        businessBankingHelper.takeSnapShot(MFCCollaborationLabel +" Page");
    }
    public void verifySalesLevers()  {
        businessBankingHelper.verifyPage(salesLeversLabel, salesLevers);
        businessBankingHelper.takeSnapShot(salesLeversLabel +" Page");
    }

}
