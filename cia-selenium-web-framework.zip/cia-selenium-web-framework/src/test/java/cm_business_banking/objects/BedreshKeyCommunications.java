package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class BedreshKeyCommunications {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String systemAccessControlsLabel = "SYSTEM ACCESS CONTROLS";
    final String emeraldEReviewFacilityLetterLabel = "EMERALD eREVIEW FACILITY LETTER";
    final String creditAndCreditRiskNewsletterLabel = "CREDIT AND CREDIT RISK NEWSLETTER";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ systemAccessControlsLabel +"']")
    public WebElement systemAccessControls;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ emeraldEReviewFacilityLetterLabel +"']")
    public WebElement emeraldEReviewFacilityLetter;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ creditAndCreditRiskNewsletterLabel +"']")
    public WebElement creditAndCreditRiskNewsletter;

    public BedreshKeyCommunications(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getSystemAccessControls() {
        businessBankingHelper.verifyAndClickElement( systemAccessControls, systemAccessControlsLabel);
    }
    public void verifySystemAccessControls()  {
        businessBankingHelper.verifyPage(systemAccessControlsLabel, systemAccessControls);
        businessBankingHelper.takeSnapShot(systemAccessControlsLabel+" Page");
    }

    public void getEmeraldEReviewFacilityLetter() {
        businessBankingHelper.verifyAndClickElement( emeraldEReviewFacilityLetter, emeraldEReviewFacilityLetterLabel);
    }
    public void verifyEmeraldEReviewFacilityLetter()  {
        businessBankingHelper.verifyPage(emeraldEReviewFacilityLetterLabel, emeraldEReviewFacilityLetter);
        businessBankingHelper.takeSnapShot(emeraldEReviewFacilityLetterLabel+" Page");
    }

    public void getCreditAndCreditRiskNewsletter() {
        businessBankingHelper.verifyAndClickElement( creditAndCreditRiskNewsletter, creditAndCreditRiskNewsletterLabel);
    }
    public void verifyCreditAndCreditRiskNewsletter()  {
        businessBankingHelper.verifyPage(creditAndCreditRiskNewsletterLabel, creditAndCreditRiskNewsletter);
        businessBankingHelper.takeSnapShot(creditAndCreditRiskNewsletterLabel+" Page");
    }

}
