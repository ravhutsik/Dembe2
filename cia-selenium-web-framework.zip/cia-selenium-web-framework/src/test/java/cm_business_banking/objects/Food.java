package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Food {

    //Pending Methods

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String adegaLabel = "Adega";
    final String andiccio24Label = "Andiccio 24";
    final String chickenLickenLabel = "Chicken Licken";
    final String boostJuiceLabel = "Boost Juice";
    final String breadBasketLabel = "Bread Basket";
    final String burgerKingLabel = "Burger King";
    final String coffeeCoutureLabel = "Coffee Couture";
    final String capeTownFishMarketLabel = "Cape Town Fish Market ";
    final String debonairsLabel = "Debonairs";
    final String cafe2GoLabel = "cafe 2 go";

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ adegaLabel +"']")
    public WebElement Adega;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ andiccio24Label +"']")
    public WebElement Andiccio24;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ chickenLickenLabel +"']")
    public WebElement chickenLicken;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ boostJuiceLabel +"']")
    public WebElement boostJuice;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ breadBasketLabel +"']")
    public WebElement breadBasket;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ burgerKingLabel +"']")
    public WebElement burgerKing;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ coffeeCoutureLabel +"']")
    public WebElement coffeeCouture;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ capeTownFishMarketLabel +"']")
    public WebElement capeTownFishMarket;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ debonairsLabel +"']")
    public WebElement debonairs;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ cafe2GoLabel +"']")
    public WebElement cafe2Go;

    public Food(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getAdega() {
        businessBankingHelper.verifyAndClickElement( Adega, adegaLabel);
    }
    public void verifyAdega()  {
        businessBankingHelper.verifyPage(adegaLabel, Adega);
        businessBankingHelper.takeSnapShot(adegaLabel +" Page");
    }
    public void getAndiccio24() {
        businessBankingHelper.verifyAndClickElement( Andiccio24, andiccio24Label);
    }
    public void verifyAndiccio24()  {
        businessBankingHelper.verifyPage(andiccio24Label, Andiccio24);
        businessBankingHelper.takeSnapShot(andiccio24Label +" Page");
    }
    public void getChickenLicken() {
        businessBankingHelper.verifyAndClickElement(chickenLicken, chickenLickenLabel);
    }
    public void verifyChickenLicken()  {
        businessBankingHelper.verifyPage(chickenLickenLabel, chickenLicken);
        businessBankingHelper.takeSnapShot(chickenLickenLabel +" Page");
    }
    public void getBoostJuice() {
        businessBankingHelper.verifyAndClickElement(boostJuice, boostJuiceLabel);
    }
    public void verifyBoostJuice()  {
        businessBankingHelper.verifyPage(boostJuiceLabel, boostJuice);
        businessBankingHelper.takeSnapShot(boostJuiceLabel +" Page");
    }
    public void getBreadBasket() {
        businessBankingHelper.verifyAndClickElement( breadBasket, breadBasketLabel);
    }
    public void verifyBreadBasket()  {
        businessBankingHelper.verifyPage(breadBasketLabel, breadBasket);
        businessBankingHelper.takeSnapShot(breadBasketLabel+" Page");
    }
    public void getTigerBurgerKing() {
        businessBankingHelper.verifyAndClickElement(burgerKing, burgerKingLabel);
    }
    public void verifyBurgerKing()  {
        businessBankingHelper.verifyPage(burgerKingLabel, burgerKing);
        businessBankingHelper.takeSnapShot(burgerKingLabel +" Page");
    }
    public void getCoffeeCouture() {
        businessBankingHelper.verifyAndClickElement( coffeeCouture, coffeeCoutureLabel);
    }
    public void verifyCoffeeCouture()  {
        businessBankingHelper.verifyPage(coffeeCoutureLabel, coffeeCouture);
        businessBankingHelper.takeSnapShot(coffeeCoutureLabel +" Page");
    }
    public void getCapeTownFishMarket() {
        businessBankingHelper.verifyAndClickElement(capeTownFishMarket, capeTownFishMarketLabel);
    }
    public void verifyCapeTownFishMarket()  {
        businessBankingHelper.verifyPage(capeTownFishMarketLabel, capeTownFishMarket);
        businessBankingHelper.takeSnapShot(capeTownFishMarketLabel +" Page");
    }
    public void getDebonairs() {
        businessBankingHelper.verifyAndClickElement(debonairs, debonairsLabel);
    }
    public void verifyDebonairs()  {
        businessBankingHelper.verifyPage(debonairsLabel, debonairs);
        businessBankingHelper.takeSnapShot(debonairsLabel +" Page");
    }
    public void getCafe2Go() {
        businessBankingHelper.verifyAndClickElement(cafe2Go, cafe2GoLabel);
    }
    public void verifyCafe2Go()  {
        businessBankingHelper.verifyPage(cafe2GoLabel, cafe2Go);
        businessBankingHelper.takeSnapShot(cafe2GoLabel +" Page");
    }
}
