package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Sales {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String BMRRLearningMatrixLabel = "BM RR Learning Matrix";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BMRRLearningMatrixLabel +"']")
    public WebElement BMRRLearningMatrix;

    public Sales(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getOperationalManagement() {
        businessBankingHelper.verifyAndClickElement(BMRRLearningMatrix, BMRRLearningMatrixLabel);
    }
    public void verifyOperationalManagement()  {
        businessBankingHelper.verifyPage(BMRRLearningMatrixLabel, BMRRLearningMatrix);
        businessBankingHelper.takeSnapShot(BMRRLearningMatrixLabel +" Page");
    }
}
