package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class TransactionalCard {


    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String NedbankBusinessCardLabel = "Nedbank Business Carde";
    final String NedbankChequeCardLabel = "Nedbank Cheque Card";
    final String RewardsRevolveCardLabel = "Rewards Revolve Card";
    final String PortablePOSLabel = "Portable POS";
    final String NedbankPurchaseCardLabel = "Nedbank Purchase Card";
    final String DesktopPOSLabel = "Desktop POS";
    final String GarageCardLabel = "Garage Card";
    final String BusinessTravelAccountLabel = "Business Travel Account (BTA)";


    String [] NedbankBusinessCard = {"Nedbank Business Card Cheat sheet"};
    String [] NedbankChequeCard  = {"Nedbank Cheque Card Cheat sheet"};
    String [] RewardsRevolveCard  = {"Nedbank Rewards Revolve Card Training presentation","Business Cheque Card Training presentation"};
    String[] PortablePOS = {"Portable POS device cheathseet","Point-of-sale solutions training presentation"};
    String [] NedbankPurchaseCard = {"Purchasing Card cheatsheet","Purchasing Card Training presentation"};
    String[] DesktopPOS = {"Point-of-sale solutions training presentation","Nedlink POS Cheatsheet"};
    String []GarageCard = {"Garage Cheque Card cheatsheet", "Nedbank Business Garage Card Training presentation"};
    String[] BusinessTravelAccount = {"Business Travel Account training presentation", "Amex Business Travel Account cheat sheet"};


    public TransactionalCard(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }
    


    public void getNedbankBusinessCard() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(NedbankBusinessCardLabel), NedbankBusinessCardLabel);
        businessBankingHelper.performOperation(NedbankBusinessCard);
    }

    public void getNedbankChequeCard() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(NedbankChequeCardLabel), NedbankChequeCardLabel);
        businessBankingHelper.performOperation(NedbankChequeCard);
    }

    public void getRewardsRevolveCard() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(RewardsRevolveCardLabel), RewardsRevolveCardLabel);
        businessBankingHelper.performOperation(RewardsRevolveCard);
    }
    public void getPortablePOS() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(PortablePOSLabel), PortablePOSLabel);
        businessBankingHelper.performOperation(PortablePOS);
    }
    public void getNedbankPurchaseCard() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(NedbankPurchaseCardLabel), NedbankPurchaseCardLabel);
        businessBankingHelper.performOperation(NedbankPurchaseCard);
    }
    public void getDesktopPOS() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(DesktopPOSLabel), DesktopPOSLabel);
        businessBankingHelper.performOperation(DesktopPOS);
    }
    public void getGarageCard() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(GarageCardLabel), GarageCardLabel);
        businessBankingHelper.performOperation(GarageCard);
    }
    public void getBusinessTravelAccount() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(BusinessTravelAccountLabel), BusinessTravelAccountLabel);
        businessBankingHelper.performOperation(BusinessTravelAccount);
    }

}
