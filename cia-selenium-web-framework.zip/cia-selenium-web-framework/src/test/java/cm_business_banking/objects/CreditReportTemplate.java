package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class CreditReportTemplate {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;

    public final String RBB_NEW_NEDBANK_PRESENTATION_LABEL = "RBB NEW NEDBANK PRESENTATION";
    public final String BB_INTERNAL_REPORTING_PRESENTATION_LABEL = "BB INTERNAL REPORTING PRESENTATION";
    public final String Whole_View_BB_Editorial_LABEL = "Whole-view Business Banking Afrikaans editorial";
    public final String FX_Derivatives_Nedbank_LABEL= "FX Derivatives - by Nedbank";
    public final String WholeView_Digital_Banners_Product_Label = "Wholeview Digital banners – product";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ RBB_NEW_NEDBANK_PRESENTATION_LABEL +"']")
    public WebElement RBB_NEW_NEDBANK_PRESENTATION;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BB_INTERNAL_REPORTING_PRESENTATION_LABEL +"']")
    public WebElement BB_INTERNAL_REPORTING_PRESENTATION;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ Whole_View_BB_Editorial_LABEL +"']")
    public WebElement  Whole_View_BB_Afrikaans_Editorial;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ FX_Derivatives_Nedbank_LABEL +"']")
    public WebElement FX_Derivatives_Nedbank;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ WholeView_Digital_Banners_Product_Label +"']")
    public WebElement WholeView_Digital_Banners_Product;


    public CreditReportTemplate(WebDriver driver) {
            this.driver = driver;
            businessBankingHelper = new BusinessBankingHelper(this.driver);
            PageFactory.initElements(driver, this);
    }

    public void verifyRBBNewNedbankPresentationPage() throws Exception{
        businessBankingHelper.verifyPage(RBB_NEW_NEDBANK_PRESENTATION_LABEL, RBB_NEW_NEDBANK_PRESENTATION);
        businessBankingHelper.takeSnapShot(RBB_NEW_NEDBANK_PRESENTATION_LABEL+" Page");
    }

    public void verifyInternalReportingPage() throws Exception{
        businessBankingHelper.verifyPage(BB_INTERNAL_REPORTING_PRESENTATION_LABEL, BB_INTERNAL_REPORTING_PRESENTATION);
        businessBankingHelper.takeSnapShot(BB_INTERNAL_REPORTING_PRESENTATION_LABEL+" Page");
//        businessBankingHelper.closePage();
    }

    public void verifyWholeViewEditorialPage()throws Exception {
        businessBankingHelper.verifyPage(Whole_View_BB_Editorial_LABEL, Whole_View_BB_Afrikaans_Editorial);
        businessBankingHelper.takeSnapShot(Whole_View_BB_Editorial_LABEL+" Page");    }

    public void verifyFXDerivativesNedbankPage()throws Exception {
        businessBankingHelper.verifyPage(FX_Derivatives_Nedbank_LABEL, FX_Derivatives_Nedbank);
        businessBankingHelper.takeSnapShot(FX_Derivatives_Nedbank_LABEL+" Page");
    }

    public void verifyWholeViewDigitalBannerProductPage() throws Exception{
        businessBankingHelper.verifyPage(WholeView_Digital_Banners_Product_Label, WholeView_Digital_Banners_Product);
        businessBankingHelper.takeSnapShot(WholeView_Digital_Banners_Product_Label+" Page");
    }

    public void getRBB_NEW_NEDBANK_PRESENTATION() {
        businessBankingHelper.verifyAndClickElement(RBB_NEW_NEDBANK_PRESENTATION, RBB_NEW_NEDBANK_PRESENTATION_LABEL);
    }

    public void getBB_INTERNAL_REPORTING_PRESENTATION() {
        businessBankingHelper.verifyAndClickElement( BB_INTERNAL_REPORTING_PRESENTATION, BB_INTERNAL_REPORTING_PRESENTATION_LABEL);
    }

    public void getWhole_View_BB_Afrikaans_Editorial() {
        businessBankingHelper.verifyAndClickElement(Whole_View_BB_Afrikaans_Editorial, Whole_View_BB_Editorial_LABEL);
    }

    public void getFX_Derivatives_Nedbank() {
        businessBankingHelper.verifyAndClickElement(FX_Derivatives_Nedbank, FX_Derivatives_Nedbank_LABEL);
    }

    public void getWholeView_Digital_Banners_Product() {
        businessBankingHelper.verifyAndClickElement( WholeView_Digital_Banners_Product, WholeView_Digital_Banners_Product_Label);
    }
}
