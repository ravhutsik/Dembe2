package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class GeneralCommunication {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String BBPositioningLabel  = "BB Positioning";
    final String debtorManagementCampaignRadioAdvertLabel = "Debtor Management Campaign radio advert";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BBPositioningLabel +"']")
    public WebElement BBPositioning;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ debtorManagementCampaignRadioAdvertLabel +"']")
    public WebElement debtorManagementCampaignRadioAdvert;

    public GeneralCommunication(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getDebtorManagementCampaignRadioAdvert() {
        businessBankingHelper.verifyAndClickElement( debtorManagementCampaignRadioAdvert, debtorManagementCampaignRadioAdvertLabel);
    }
    public void verifyDebtorManagementCampaignRadioAdvert()  {
        businessBankingHelper.verifyPage(debtorManagementCampaignRadioAdvertLabel, debtorManagementCampaignRadioAdvert);
        businessBankingHelper.takeSnapShot(debtorManagementCampaignRadioAdvertLabel+" Page");
    }

    public void getBBPositioning() {
        businessBankingHelper.verifyAndClickElement( BBPositioning, BBPositioningLabel);
    }
    public void verifyBBPositioning()  {
        businessBankingHelper.verifyPage(BBPositioningLabel, BBPositioning);
        businessBankingHelper.takeSnapShot(BBPositioningLabel+" Page");
    }


}
