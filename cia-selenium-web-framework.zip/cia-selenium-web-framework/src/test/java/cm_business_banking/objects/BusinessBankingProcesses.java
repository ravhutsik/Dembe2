package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class BusinessBankingProcesses {


    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String BBProcessesHyperLinkLabel = "BB PROCESSES HYPERLINK";
    final String creditReportMonthlyLabel = "DAILY – WEEKLY – MONTHLY CONTROLS: CREDIT";
    final String electronicSecuritySigningLabel = "ELECTRONIC SECURITY SIGNING";
    final String emailNotificationLabel = "eMAIL NOTIFICATION for CREDIT REVIEWS";
    final String visitationCaptureProcedureLabel = "VISITATION CAPTURE PROCEDURES";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BBProcessesHyperLinkLabel +"']")
    public WebElement BBProcessesHyperLink;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ creditReportMonthlyLabel +"']")
    public WebElement creditReportMonthly;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ electronicSecuritySigningLabel +"']")
    public WebElement electronicSecuritySigning;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ emailNotificationLabel +"']")
    public WebElement emailNotification;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ visitationCaptureProcedureLabel +"']")
    public WebElement visitationCaptureProcedure;


    public BusinessBankingProcesses(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getBBProcessesHyperLink() {
        businessBankingHelper.verifyAndClickElement( BBProcessesHyperLink, BBProcessesHyperLinkLabel);
    }

    public void verifyBBProcessesHyperLink()  {
        businessBankingHelper.verifyPage(BBProcessesHyperLinkLabel, BBProcessesHyperLink);
        businessBankingHelper.takeSnapShot(BBProcessesHyperLinkLabel+" Page");
    }

    public void getCreditReportMonthly() {
        businessBankingHelper.verifyAndClickElement( creditReportMonthly, "creditReportMonthlyLabel");
    }

    public void verifyCreditReportMonthly()  {
        businessBankingHelper.verifyPage(creditReportMonthlyLabel, creditReportMonthly);
        businessBankingHelper.takeSnapShot("creditReportMonthlyLabelPage");
    }

    public void getElectronicSecuritySigning() {
        businessBankingHelper.verifyAndClickElement( electronicSecuritySigning, electronicSecuritySigningLabel);
    }

    public void verifyElectronicSecuritySigning()  {
        businessBankingHelper.verifyPage(electronicSecuritySigningLabel, electronicSecuritySigning);
        businessBankingHelper.takeSnapShot(electronicSecuritySigningLabel+" Page");
    }

    public void getEmailNotification() {
        businessBankingHelper.verifyAndClickElement( emailNotification, emailNotificationLabel);
    }

    public void verifyEmailNotification()  {
        businessBankingHelper.verifyPage(emailNotificationLabel, emailNotification);
        businessBankingHelper.takeSnapShot(emailNotificationLabel+" Page");
    }

    public void getVisitationCaptureProcedure() {
        businessBankingHelper.verifyAndClickElement( visitationCaptureProcedure, visitationCaptureProcedureLabel);
    }

    public void verifyVisitationCaptureProcedure()  {
        businessBankingHelper.verifyPage(visitationCaptureProcedureLabel, visitationCaptureProcedure);
        businessBankingHelper.takeSnapShot(visitationCaptureProcedureLabel+" Page");
    }


}
