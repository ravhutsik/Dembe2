package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LearningDevelopment {
    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String roleRelevantTrainingLabel = "Role Relevant Training";
    final String curriculumsLabel = "Curriculums";
    final String successFactorsLabel = "Success Factors";
    final String financialProductsLabel = "Financial Products";
    final String trainingMaterialAndProjectsLabel = "Training Material and Projects";
    final String contactUsLabel = "Contact Us";
    final String moodySAnalyticsLabel = "Moody's Analytics";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ roleRelevantTrainingLabel +"']")
    public WebElement roleRelevantTraining;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ curriculumsLabel +"']")
    public WebElement curriculums;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ successFactorsLabel +"']")
    public WebElement successFactors;


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ financialProductsLabel +"']")
    public WebElement financialProducts;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ trainingMaterialAndProjectsLabel +"']")
    public WebElement trainingMaterialAndProjects;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ contactUsLabel +"']")
    public WebElement contactUs;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ moodySAnalyticsLabel +"']")
    public WebElement moodySAnalytics;


    public LearningDevelopment(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getRoleRelevantTraining() {
        businessBankingHelper.verifyAndClickElement(roleRelevantTraining, roleRelevantTrainingLabel);
    }
    public void getCurriculums() {
        businessBankingHelper.verifyAndClickElement(curriculums, curriculumsLabel);
    }
    public void getSuccessFactors() {
        businessBankingHelper.verifyAndClickElement(successFactors, successFactorsLabel);
    }
    public void getFinancialProducts() {
        businessBankingHelper.verifyAndClickElement(financialProducts, financialProductsLabel);
    }
    public void getTrainingMaterialAndProjects() {
        businessBankingHelper.verifyAndClickElement(trainingMaterialAndProjects, trainingMaterialAndProjectsLabel);
    }
    public void getContactUs() {
        businessBankingHelper.verifyAndClickElement(contactUs, contactUsLabel);
    }
    public void getMoodySAnalytics() {
        businessBankingHelper.verifyAndClickElement(moodySAnalytics, moodySAnalyticsLabel);
    }

    public void verifyContactUs()  {
        businessBankingHelper.verifyPage(contactUsLabel, contactUs);
        businessBankingHelper.takeSnapShot(contactUsLabel +" Page");
    }

}
