package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class AgriKeyContact {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String agricultureTeamLabel = "Agriculture Team";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ agricultureTeamLabel +"']")
    public WebElement agricultureTeam;

    public AgriKeyContact(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getAgricultureTeam() {
        businessBankingHelper.verifyAndClickElement( agricultureTeam, agricultureTeamLabel);
    }
    public void verifyAgricultureTeam()  {
        businessBankingHelper.verifyPage(agricultureTeamLabel, agricultureTeam);
        businessBankingHelper.takeSnapShot(agricultureTeamLabel +" Page");
    }
}
