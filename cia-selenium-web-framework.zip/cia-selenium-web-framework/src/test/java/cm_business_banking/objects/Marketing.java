package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Marketing {


    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String publicSectorBrochureLabel = "Public Sector Brochure";
    final String FXDerivativesByNedbankLabel = "FX Derivatives - by Nedbank";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ publicSectorBrochureLabel +"']")
    public WebElement publicSectorBrochure;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ FXDerivativesByNedbankLabel +"']")
    public WebElement FXDerivativesByNedbank;

    public Marketing(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getPublicSectorBrochure() {
        businessBankingHelper.verifyAndClickElement( publicSectorBrochure, publicSectorBrochureLabel);
    }
    public void verifyPublicSectorBrochure()  {
        businessBankingHelper.verifyPage(publicSectorBrochureLabel, publicSectorBrochure);
        businessBankingHelper.takeSnapShot(publicSectorBrochureLabel+" Page");
    }
    public void getFXDerivativesByNedbank() {
        businessBankingHelper.verifyAndClickElement( FXDerivativesByNedbank, FXDerivativesByNedbankLabel);
    }
    public void verifyFXDerivativesByNedbank()  {
        businessBankingHelper.verifyPage(FXDerivativesByNedbankLabel, FXDerivativesByNedbank);
        businessBankingHelper.takeSnapShot(FXDerivativesByNedbankLabel+" Page");
    }
}
