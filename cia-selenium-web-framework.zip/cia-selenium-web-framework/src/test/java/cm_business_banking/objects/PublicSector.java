package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PublicSector {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String marketingLabel = "Marketing";
    final String legislationLabel = "Legislation";
    final String overviewLabel = "Overview";
    final String productRequirementsLabel = "Product Requirements";
    final String solutionsAndServicesLabel = "Solutions and Services";

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ marketingLabel +"']")
    public WebElement marketing;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ legislationLabel +"']")
    public WebElement legislation;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ overviewLabel +"']")
    public WebElement overview;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ productRequirementsLabel +"']")
    public WebElement productRequirements;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ solutionsAndServicesLabel +"']")
    public WebElement solutionsAndServices;


    public PublicSector(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getMarketing() {
        businessBankingHelper.verifyAndClickElement(marketing, marketingLabel);
    }

    public void getLegislation() {
        businessBankingHelper.verifyAndClickElement(legislation, legislationLabel);
    }

    public void getOverview() {
        businessBankingHelper.verifyAndClickElement( overview, overviewLabel);
    }

    public void getProductRequirements() {
        businessBankingHelper.verifyAndClickElement( productRequirements, productRequirementsLabel);
    }

    public void getSolutionsAndServices() {
        businessBankingHelper.verifyAndClickElement( solutionsAndServices, solutionsAndServicesLabel);
    }
}
