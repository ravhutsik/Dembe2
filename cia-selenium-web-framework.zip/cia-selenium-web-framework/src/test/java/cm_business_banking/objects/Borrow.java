package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class Borrow {


    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String OverdraftLabel = "Overdraft";
    final String AssetBasedFinanceLabel = "Asset Based Finance (ABF)";
    final String CommercialBondLabel = "Commercial Bond";
    final String LocalGuaranteesLabel = "Local Guarantees";
    final String ResidentialHomeLoanLabel = "Residential Home Loan (RHL)";
    final String MediumTermLoanLabel = "Medium Term Loan (MTL)";


    String [] Overdraft = {"Overdraft Cheat sheet"};
    String [] AssetBasedFinance  = {"ABF Cheatsheet"};
    String [] CommercialBond  = {"Commercial Bond Cheatsheet"};
    String[] LocalGuarantees = {"Local Guarantee Cheatsheet"};
    String [] ResidentialHomeLoan = {"Residential Home Loans"};
    String[] MediumTermLoan = {"Medium-Term Loan Cheatsheet"};


    public Borrow(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }
    


    public void getOverdraft() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(OverdraftLabel), OverdraftLabel);
        businessBankingHelper.performOperation(Overdraft);
    }

    public void getAssetBasedFinance() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(AssetBasedFinanceLabel), AssetBasedFinanceLabel);
        businessBankingHelper.performOperation(AssetBasedFinance);
    }

    public void getCommercialBond() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(CommercialBondLabel), CommercialBondLabel);
        businessBankingHelper.performOperation(CommercialBond);
    }
    public void getLocalGuarantees() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(LocalGuaranteesLabel), LocalGuaranteesLabel);
        businessBankingHelper.performOperation(LocalGuarantees);
    }
    public void getResidentialHomeLoan() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(ResidentialHomeLoanLabel), ResidentialHomeLoanLabel);
        businessBankingHelper.performOperation(ResidentialHomeLoan);
    }
    public void getMediumTermLoan() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(MediumTermLoanLabel), MediumTermLoanLabel);
        businessBankingHelper.performOperation(MediumTermLoan);
    }

}
