package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class MoreCategories {
    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String leadershipInsightsLabel = "Leadership Insights";
    final String takingClientExperienceNextLevelLabel = "Taking client experience to the next level";
    final String takingPersonalGrowthNextLevelLabel = "Taking my personal growth to the next level";
    final String takingBusinessNextLevelLabel = "Taking our business to the next level";
    final String aboutNedbankLabel = "About Nedbank";
    final String takingSalesNextLevelLabel = "Taking sales to the next level";
    final String businessGoalsAndMeasuresLabel = "Business Goals and Measures";
    final String BBOperationsLabel = "BB OPERATIONS";
    final String AboutNedbank2Label = "About - Nedbank";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ leadershipInsightsLabel +"']")
    public WebElement leadershipInsights;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ takingClientExperienceNextLevelLabel +"']")
    public WebElement takingClientExperienceNextLevel;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ takingPersonalGrowthNextLevelLabel +"']")
    public WebElement takingPersonalGrowthNextLevel;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ takingBusinessNextLevelLabel +"']")
    public WebElement takingBusinessNextLevel;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ aboutNedbankLabel +"']")
    public WebElement aboutNedbank;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ takingSalesNextLevelLabel +"']")
    public WebElement takingSalesNextLevel;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ businessGoalsAndMeasuresLabel +"']")
    public WebElement businessGoalsAndMeasures;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BBOperationsLabel +"']")
    public WebElement BBOperations;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ AboutNedbank2Label +"']")
    public WebElement AboutNedbank2;



    public MoreCategories(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getLeadershipInsights() {
        businessBankingHelper.verifyAndClickElement( leadershipInsights, leadershipInsightsLabel);
    }
    public void getTakingClientExperienceNextLevel() {
        businessBankingHelper.verifyAndClickElement(takingClientExperienceNextLevel, takingClientExperienceNextLevelLabel);
    }
    public void getTakingPersonalGrowthNextLevel() {
        businessBankingHelper.verifyAndClickElement(takingPersonalGrowthNextLevel, takingPersonalGrowthNextLevelLabel);
    }
    public void getTakingBusinessNextLevel() {
        businessBankingHelper.verifyAndClickElement(takingBusinessNextLevel, takingBusinessNextLevelLabel);
    }
    public void getAboutNedbank() {
        businessBankingHelper.verifyAndClickElement(aboutNedbank, aboutNedbankLabel);
    }
    public void getTakingSalesNextLevel() {
        businessBankingHelper.verifyAndClickElement(takingSalesNextLevel, takingSalesNextLevelLabel);
    }
    public void getBusinessGoalsAndMeasures() {
        businessBankingHelper.verifyAndClickElement(businessGoalsAndMeasures, businessGoalsAndMeasuresLabel);
    }
    public void getBBOperations() {
        businessBankingHelper.verifyAndClickElement(BBOperations, BBOperationsLabel);
    }
    public void getAboutNedbank2() {
        businessBankingHelper.verifyAndClickElement(AboutNedbank2, AboutNedbank2Label);
    }
}
