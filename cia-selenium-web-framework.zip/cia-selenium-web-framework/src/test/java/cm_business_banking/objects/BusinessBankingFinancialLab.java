package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class BusinessBankingFinancialLab {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;

    final String IPREUserGuideLabel = "IPRE USER GUIDE";
    final String introductionIntoAIRBAndIFRS9ModelsLabel = "Introduction into AIRB and IFRS9 models";
    final String BBFinancialLabBusinessQueriesLabel = "BB FINANCIAL LAB BUSINESS QUERIES";
    final String ratingToolHelpDocumentLabel = "RATING TOOL HELP DOCUMENT";
    final String BBImpairmentPredictorToolLabel = "BB IMPAIRMENT PREDICTOR TOOL";
    final String wholeViewTVLabel = "Whole-view TV";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ IPREUserGuideLabel +"']")
    public WebElement IPREUserGuide;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ introductionIntoAIRBAndIFRS9ModelsLabel +"']")
    public WebElement introductionIntoAIRBAndIFRS9Models;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BBFinancialLabBusinessQueriesLabel +"']")
    public WebElement BBFinancialLabBusinessQueries;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ ratingToolHelpDocumentLabel +"']")
    public WebElement ratingToolHelpDocument;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BBImpairmentPredictorToolLabel +"']")
    public WebElement BBImpairmentPredictorTool;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ wholeViewTVLabel +"']")
    public WebElement wholeViewTV;

    public BusinessBankingFinancialLab(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getIPREUserGuide() {

        businessBankingHelper.verifyAndClickElement( IPREUserGuide, IPREUserGuideLabel);
    }

    public void verifyIPREUserGuide()  {
        businessBankingHelper.verifyPage(IPREUserGuideLabel, IPREUserGuide);
        businessBankingHelper.takeSnapShot(IPREUserGuideLabel+" Page");
    }
    public void getIntroductionIntoAIRBAndIFRS9Models() {
        businessBankingHelper.verifyAndClickElement( introductionIntoAIRBAndIFRS9Models, introductionIntoAIRBAndIFRS9ModelsLabel);
    }
    public void verifyIntroductionIntoAIRBAndIFRS9Models()  {
        businessBankingHelper.verifyPage(introductionIntoAIRBAndIFRS9ModelsLabel, introductionIntoAIRBAndIFRS9Models);
        businessBankingHelper.takeSnapShot(introductionIntoAIRBAndIFRS9ModelsLabel+" Page");
    }
    public void getBBFinancialLabBusinessQueries() {
        businessBankingHelper.verifyAndClickElement( BBFinancialLabBusinessQueries, BBFinancialLabBusinessQueriesLabel);
    }
    public void verifyBBFinancialLabBusinessQueries()  {
        businessBankingHelper.verifyPage(BBFinancialLabBusinessQueriesLabel, BBFinancialLabBusinessQueries);
        businessBankingHelper.takeSnapShot(BBFinancialLabBusinessQueriesLabel+" Page");
    }
    public void getRatingToolHelpDocument() {
        businessBankingHelper.verifyAndClickElement( IPREUserGuide, IPREUserGuideLabel);
    }
    public void verifyRatingToolHelpDocument()  {
        businessBankingHelper.verifyPage(ratingToolHelpDocumentLabel, ratingToolHelpDocument);
        businessBankingHelper.takeSnapShot(ratingToolHelpDocumentLabel+" Page");
    }
    public void getBBImpairmentPredictorTool() {
        businessBankingHelper.verifyAndClickElement( BBImpairmentPredictorTool, BBImpairmentPredictorToolLabel);
    }
    public void verifyBBImpairmentPredictorTool()  {
        businessBankingHelper.verifyPage(BBImpairmentPredictorToolLabel, BBImpairmentPredictorTool);
        businessBankingHelper.takeSnapShot(BBImpairmentPredictorToolLabel+" Page");
    }
    public void getWholeViewTV() {
        businessBankingHelper.verifyAndClickElement( wholeViewTV, wholeViewTVLabel);
    }
    public void verifyWholeViewTV()  {
        businessBankingHelper.verifyPage(wholeViewTVLabel, wholeViewTV);
        businessBankingHelper.takeSnapShot(wholeViewTVLabel+" Page");
    }
}
