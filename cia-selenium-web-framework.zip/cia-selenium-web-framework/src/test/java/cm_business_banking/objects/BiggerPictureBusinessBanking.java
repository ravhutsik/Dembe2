package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class BiggerPictureBusinessBanking {


    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String BrochuresLabel = "Brochures";
    final String VideosLabel = "Videos";
    final String RadioAdsLabel = "Radio Ads";
    final String BankerToolkitLabel = "Banker Toolkit";

    String [] Brochures = {"Need-state Brouchures"};
    String [] Videos  = {"Bigger-Picture Banking 45 Sec TVC ","TV Advert 2","TV Advert 3","Bigger-picture Business Banking  AV ","Economic Overview Busi Radebe"};
    String [] RadioAds  = {"TV Advert 1","TV Advert 2","Business Banking Bigger Picture banking radio ads ",
                            "Financing Radio Advert","Radio Clip 1 English","Radio Clip 2 English","Radio Clip 3 English",
                            "Transactional Radio Clip","Radio Clip 1 Afrikaans","Radio Clip 2 Afrikaans","Radio Clip 3 Afrikaans"};
    String [] BankerToolkit  = {"Banker Toolkit"};

    public BiggerPictureBusinessBanking(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getBrochures() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(BrochuresLabel), BrochuresLabel);
        businessBankingHelper.performOperation(Brochures);
    }

    public void getVideos() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(VideosLabel), VideosLabel);
        businessBankingHelper.performOperation(Videos);
    }

    public void getRadioAds() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(RadioAdsLabel), RadioAdsLabel);
        businessBankingHelper.performOperation(RadioAds);
    }

    public void getBankerToolkit() {
        businessBankingHelper.verifyAndClickElement( businessBankingHelper.getWebElement(BankerToolkitLabel), BankerToolkitLabel);
        businessBankingHelper.performOperation(BankerToolkit);
    }

}
