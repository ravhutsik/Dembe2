package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class NationalCreditAct {


    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String automatedBureauCallsLabel = "Automated Bureau Calls";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ automatedBureauCallsLabel +"']")
    public WebElement automatedBureauCalls;

    public NationalCreditAct(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getAutomatedBureauCalls() {
        businessBankingHelper.verifyAndClickElement( automatedBureauCalls, automatedBureauCallsLabel);
    }
    public void verifyAutomatedBureauCalls()  {
        businessBankingHelper.verifyPage(automatedBureauCallsLabel, automatedBureauCalls);
        businessBankingHelper.takeSnapShot(automatedBureauCallsLabel+" Page");
    }
}
