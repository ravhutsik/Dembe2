package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Fuel {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String bpLabel = "BP";
    final String texanPetroleumLabel = "Texan Petroleum";
    final String greenPetroleumLabel = "Green Petroleum";
    final String elegantFuelLabel = "Elegant Fuel";
    final String vivaOilLabel = "VIVA OIL";
    final String pumaLabel = "Puma";
    final String questPetroleumLabel = "quest petroleum";
    final String engenLabel = "Engen";
    final String sasolLabel = "Sasol";
    final String shellLabel = "Shell";
    final String totalLabel = "Total";
    final String MPTPetroleumLabel = "MBT Petroleum";
    final String globalOilLabel = "Global Oil";
    final String caltexLabel = "Caltex";
    final String xfuelsLabel = "xfuels";
    final String micarenExcelLabel = "Micaren excel";

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ bpLabel +"']")
    public WebElement bp;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ texanPetroleumLabel +"']")
    public WebElement texanPetroleum;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ greenPetroleumLabel +"']")
    public WebElement greenPetroleum;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ elegantFuelLabel +"']")
    public WebElement elegantFuel;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ vivaOilLabel +"']")
    public WebElement vivaOil;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ pumaLabel +"']")
    public WebElement puma;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ questPetroleumLabel +"']")
    public WebElement questPetroleum;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ engenLabel +"']")
    public WebElement engen;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ sasolLabel +"']")
    public WebElement sasol;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ shellLabel +"']")
    public WebElement shell;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ totalLabel +"']")
    public WebElement total;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ MPTPetroleumLabel +"']")
    public WebElement MPTPetroleum;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ globalOilLabel +"']")
    public WebElement globalOil;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ caltexLabel +"']")
    public WebElement caltex;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ xfuelsLabel +"']")
    public WebElement xfuels;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ micarenExcelLabel +"']")
    public WebElement micarenExcel;

    public Fuel(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getBP() {
        businessBankingHelper.verifyAndClickElement(bp, bpLabel);
    }
    public void verifyBP()  {
        businessBankingHelper.verifyPage(bpLabel, bp);
        businessBankingHelper.takeSnapShot(bpLabel +" Page");
    }
    public void getTexanPetroleum() {
        businessBankingHelper.verifyAndClickElement(texanPetroleum, texanPetroleumLabel);
    }
    public void verifyTexanPetroleum()  {
        businessBankingHelper.verifyPage(texanPetroleumLabel, texanPetroleum);
        businessBankingHelper.takeSnapShot(texanPetroleumLabel +" Page");
    }
    public void getGreenPetroleum() {
        businessBankingHelper.verifyAndClickElement(greenPetroleum, greenPetroleumLabel);
    }
    public void verifyGreenPetroleum()  {
        businessBankingHelper.verifyPage(greenPetroleumLabel, greenPetroleum);
        businessBankingHelper.takeSnapShot(greenPetroleumLabel +" Page");
    }
    public void getElegantFuel() {
        businessBankingHelper.verifyAndClickElement(elegantFuel, elegantFuelLabel);
    }
    public void verifyElegantFuel()  {
        businessBankingHelper.verifyPage(elegantFuelLabel, elegantFuel);
        businessBankingHelper.takeSnapShot(elegantFuelLabel +" Page");
    }
    public void getVivaOil() {
        businessBankingHelper.verifyAndClickElement(vivaOil, vivaOilLabel);
    }
    public void verifyVivaOil()  {
        businessBankingHelper.verifyPage(vivaOilLabel, vivaOil);
        businessBankingHelper.takeSnapShot(vivaOilLabel +" Page");
    }
    public void getPuma() {
        businessBankingHelper.verifyAndClickElement(puma, pumaLabel);
    }
    public void verifyPuma()  {
        businessBankingHelper.verifyPage(pumaLabel, puma);
        businessBankingHelper.takeSnapShot(pumaLabel +" Page");
    }
    public void getQuestPetroleum() {
        businessBankingHelper.verifyAndClickElement(questPetroleum, questPetroleumLabel);
    }
    public void verifyQuestPetroleum()  {
        businessBankingHelper.verifyPage(questPetroleumLabel, questPetroleum);
        businessBankingHelper.takeSnapShot(questPetroleumLabel +" Page");
    }
    public void getEngen() {
        businessBankingHelper.verifyAndClickElement(engen, engenLabel);
    }
    public void verifyEngen()  {
        businessBankingHelper.verifyPage(engenLabel, engen);
        businessBankingHelper.takeSnapShot(engenLabel +" Page");
    }
    public void getSasol() {
        businessBankingHelper.verifyAndClickElement(sasol, sasolLabel);
    }
    public void verifySasol()  {
        businessBankingHelper.verifyPage(sasolLabel, sasol);
        businessBankingHelper.takeSnapShot(sasolLabel +" Page");
    }
    public void getShell() {
        businessBankingHelper.verifyAndClickElement(shell, shellLabel);
    }
    public void verifyShell()  {
        businessBankingHelper.verifyPage(shellLabel, shell);
        businessBankingHelper.takeSnapShot(shellLabel +" Page");
    }
    public void getTotal() {
        businessBankingHelper.verifyAndClickElement(total, totalLabel);
    }
    public void verifyTotal()  {
        businessBankingHelper.verifyPage(totalLabel, total);
        businessBankingHelper.takeSnapShot(totalLabel +" Page");
    }
    public void getMPTPetroleum() {
        businessBankingHelper.verifyAndClickElement(MPTPetroleum, MPTPetroleumLabel);
    }
    public void verifyMPTPetroleum()  {
        businessBankingHelper.verifyPage(MPTPetroleumLabel, MPTPetroleum);
        businessBankingHelper.takeSnapShot(MPTPetroleumLabel +" Page");
    }
    public void getGlobalOil() {
        businessBankingHelper.verifyAndClickElement(globalOil, globalOilLabel);
    }
    public void verifyGlobalOil()  {
        businessBankingHelper.verifyPage(globalOilLabel, globalOil);
        businessBankingHelper.takeSnapShot(globalOilLabel +" Page");
    }
    public void getCaltex() {
        businessBankingHelper.verifyAndClickElement(caltex, caltexLabel);
    }
    public void verifyCaltex()  {
        businessBankingHelper.verifyPage(caltexLabel, caltex);
        businessBankingHelper.takeSnapShot(caltexLabel +" Page");
    }
    public void getXfuels() {
        businessBankingHelper.verifyAndClickElement(xfuels, xfuelsLabel);
    }
    public void verifyXfuels()  {
        businessBankingHelper.verifyPage(xfuelsLabel, xfuels);
        businessBankingHelper.takeSnapShot(xfuelsLabel +" Page");
    }
    public void getMicarenExcel() {
        businessBankingHelper.verifyAndClickElement(micarenExcel, micarenExcelLabel);
    }
    public void verifyMicarenExcel()  {
        businessBankingHelper.verifyPage(micarenExcelLabel, micarenExcel);
        businessBankingHelper.takeSnapShot(micarenExcelLabel +" Page");
    }
}
