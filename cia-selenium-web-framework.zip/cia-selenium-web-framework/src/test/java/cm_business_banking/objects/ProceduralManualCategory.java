package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class ProceduralManualCategory {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String watchListLabel = "E-Watchlist";
    final String impairmentWriteOffProceduresLabel = "Impairment and Write-off Procedures";
    final String internalBureauCreditProcedureLabel = "INTERNAL BUREAU CREDIT PROCEDURES";
    final String nedbankOwnedPropertyLabel = "NEDBANK OWNED PROPERTIES (NOPS)";
    final String recoveriesProceduralManualLabel = "RECOVERIES PROCEDURAL MANUAL";
    final String experianProcedureLabel = "EXPERIAN PROCEDURES";
    final String actualRecoveryQuickReferenceLabel = "ACTUAL RECOVERIES QUICK REFERENCE GUIDE";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ watchListLabel +"']")
    public WebElement watchList;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ impairmentWriteOffProceduresLabel +"']")
    public WebElement impairmentWriteOffProcedures;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ internalBureauCreditProcedureLabel +"']")
    public WebElement internalBureauCreditProcedure;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ nedbankOwnedPropertyLabel +"']")
    public WebElement nedbankOwnedProperty;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ recoveriesProceduralManualLabel +"']")
    public WebElement recoveriesProceduralManual;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ experianProcedureLabel +"']")
    public WebElement experianProcedure;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ actualRecoveryQuickReferenceLabel +"']")
    public WebElement actualRecoveryQuickReference;


    public ProceduralManualCategory(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getWatchList() {
        businessBankingHelper.verifyAndClickElement( watchList, watchListLabel);
    }
    public void verifyWatchList() {
        businessBankingHelper.verifyPage(watchListLabel, watchList);
        businessBankingHelper.takeSnapShot(watchListLabel+" Page");
    }

       public void getImpairmentWriteOffProcedures() {
        businessBankingHelper.verifyAndClickElement( impairmentWriteOffProcedures, impairmentWriteOffProceduresLabel);
    }
    public void verifyImpairmentWriteOffProcedures()  {
        businessBankingHelper.verifyPage(impairmentWriteOffProceduresLabel, impairmentWriteOffProcedures);
        businessBankingHelper.takeSnapShot(impairmentWriteOffProceduresLabel +" Page");
    }

       public void getInternalBureauCreditProcedure() {
        businessBankingHelper.verifyAndClickElement( internalBureauCreditProcedure, internalBureauCreditProcedureLabel);
    }
    public void verifyInternalBureauCreditProcedure()  {
        businessBankingHelper.verifyPage(internalBureauCreditProcedureLabel, internalBureauCreditProcedure);
        businessBankingHelper.takeSnapShot(internalBureauCreditProcedureLabel+" Page");
    }

       public void getNedbankOwnedProperty() {
        businessBankingHelper.verifyAndClickElement( nedbankOwnedProperty, nedbankOwnedPropertyLabel);
    }
    public void verifyNedbankOwnedProperty()  {
        businessBankingHelper.verifyPage(nedbankOwnedPropertyLabel, nedbankOwnedProperty);
        businessBankingHelper.takeSnapShot(nedbankOwnedPropertyLabel+" Page");
    }

       public void getRecoveriesProceduralManual() {
        businessBankingHelper.verifyAndClickElement( recoveriesProceduralManual, recoveriesProceduralManualLabel);
    }
    public void verifyRecoveriesProceduralManual()  {
        businessBankingHelper.verifyPage(recoveriesProceduralManualLabel, recoveriesProceduralManual);
        businessBankingHelper.takeSnapShot(recoveriesProceduralManualLabel+" Page");
    }

       public void getExperianProcedure() {
        businessBankingHelper.verifyAndClickElement( experianProcedure, experianProcedureLabel);
    }
    public void verifyExperianProcedure()  {
        businessBankingHelper.verifyPage(experianProcedureLabel, experianProcedure);
        businessBankingHelper.takeSnapShot(experianProcedureLabel+" Page");
    }

       public void getActualRecoveryQuickReference() {
        businessBankingHelper.verifyAndClickElement( actualRecoveryQuickReference, actualRecoveryQuickReferenceLabel);
    }
    public void verifyActualRecoveryQuickReference()  {
        businessBankingHelper.verifyPage(actualRecoveryQuickReferenceLabel, actualRecoveryQuickReference);
        businessBankingHelper.takeSnapShot(actualRecoveryQuickReferenceLabel+" Page");
    }


}
