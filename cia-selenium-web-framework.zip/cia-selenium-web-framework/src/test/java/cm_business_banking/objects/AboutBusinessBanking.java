package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class AboutBusinessBanking {
    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String wholeviewBusinessBankingBankerGuideLabel = "Whole-view Business Banking Banker guide";
    final String BBBackgroundAndHistoryLabel = "BB Background and History";
    final String BBPurposeAndClientExperienceLabel = "BB Purpose and Client Experience ";
    final String BBStructureLabel = "BB Structure ";
    final String BBValuePropositionLabel = "BB Value Proposition";
    final String BBStructureAreaOfficesLabel = "BB Structure Area Offices";
    final String AboutOurCSTLabel = "About our CST's";
    final String strategicObjectiveLabel = "Strategic Objective";
    final String BBPastSuccessesLabel = "BB Past Successes";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ wholeviewBusinessBankingBankerGuideLabel +"']")
    public WebElement wholeviewBusinessBankingBankerGuide;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BBBackgroundAndHistoryLabel +"']")
    public WebElement BBBackgroundAndHistory;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BBPurposeAndClientExperienceLabel +"']")
    public WebElement BBPurposeAndClientExperience;


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BBStructureLabel +"']")
    public WebElement BBStructure;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BBValuePropositionLabel +"']")
    public WebElement BBValueProposition;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BBStructureAreaOfficesLabel +"']")
    public WebElement BBStructureAreaOffices;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ AboutOurCSTLabel +"']")
    public WebElement AboutOurCST;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ strategicObjectiveLabel +"']")
    public WebElement strategicObjective;


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BBPastSuccessesLabel +"']")
    public WebElement BBPastSuccesses;



    public AboutBusinessBanking(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getWholeviewBusinessBankingBankerGuide() {
        businessBankingHelper.verifyAndClickElement(wholeviewBusinessBankingBankerGuide, wholeviewBusinessBankingBankerGuideLabel);
    }
    public void getBBBackgroundAndHistory() {
        businessBankingHelper.verifyAndClickElement(BBBackgroundAndHistory, BBBackgroundAndHistoryLabel);
    }
    public void getBBPurposeAndClientExperience() {
        businessBankingHelper.verifyAndClickElement(BBPurposeAndClientExperience, BBPurposeAndClientExperienceLabel);
    }
    public void getBBStructure() {
        businessBankingHelper.verifyAndClickElement(BBStructure, BBStructureLabel);
    }
    public void getBBValueProposition() {
        businessBankingHelper.verifyAndClickElement(BBValueProposition, BBValuePropositionLabel);
    }
    public void getBBStructureAreaOffices() {
        businessBankingHelper.verifyAndClickElement(BBStructureAreaOffices, BBStructureAreaOfficesLabel);
    }
    public void getAboutOurCST() {
        businessBankingHelper.verifyAndClickElement(AboutOurCST, AboutOurCSTLabel);
    }

    public void getStrategicObjective() {
        businessBankingHelper.verifyAndClickElement(strategicObjective, strategicObjectiveLabel);
    }

    public void getBBPastSuccesses() {
        businessBankingHelper.verifyAndClickElement(BBPastSuccesses, BBPastSuccessesLabel);
    }

    public void verifyWholeviewBusinessBankingBankerGuide()  {
        businessBankingHelper.verifyPage(wholeviewBusinessBankingBankerGuideLabel, wholeviewBusinessBankingBankerGuide);
        businessBankingHelper.takeSnapShot(wholeviewBusinessBankingBankerGuideLabel+" Page");
    }
    public void verifyBBBackgroundAndHistory()  {
        businessBankingHelper.verifyPage(BBBackgroundAndHistoryLabel, BBBackgroundAndHistory);
        businessBankingHelper.takeSnapShot(BBBackgroundAndHistoryLabel+" Page");
    }
    public void verifyBBPurposeAndClientExperience()  {
        businessBankingHelper.verifyPage(BBPurposeAndClientExperienceLabel, BBPurposeAndClientExperience);
        businessBankingHelper.takeSnapShot(BBPurposeAndClientExperienceLabel+" Page");
    }

    public void verifyBBStructure()  {
        businessBankingHelper.verifyPage(BBStructureLabel, BBStructure);
        businessBankingHelper.takeSnapShot(BBStructureLabel+" Page");
    }
    public void verifyBBValueProposition()  {
        businessBankingHelper.verifyPage(BBValuePropositionLabel, BBValueProposition);
        businessBankingHelper.takeSnapShot(BBValuePropositionLabel+" Page");
    }
    public void verifyBBStructureAreaOffices()  {
        businessBankingHelper.verifyPage(BBStructureAreaOfficesLabel, BBStructureAreaOffices);
        businessBankingHelper.takeSnapShot(BBStructureAreaOfficesLabel+" Page");
    } public void verifyAboutOurCST()  {
        businessBankingHelper.verifyPage(AboutOurCSTLabel, AboutOurCST);
        businessBankingHelper.takeSnapShot(AboutOurCSTLabel+" Page");
    }
    public void verifyStrategicObjective()  {
        businessBankingHelper.verifyPage(BBValuePropositionLabel, BBValueProposition);
        businessBankingHelper.takeSnapShot(BBValuePropositionLabel+" Page");
    }
    public void verifyBBPastSuccessesLabel()  {
        businessBankingHelper.verifyPage(BBPastSuccessesLabel, BBPastSuccesses);
        businessBankingHelper.takeSnapShot(BBPastSuccessesLabel+" Page");
    }
}
