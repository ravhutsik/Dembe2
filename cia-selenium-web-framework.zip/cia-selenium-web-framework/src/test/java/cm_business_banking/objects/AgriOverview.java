package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class AgriOverview {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String overviewAgricultureIndustryLabel = "Overview of the agriculture industry";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ overviewAgricultureIndustryLabel +"']")
    public WebElement overviewAgricultureIndustry;

    public AgriOverview(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getOverviewAgricultureIndustry() {
        businessBankingHelper.verifyAndClickElement( overviewAgricultureIndustry, overviewAgricultureIndustryLabel);
    }
    public void verifyOverviewAgricultureIndustry()  {
        businessBankingHelper.verifyPage(overviewAgricultureIndustryLabel, overviewAgricultureIndustry);
        businessBankingHelper.takeSnapShot(overviewAgricultureIndustryLabel +" Page");
    }
}
