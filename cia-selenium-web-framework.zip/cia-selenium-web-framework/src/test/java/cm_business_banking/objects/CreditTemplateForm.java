package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import cm_utils.DriverFactory;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class CreditTemplateForm {
    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;

    final String FIND_CREDIT_TEMPLATES_FORMS_label = "FIND CREDIT TEMPLATES or FORMS";
    final String EXTERNAL_CLIENT_COMMUNICATIONS_Label = "EXTERNAL CLIENT COMMUNICATIONS";
    final String INTERNAL_TEMPLATES_Label = "INTERNAL TEMPLATES";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ FIND_CREDIT_TEMPLATES_FORMS_label +"']")
    public WebElement FIND_CREDIT_TEMPLATES_FORMS;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ EXTERNAL_CLIENT_COMMUNICATIONS_Label +"']")
    public WebElement EXTERNAL_CLIENT_COMMUNICATIONS;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ INTERNAL_TEMPLATES_Label +"']")
    public WebElement INTERNAL_TEMPLATES;


    public CreditTemplateForm(WebDriver driver) {
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(this.driver);
        PageFactory.initElements(driver, this);
    }

    public void getFindCreditTemplateForms() {
        businessBankingHelper.verifyAndClickElement(FIND_CREDIT_TEMPLATES_FORMS_label, FIND_CREDIT_TEMPLATES_FORMS, FIND_CREDIT_TEMPLATES_FORMS_label);
    }

    public void getExternalClientCommunication() {
        businessBankingHelper.verifyAndClickElement(EXTERNAL_CLIENT_COMMUNICATIONS_Label, EXTERNAL_CLIENT_COMMUNICATIONS, EXTERNAL_CLIENT_COMMUNICATIONS_Label);
    }

    public void getInternalTemplates() {
        businessBankingHelper.verifyAndClickElement(INTERNAL_TEMPLATES_Label, INTERNAL_TEMPLATES, INTERNAL_TEMPLATES_Label);
    }
}
