package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class ApplicationToolsCategory {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String applicationToolsHyperlinkLabel = "APPLICATION TOOLS HYPERLINKS";
    final String globalBondCapturingSheetLabel = "GLOBAL BOND CAPTURING SHEET";
    final String bankCodeCalculatorLabel = "BANK CODE CALCULATOR";
    final String discretionaryMandateScheduleLabel = "DISCRETIONARY MANDATE SCHEDULE";
    final String debtorsAnalysisSheetLabel = "DEBTORS ANALYSIS SHEET";
    final String NCAInitiationFeeCalculatorLabel = "NCA INITIATION FEE CALCULATOR";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ applicationToolsHyperlinkLabel +"']")
    public WebElement applicationToolsHyperlink;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ globalBondCapturingSheetLabel +"']")
    public WebElement globalBondCapturingSheet;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ bankCodeCalculatorLabel +"']")
    public WebElement bankCodeCalculator;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ discretionaryMandateScheduleLabel +"']")
    public WebElement discretionaryMandateSchedule;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ debtorsAnalysisSheetLabel +"']")
    public WebElement debtorsAnalysisSheet;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ NCAInitiationFeeCalculatorLabel +"']")
    public WebElement NCAInitiationFeeCalculator;

    public ApplicationToolsCategory(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getApplicationToolsHyperlink() {
        businessBankingHelper.verifyAndClickElement( applicationToolsHyperlink, applicationToolsHyperlinkLabel);
    }
    public void verifyApplicationToolsHyperlink(){
        businessBankingHelper.verifyPage(applicationToolsHyperlinkLabel, applicationToolsHyperlink);
        businessBankingHelper.takeSnapShot(applicationToolsHyperlinkLabel+" Page");
    }
        public void getGlobalBondCapturingSheet() {
        businessBankingHelper.verifyAndClickElement( globalBondCapturingSheet, globalBondCapturingSheetLabel);
    }
    public void verifyGlobalBondCapturingSheet() {
        businessBankingHelper.verifyPage(globalBondCapturingSheetLabel, globalBondCapturingSheet);
        businessBankingHelper.takeSnapShot(globalBondCapturingSheetLabel+" Page");
    }
        public void getBankCodeCalculator() {
        businessBankingHelper.verifyAndClickElement( bankCodeCalculator, bankCodeCalculatorLabel);
    }
    public void verifyBankCodeCalculator()  {
        businessBankingHelper.verifyPage(bankCodeCalculatorLabel, bankCodeCalculator);
        businessBankingHelper.takeSnapShot(bankCodeCalculatorLabel+" Page");
    }
        public void getDiscretionaryMandateSchedule() {
        businessBankingHelper.verifyAndClickElement( discretionaryMandateSchedule, discretionaryMandateScheduleLabel);
    }
    public void verifyDiscretionaryMandateSchedule()  {
        businessBankingHelper.verifyPage(discretionaryMandateScheduleLabel, discretionaryMandateSchedule);
        businessBankingHelper.takeSnapShot(discretionaryMandateScheduleLabel+" Page");
    }
    public void getDebtorsAnalysisSheet() {
        businessBankingHelper.verifyAndClickElement( debtorsAnalysisSheet, debtorsAnalysisSheetLabel);
    }
    public void verifyOperationalManagement()  {
        businessBankingHelper.verifyPage(debtorsAnalysisSheetLabel, debtorsAnalysisSheet);
        businessBankingHelper.takeSnapShot(debtorsAnalysisSheetLabel+" Page");
    }
    
    public void getNCAInitiationFeeCalculator() {
        businessBankingHelper.verifyAndClickElement( NCAInitiationFeeCalculator, NCAInitiationFeeCalculatorLabel);
    }
    public void verifyNCAInitiationFeeCalculator() {
        businessBankingHelper.verifyPage(NCAInitiationFeeCalculatorLabel, NCAInitiationFeeCalculator);
        businessBankingHelper.takeSnapShot(NCAInitiationFeeCalculatorLabel+" Page");
    }
    
    
    
}
