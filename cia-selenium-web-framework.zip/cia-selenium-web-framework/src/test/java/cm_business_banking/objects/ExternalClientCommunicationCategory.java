package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class ExternalClientCommunicationCategory {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;

    final String CREDIT_GRANTING_LABEL = "CREDIT GRANTING";
    final String CREDIT_ADMINISTRATION_LABEL = "CREDIT ADMINISTRATION";
    final String CREDIT_PORTFOLIO_MANAGEMENT_LABEL = "CREDIT PORTFOLIO MANAGEMENT";
    final String DEBT_ENFORCEMENT_CREDIT_RISK_RECOVERIES_LABEL = "DEBT ENFORCEMENT: CREDIT RISK & RECOVERIES";
    final String DEBT_ENFORCEMENT_CREDIT_RISK_RECOVERIES_Page = "DEBT ENFORCEMENT";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ CREDIT_GRANTING_LABEL +"']")
    public WebElement CREDIT_GRANTING;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ CREDIT_ADMINISTRATION_LABEL +"']")
    public WebElement CREDIT_ADMINISTRATION;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ CREDIT_PORTFOLIO_MANAGEMENT_LABEL +"']")
    public WebElement CREDIT_PORTFOLIO_MANAGEMENT;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ DEBT_ENFORCEMENT_CREDIT_RISK_RECOVERIES_LABEL +"']")
    public WebElement DEBT_ENFORCEMENT_CREDIT_RISK_RECOVERIES;

    public ExternalClientCommunicationCategory(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getCreditGranting() {
        businessBankingHelper.verifyAndClickElement( CREDIT_GRANTING, CREDIT_GRANTING_LABEL);
    }

    public void getCreditAdministration() {
        businessBankingHelper.verifyAndClickElement( CREDIT_ADMINISTRATION, CREDIT_ADMINISTRATION_LABEL);
    }

    public void getCreditPortfolioManagement() {
        businessBankingHelper.verifyAndClickElement( CREDIT_PORTFOLIO_MANAGEMENT, CREDIT_PORTFOLIO_MANAGEMENT_LABEL);
    }

    public void getDebtEnforcementCreditRiskRecovery() {
        businessBankingHelper.verifyAndClickElement( DEBT_ENFORCEMENT_CREDIT_RISK_RECOVERIES, DEBT_ENFORCEMENT_CREDIT_RISK_RECOVERIES_Page);
    }
    public void verifyCreditGranting() throws Exception {
        businessBankingHelper.verifyPage(CREDIT_GRANTING_LABEL, CREDIT_GRANTING);
        businessBankingHelper.takeSnapShot(CREDIT_GRANTING_LABEL+" Page");
    }

    public void verifyCreditAdministration() throws Exception {
        businessBankingHelper.verifyPage(CREDIT_ADMINISTRATION_LABEL, CREDIT_ADMINISTRATION);
        businessBankingHelper.takeSnapShot(CREDIT_ADMINISTRATION_LABEL+" Page");
    }

    public void verifyCreditPortfolioManagement() throws Exception {
        businessBankingHelper.verifyPage(CREDIT_PORTFOLIO_MANAGEMENT_LABEL, CREDIT_PORTFOLIO_MANAGEMENT);
        businessBankingHelper.takeSnapShot(CREDIT_PORTFOLIO_MANAGEMENT_LABEL+" Page");
    }

    public void verifyDebtEnforcementCreditRiskRecovery() throws Exception {
        businessBankingHelper.verifyPage(DEBT_ENFORCEMENT_CREDIT_RISK_RECOVERIES_LABEL, DEBT_ENFORCEMENT_CREDIT_RISK_RECOVERIES);
        businessBankingHelper.takeSnapShot(DEBT_ENFORCEMENT_CREDIT_RISK_RECOVERIES_Page+" Page");
    }
}
