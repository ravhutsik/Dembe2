package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class HomeCategory {

    private final WebDriver driver;

    @FindBy(how = How.XPATH, using = "//*[@id=\"CategoriesDiv\"]")
    public WebElement BBHomePage;

    final String biggerPictureBusinessBankingLabel = "Bigger-Picture Business Banking";
    final String coreBankingSolutionsLabel = "Core Banking Solutions";
    final String ERCG_LABEL = "Enterprisewide Risk, Compliance and Governance";
    final String creditLabel = "Credit";
    final String specialisationLabel = "Specialisation";
    final String PRODUCTS_LABEL = "Products";
    final String MARKETING_AND_COMMUNICATION = "Marketing and Communications";
    final String LEARNING_AND_DEVELOPMENT_LABEL = "Learning and Development";
    final String PRICING_LABEL = "Pricing";
    final String managedEvolutionLabel = "Managed Evolution";
    final String MORE_CATEGORIES_LABEL = "More Categories";
    final String topLevelCategory = "New Top Level Category";
    final String salesOpportunitiesLabel = "My Sales Opportunities";
    final String principleClientPortfolioLabel = "Principle Client Portfolio";

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ biggerPictureBusinessBankingLabel +"']")
    public WebElement biggerPictureBusinessBanking;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ coreBankingSolutionsLabel +"']")
    public WebElement coreBankingSolutions;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ ERCG_LABEL +"']")
    public WebElement enterpriseWideRiskComplianceAndGovernance;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ creditLabel +"']")
    public WebElement credit;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ specialisationLabel +"']")
    public WebElement specialisation;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ salesOpportunitiesLabel +"']")
    public WebElement salesOpportunities;
     @FindBy(how = How.XPATH, using = "//*[text() = '"+ principleClientPortfolioLabel +"']")
    public WebElement principleClientPortfolio;




    @FindBy(how = How.XPATH, using = "//*[@id=\"CategoriesDiv\"]/a[6]/div/div[4]/label")
    public WebElement products;
    @FindBy(how = How.XPATH, using = "//*[@id=\"CategoriesDiv\"]/a[7]/div/div[4]/label")
    public WebElement marketingAndCommunications;
    @FindBy(how = How.XPATH, using = "//*[@id=\"CategoriesDiv\"]/a[8]/div/div[4]/label")
    public WebElement learningAndDevelopment;
    @FindBy(how = How.XPATH, using = "//*[@id=\"CategoriesDiv\"]/a[9]/div/div[4]/label")
    public WebElement pricing;
    @FindBy(how = How.XPATH, using = "//*[@id=\"CategoriesDiv\"]/a[10]/div/div[4]/label")
    public WebElement managedEvolution;
    @FindBy(how = How.XPATH, using = "//*[@id=\"CategoriesDiv\"]/a[12]/div/div[4]/label")
    public WebElement moreCategories;
    @FindBy(how = How.XPATH, using = "//*[@id=\"CategoriesDiv\"]/a[12]/div/div[4]/label")
    public WebElement newTopLevelCategory;



    BusinessBankingHelper businessBankingHelper;


    public HomeCategory(WebDriver driver) {
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(this.driver);
        PageFactory.initElements(driver, this);
    }

    public void getBiggerPictureBusinessBanking() {
        businessBankingHelper.verifyAndClickElement(biggerPictureBusinessBanking, biggerPictureBusinessBankingLabel);
    }

    public void getCoreBankingSolutions() {
        businessBankingHelper.verifyAndClickElement(coreBankingSolutions, coreBankingSolutionsLabel);
    }

    public void getEnterpriseWideRiskComplianceAndGovernance() {
        businessBankingHelper.verifyAndClickElement( enterpriseWideRiskComplianceAndGovernance, ERCG_LABEL);
    }

    public void getCredit() {
        businessBankingHelper.verifyAndClickElement(credit, creditLabel);
    }

    public void getSpecialisation() {
        businessBankingHelper.verifyAndClickElement(specialisation, specialisationLabel);
    }

    public void getProducts() {
        businessBankingHelper.verifyAndClickElement(PRODUCTS_LABEL, BBHomePage, PRODUCTS_LABEL);
    }

    public void getMarketingAndCommunications() {
        businessBankingHelper.verifyAndClickElement(MARKETING_AND_COMMUNICATION, BBHomePage, MARKETING_AND_COMMUNICATION);
    }

    public void getLearningAndDevelopment() {
        businessBankingHelper.verifyAndClickElement(LEARNING_AND_DEVELOPMENT_LABEL, BBHomePage, LEARNING_AND_DEVELOPMENT_LABEL);
    }

    public void getPricing() {
        businessBankingHelper.verifyAndClickElement(PRICING_LABEL, BBHomePage, PRICING_LABEL);
    }

    public void getManagedEvolution() {
        businessBankingHelper.verifyAndClickElement(managedEvolutionLabel, BBHomePage, managedEvolutionLabel);
    }

    public void getMoreCategories() {
        businessBankingHelper.verifyAndClickElement(MORE_CATEGORIES_LABEL, BBHomePage, MORE_CATEGORIES_LABEL);
    }

    public void getNewTopLevelCategory() {
        businessBankingHelper.verifyAndClickElement(topLevelCategory, BBHomePage, topLevelCategory);
    }
    public void getSalesOpportunities() {
        businessBankingHelper.verifyAndClickElement(salesOpportunities, salesOpportunitiesLabel);
    }

    public void getPrincipleClientPortfolio() {
        businessBankingHelper.verifyAndClickElement(principleClientPortfolio, principleClientPortfolioLabel);
    }




}
