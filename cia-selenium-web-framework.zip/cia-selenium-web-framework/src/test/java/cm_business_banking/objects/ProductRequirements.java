package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class ProductRequirements {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String publicSectorProductRequirementsLabel = "Public Sector Product Requirements";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ publicSectorProductRequirementsLabel +"']")
    public WebElement publicSectorProductRequirements;

    public ProductRequirements(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getPublicSectorProductRequirements() {
        businessBankingHelper.verifyAndClickElement( publicSectorProductRequirements, publicSectorProductRequirementsLabel);
    }
    public void verifyPublicSectorProductRequirements()  {
        businessBankingHelper.verifyPage(publicSectorProductRequirementsLabel, publicSectorProductRequirements);
        businessBankingHelper.takeSnapShot(publicSectorProductRequirementsLabel +" Page");
    }
}
