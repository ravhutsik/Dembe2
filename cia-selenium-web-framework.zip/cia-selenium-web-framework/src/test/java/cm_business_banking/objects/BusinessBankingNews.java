package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class BusinessBankingNews {
    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String BBNews14MarchLabel = "BB News 14 March";
    final String BBNews09MarchLabel = "BB News 09 March";
    final String NedbankAccountingThirdPartyVendorsLabel = "Nedbank Accounting and other 3rd party vendors";
    final String NetBankBusinessNotificationsAlertsLabel = "NetBank Business notifications and alerts ";
    final String NetBankBusinessEnhancementsLabel = "NetBank Business enhancements";
    final String BBNews29JuneLabel = "BB News 29 June";
    final String BBNews1July3Label = "Business Banking News 1 July";
    final String BusinessBankingNews4July2016Label = "Business Banking News 4 July 2016";
    final String BBNews15July2016Label = "BB News 15 July 2016";
    final String BBNews13JulyLabel = "BB News 13 July";
    final String BBNews08July2016Label = "BB News 8 July 2016";
    final String SBVCashCentreInSelbyRelocationLabel = "SBV cash centre in Selby relocation ";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BBNews14MarchLabel +"']")
    public WebElement BBNews14March;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BBNews09MarchLabel +"']")
    public WebElement BBNews09March;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ NedbankAccountingThirdPartyVendorsLabel +"']")
    public WebElement NedbankAccountingThirdPartyVendors;


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ NetBankBusinessNotificationsAlertsLabel +"']")
    public WebElement NetBankBusinessNotificationsAlerts;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ NetBankBusinessEnhancementsLabel +"']")
    public WebElement NetBankBusinessEnhancements;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BBNews29JuneLabel +"']")
    public WebElement BBNews29June;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BBNews1July3Label +"']")
    public WebElement BBNews1July3;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BusinessBankingNews4July2016Label +"']")
    public WebElement BusinessBankingNews4July2016;


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BBNews15July2016Label +"']")
    public WebElement BBNews15July2016;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BBNews13JulyLabel +"']")
    public WebElement BBNews13July;


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BBNews08July2016Label +"']")
    public WebElement BBNews08July2016;


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ SBVCashCentreInSelbyRelocationLabel +"']")
    public WebElement SBVCashCentreInSelbyRelocation;



    public BusinessBankingNews(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getBBNews14March() {
        businessBankingHelper.verifyAndClickElement(BBNews14March, BBNews14MarchLabel);
    }
    public void getBBNews09March() {
        businessBankingHelper.verifyAndClickElement(BBNews09March, BBNews09MarchLabel);
    }
    public void getNedbankAccountingThirdPartyVendors() {
        businessBankingHelper.verifyAndClickElement(NedbankAccountingThirdPartyVendors, NedbankAccountingThirdPartyVendorsLabel);
    }
    public void getNetBankBusinessNotificationsAlerts() {
        businessBankingHelper.verifyAndClickElement(NetBankBusinessNotificationsAlerts, NetBankBusinessNotificationsAlertsLabel);
    }
    public void getNetBankBusinessEnhancements() {
        businessBankingHelper.verifyAndClickElement(NetBankBusinessEnhancements, NetBankBusinessEnhancementsLabel);
    }
    public void getBBNews29June() {
        businessBankingHelper.verifyAndClickElement(BBNews29June, BBNews29JuneLabel);
    }
    public void getBBNews1July3() {
        businessBankingHelper.verifyAndClickElement(BBNews1July3, BBNews1July3Label);
    }

    public void getBusinessBankingNews4July2016() {
        businessBankingHelper.verifyAndClickElement(BusinessBankingNews4July2016, BusinessBankingNews4July2016Label);
    }

    public void getBBNews15July2016() {
        businessBankingHelper.verifyAndClickElement(BBNews15July2016, BBNews15July2016Label);
    }


    public void getBBNews13July() {
        businessBankingHelper.verifyAndClickElement(BBNews13July, BBNews13JulyLabel);
    }
    public void getBBNews08July2016() {
        businessBankingHelper.verifyAndClickElement(BBNews08July2016, BBNews08July2016Label);
    }
    public void getSBVCashCentreInSelbyRelocation() {
        businessBankingHelper.verifyAndClickElement(SBVCashCentreInSelbyRelocation, SBVCashCentreInSelbyRelocationLabel);
    }

    public void verifyBBNews14March()  {
        businessBankingHelper.verifyPage(BBNews14MarchLabel, BBNews14March);
        businessBankingHelper.takeSnapShot(BBNews14MarchLabel +" Page");
    }
    public void verifyBBNews09March()  {
        businessBankingHelper.verifyPage(BBNews09MarchLabel, BBNews09March);
        businessBankingHelper.takeSnapShot(BBNews09MarchLabel +" Page");
    }
    public void verifyNedbankAccountingThirdPartyVendors()  {
        businessBankingHelper.verifyPage(NedbankAccountingThirdPartyVendorsLabel, NedbankAccountingThirdPartyVendors);
        businessBankingHelper.takeSnapShot(NedbankAccountingThirdPartyVendorsLabel +" Page");
    }

    public void verifyNetBankBusinessNotificationsAlerts()  {
        businessBankingHelper.verifyPage(NetBankBusinessNotificationsAlertsLabel, NetBankBusinessNotificationsAlerts);
        businessBankingHelper.takeSnapShot(NetBankBusinessNotificationsAlertsLabel +" Page");
    }
    public void verifyNetBankBusinessEnhancements()  {
        businessBankingHelper.verifyPage(NetBankBusinessEnhancementsLabel, NetBankBusinessEnhancements);
        businessBankingHelper.takeSnapShot(NetBankBusinessEnhancementsLabel +" Page");
    }
    public void verifyBBNews29June()  {
        businessBankingHelper.verifyPage(BBNews29JuneLabel, BBNews29June);
        businessBankingHelper.takeSnapShot(BBNews29JuneLabel +" Page");
    } public void verifyBBNews1July3()  {
        businessBankingHelper.verifyPage(BBNews1July3Label, BBNews1July3);
        businessBankingHelper.takeSnapShot(BBNews1July3Label +" Page");
    }
    public void verifyBusinessBankingNews4July2016()  {
        businessBankingHelper.verifyPage(NetBankBusinessEnhancementsLabel, NetBankBusinessEnhancements);
        businessBankingHelper.takeSnapShot(NetBankBusinessEnhancementsLabel +" Page");
    }
    public void verifyBBNews15July2016()  {
        businessBankingHelper.verifyPage(BBNews15July2016Label, BBNews15July2016);
        businessBankingHelper.takeSnapShot(BBNews15July2016Label +" Page");
    }

    public void verifyBBNews13July()  {
        businessBankingHelper.verifyPage(BBNews13JulyLabel, BBNews13July);
        businessBankingHelper.takeSnapShot(BBNews13JulyLabel +" Page");
    }


    public void verifyBBNews08July2016()  {
        businessBankingHelper.verifyPage(BBNews08July2016Label, BBNews08July2016);
        businessBankingHelper.takeSnapShot(BBNews08July2016Label +" Page");
    }

    public void verifySBVCashCentreInSelbyRelocation()  {
        businessBankingHelper.verifyPage(SBVCashCentreInSelbyRelocationLabel, SBVCashCentreInSelbyRelocation);
        businessBankingHelper.takeSnapShot(SBVCashCentreInSelbyRelocationLabel +" Page");
    }


}
