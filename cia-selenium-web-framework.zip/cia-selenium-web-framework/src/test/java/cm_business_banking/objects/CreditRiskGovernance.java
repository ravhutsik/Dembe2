package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class CreditRiskGovernance {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String frameworkAndChartersLabel = "FRAMEWORK and CHARTERS";
    final String corporateIdentityGuidesAndBrandedTemplatesLabel = "CORPORATE IDENTITY - Guides and Branded Templates";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+  frameworkAndChartersLabel +"']")
    public WebElement frameworkAndCharters;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ corporateIdentityGuidesAndBrandedTemplatesLabel +"']")
    public WebElement corporateIdentityGuidesAndBrandedTemplates;

    public CreditRiskGovernance(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getFrameworkAndCharters() {
        businessBankingHelper.verifyAndClickElement( frameworkAndCharters, frameworkAndChartersLabel);
    }
    public void getCorporateIdentityGuidesAndBrandedTemplates() {
        businessBankingHelper.verifyAndClickElement(corporateIdentityGuidesAndBrandedTemplates, corporateIdentityGuidesAndBrandedTemplatesLabel);
    }

}
