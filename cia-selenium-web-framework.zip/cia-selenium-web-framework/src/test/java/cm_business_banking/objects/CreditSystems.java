package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class CreditSystems {


    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String autoReviewLabel = "Auto Review";
    final String excessAndArrearManagementLabel = "Excess and Arrear Management";
    final String eCASExpressLabel = "eCAS Express";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ autoReviewLabel +"']")
    public WebElement autoReview;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ excessAndArrearManagementLabel +"']")
    public WebElement excessAndArrearManagement;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ eCASExpressLabel +"']")
    public WebElement eCASExpress;

    public CreditSystems(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getAutoReview() {
        businessBankingHelper.verifyAndClickElement( autoReview, autoReviewLabel);
    }
    public void verifyAutoReview()  {
        businessBankingHelper.verifyPage(autoReviewLabel, autoReview);
        businessBankingHelper.takeSnapShot(autoReviewLabel+" Page");
    }
    public void getExcessAndArrearManagement() {
        businessBankingHelper.verifyAndClickElement( excessAndArrearManagement, excessAndArrearManagementLabel);
    }
    public void verifyExcessAndArrearManagement()  {
        businessBankingHelper.verifyPage(excessAndArrearManagementLabel, excessAndArrearManagement);
        businessBankingHelper.takeSnapShot(excessAndArrearManagementLabel+" Page");
    }
    public void getECASExpress() {
        businessBankingHelper.verifyAndClickElement( eCASExpress, eCASExpressLabel);
    }
    public void verifyECASExpress()  {
        businessBankingHelper.verifyPage(eCASExpressLabel, eCASExpress);
        businessBankingHelper.takeSnapShot(eCASExpressLabel+" Page");
    }
}
