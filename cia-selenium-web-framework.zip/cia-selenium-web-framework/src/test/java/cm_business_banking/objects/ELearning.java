package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class ELearning {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String eLearningLabel = "e-Learning";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ eLearningLabel +"']")
    public WebElement eLearning;

    public ELearning(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getELearning() {
        businessBankingHelper.verifyAndClickElement(eLearning, eLearningLabel);
    }
    public void verifyELearning()  {
        businessBankingHelper.verifyPage(eLearningLabel, eLearning);
        businessBankingHelper.takeSnapShot(eLearningLabel +" Page");
    }
}
