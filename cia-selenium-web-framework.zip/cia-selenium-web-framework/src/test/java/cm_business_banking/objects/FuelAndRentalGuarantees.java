package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class FuelAndRentalGuarantees {


    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String fuelRentalGuaranteesLabel = "Fuel and Rental Guarantees";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ fuelRentalGuaranteesLabel +"']")
    public WebElement fuelRentalGuarantees;

    public FuelAndRentalGuarantees(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getFuelRentalGuarantees() {
        businessBankingHelper.verifyAndClickElement( fuelRentalGuarantees, fuelRentalGuaranteesLabel);
    }
    public void verifyOperationalManagement()  {
        businessBankingHelper.verifyPage(fuelRentalGuaranteesLabel, fuelRentalGuarantees);
        businessBankingHelper.takeSnapShot(fuelRentalGuaranteesLabel +" Page");
    }
}
