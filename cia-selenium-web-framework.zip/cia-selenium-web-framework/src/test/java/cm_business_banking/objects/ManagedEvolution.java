package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class ManagedEvolution {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String integratedSolutionLabel = "An Integrated Solution";
    final String eclipseSuperUserTrainingLabel = "Eclipse Super User Training on Day 1";
    final String eclipseSuperUserTrainingLabel2 = "Eclipse Super User Training on Day 2";
    final String beneficialOwnershipLabel = "Beneficial Ownership";
    final String BOCreditSMEListingLabel = "BO Credit SME listing";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ integratedSolutionLabel +"']")
    public WebElement integratedSolution;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ eclipseSuperUserTrainingLabel +"']")
    public WebElement eclipseSuperUserTraining;
    @FindBy(how = How.XPATH, using = "//*[text() = '"+ eclipseSuperUserTrainingLabel2 +"']")
    public WebElement eclipseSuperUserTraining2;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ beneficialOwnershipLabel +"']")
    public WebElement beneficialOwnership;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BOCreditSMEListingLabel +"']")
    public WebElement BOCreditSMEListing;

    public ManagedEvolution(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getIntegratedSolution() {
        businessBankingHelper.verifyAndClickElement( integratedSolution, integratedSolutionLabel);
    }

    public void getEclipseSuperUserTraining2() {
        businessBankingHelper.verifyAndClickElement( eclipseSuperUserTraining2, eclipseSuperUserTrainingLabel2);
    }
    public void getEclipseSuperUserTraining() {
        businessBankingHelper.verifyAndClickElement( eclipseSuperUserTraining, eclipseSuperUserTrainingLabel);
    }
    public void getBeneficialOwnership() {
        businessBankingHelper.verifyAndClickElement( beneficialOwnership, beneficialOwnershipLabel);
    }
    public void getBOCreditSMEListing() {
        businessBankingHelper.verifyAndClickElement( BOCreditSMEListing, BOCreditSMEListingLabel);
    }
    public void verifyIntegratedSolution()  {
        businessBankingHelper.verifyPage(integratedSolutionLabel, integratedSolution);
        businessBankingHelper.takeSnapShot(integratedSolutionLabel +" Page");
    } public void verifyEclipseSuperUserTraining2()  {
        businessBankingHelper.verifyPage(eclipseSuperUserTrainingLabel2, eclipseSuperUserTraining2);
        businessBankingHelper.takeSnapShot(eclipseSuperUserTrainingLabel2 +" Page");
    } public void verifyEclipseSuperUserTraining()  {
        businessBankingHelper.verifyPage(eclipseSuperUserTrainingLabel, eclipseSuperUserTraining);
        businessBankingHelper.takeSnapShot(eclipseSuperUserTrainingLabel +" Page");
    } public void verifyBeneficialOwnership()  {
        businessBankingHelper.verifyPage(beneficialOwnershipLabel, beneficialOwnership);
        businessBankingHelper.takeSnapShot(beneficialOwnershipLabel +" Page");
    } public void verifyBOCreditSMEListingLabel()  {
        businessBankingHelper.verifyPage(BOCreditSMEListingLabel, BOCreditSMEListing);
        businessBankingHelper.takeSnapShot(BOCreditSMEListingLabel +" Page");
    }
}
