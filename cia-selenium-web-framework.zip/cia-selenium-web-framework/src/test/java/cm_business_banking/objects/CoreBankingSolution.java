package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class CoreBankingSolution {


    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String TransactionalCAAndEBLabel = "Transactional CA and EB";



    final String transactionalCashLabel = "Transactional - Cash";


    final String TransactionalCardLabel = "Transactional - Card";
    final String transactionalGlobalLabel = "Transactional - Global";
    final String InvestLabel = "Invest";
    final String BorrowLabel = "Borrow";
    final String CoreBankingToolsLabel = "Core Banking Tools";
    final String AssessmentsLabel = "BB PRODUCT COMMUNICATIONS";
    final String ProcessesLabel = "Processes";

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ TransactionalCAAndEBLabel +"']")
    public WebElement TransactionalCAAndEB;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ transactionalCashLabel +"']")
    public WebElement transactionalCash;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ TransactionalCardLabel +"']")
    public WebElement TransactionalCard;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ transactionalGlobalLabel +"']")
    public WebElement TransactionalGlobal;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ InvestLabel +"']")
    public WebElement Invest;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ BorrowLabel +"']")
    public WebElement Borrow;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ CoreBankingToolsLabel +"']")
    public WebElement CoreBankingTools;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ AssessmentsLabel +"']")
    public WebElement Assessments;

    @FindBy(how = How.XPATH, using = "//*[text() = '"+ ProcessesLabel +"']")
    public WebElement Processes;


    public CoreBankingSolution(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getTransactionalCAAndEB() {
        businessBankingHelper.verifyAndClickElement(TransactionalCAAndEB, TransactionalCAAndEBLabel);
    }

    public void getTransactionalCash() {
        businessBankingHelper.verifyAndClickElement( transactionalCash, transactionalCashLabel);
    }

    public void getTransactionalCard() {
        businessBankingHelper.verifyAndClickElement( TransactionalCard, TransactionalCardLabel);
    }

    public void getTransactionalGlobal() {
        businessBankingHelper.verifyAndClickElement(TransactionalGlobal, transactionalGlobalLabel);
    }

    public void getInvest() {
        businessBankingHelper.verifyAndClickElement( Invest, InvestLabel);
    }

    public void getBorrow() {
        businessBankingHelper.verifyAndClickElement( Borrow, BorrowLabel);
    }

    public void getCoreBankingTools() {
        businessBankingHelper.verifyAndClickElement( CoreBankingTools, CoreBankingToolsLabel);
    }

    public void getAssessments() {
        businessBankingHelper.verifyAndClickElement( Assessments, AssessmentsLabel);
    }
    public void getProcesses() {
        businessBankingHelper.verifyAndClickElement( Processes, ProcessesLabel);
    }
}
