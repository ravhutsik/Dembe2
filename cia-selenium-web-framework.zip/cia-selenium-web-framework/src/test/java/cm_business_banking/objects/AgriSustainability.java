package cm_business_banking.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class AgriSustainability {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String shadeNettingLabel = "Shade-netting";


    @FindBy(how = How.XPATH, using = "//*[text() = '"+ shadeNettingLabel +"']")
    public WebElement shadeNetting;

    public AgriSustainability(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void getShadeNetting() {
        businessBankingHelper.verifyAndClickElement( shadeNetting, shadeNettingLabel);
    }
    public void verifyShadeNetting()  {
        businessBankingHelper.verifyPage(shadeNettingLabel, shadeNetting);
        businessBankingHelper.takeSnapShot(shadeNettingLabel +" Page");
    }
}
