package cm_business_banking.tests;

import cm_business_banking.objects.BusinessLevel;
import cm_business_banking.objects.Innovation;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class InnovationTest {

    LaunchDriver loadBusinessBankingURL=new LaunchDriver("http://biscorpmempr/BB/Home/Navigation?CategoryId=1163");
    BusinessLevel aboutBusinessBanking = new BusinessLevel(loadBusinessBankingURL.getDriver());
    Innovation innovation = new Innovation(loadBusinessBankingURL.getDriver());


    @And("^I am able to select and verify Innovation Category on Take Business to Next Level Category$")
    public void iAmAbleToSelectAndVerifyInnovationCategoryOnTakeBusinessToNextLevelCategory() {
        aboutBusinessBanking.getInnovation();
    }

    @And("^I am able to verify and select Ideo Shoppping Cart Video Category on Innovation Category$")
    public void iAmAbleToVerifyAndSelectIdeoShopppingCartVideoCategoryOnInnovationCategory() {
        innovation.getVideoShopppingCartVideo();

    }

    @Then("^Verify all available operation on Ideo Shoppping Cart Video Article Page$")
    public void verifyAllAvailableOperationOnIdeoShopppingCartVideoArticlePage() {
        innovation.verifyVideoShopppingCartVideo();
    }

    @And("^I am able to verify and select Blue Ocean Strategies Category on Innovation Category$")
    public void iAmAbleToVerifyAndSelectBlueOceanStrategiesCategoryOnInnovationCategory() {
        innovation.getblueOceanStrategies();
    }

    @Then("^Verify all available operation on Blue Ocean Strategies Article Page$")
    public void verifyAllAvailableOperationOnBlueOceanStrategiesArticlePage() {
        innovation.verifyBlueOceanStrategies();
    }

    @And("^I am able to verify and select Innovation Approach at Nestle Category on Innovation Category$")
    public void iAmAbleToVerifyAndSelectInnovationApproachAtNestleCategoryOnInnovationCategory() {
        innovation.getInnovationApproachAtNestle();
    }

    @Then("^Verify all available operation on Innovation Approach at Nestle Article Page$")
    public void verifyAllAvailableOperationOnInnovationApproachAtNestleArticlePage() {
        innovation.verifyInnovationApproachAtNestle();
    }

    @And("^I am able to verify and select Innovations landed in (\\d+) Category on Innovation Category$")
    public void iAmAbleToVerifyAndSelectInnovationsLandedInCategoryOnInnovationCategory() {
        innovation.getInnovationsLandedIn2015();
    }

    @Then("^Verify all available operation on Innovations landed in (\\d+) Article Page$")
    public void verifyAllAvailableOperationOnInnovationsLandedInArticlePage() {
        innovation.verifyinnovationsLandedIn2015();
    }

    @And("^I am able to verify and select Market Edge video Category on Innovation Category$")
    public void iAmAbleToVerifyAndSelectMarketEdgeVideoCategoryOnInnovationCategory() {
        innovation.getMarketEdgeVideo();
    }

    @Then("^Verify all available operation on Market Edge video Article Page$")
    public void verifyAllAvailableOperationOnMarketEdgeVideoArticlePage() {
        innovation.verifyMarketEdgeVideo();
    }

    @And("^I am able to verify and select Gap Access Client video Category on Innovation Category$")
    public void iAmAbleToVerifyAndSelectGapAccessClientVideoCategoryOnInnovationCategory() {
        innovation.getGapAccessClientVideo();
    }

    @Then("^Verify all available operation on Gap Access Client Video  Article Page$")
    public void verifyAllAvailableOperationOnGapAccessClientVideoArticlePage() {
        innovation.verifyGapAccessClientVideo();
    }

    @And("^I am able to verify and select Online Business Registration Video Category on Innovation Category$")
    public void iAmAbleToVerifyAndSelectOnlineBusinessRegistrationVideoCategoryOnInnovationCategory() {
        innovation.getOnlineBusinessRegistrationVideo();
    }

    @Then("^Verify all available operation on Online Business Registration Video Article Page$")
    public void verifyAllAvailableOperationOnOnlineBusinessRegistrationVideoArticlePage() {
        innovation.verifyOnlineBusinessRegistrationVideo();
    }

    @And("^I am able to verify and select Nedbank Market Edge Delivers Category on Innovation Category$")
    public void iAmAbleToVerifyAndSelectNedbankMarketEdgeDeliversCategoryOnInnovationCategory() {
        innovation.getNedbankMarketEdgeDelivers();
    }

    @Then("^Verify all available operation on Nedbank Market Edge Delivers Article Page$")
    public void verifyAllAvailableOperationOnNedbankMarketEdgeDeliversArticlePage() {
        innovation.verifyNedbankMarketEdgeDelivers();
    }

    @And("^I am able to verify and select za website Category on Innovation Category$")
    public void iAmAbleToVerifyAndSelectZaWebsiteCategoryOnInnovationCategory() {
        innovation.getZAWebsite();
    }

    @Then("^Verify all available operation on za website Article Page$")
    public void verifyAllAvailableOperationOnZaWebsiteArticlePage() {
        innovation.verifyZAWebsiteLabel();
    }

    @And("^I am able to verify and select PocketPOS video Category on Innovation Category$")
    public void iAmAbleToVerifyAndSelectPocketPOSVideoCategoryOnInnovationCategory() {
        innovation.getPocketPOSVideo();
    }

    @Then("^Verify all available operation on PocketPOS video Article Page$")
    public void verifyAllAvailableOperationOnPocketPOSVideoArticlePage() {
        innovation.verifyPocketPOSVideo();
    }

    @And("^I am able to verify and select Plug and Transact Token - Getting Started guide Category on Innovation Category$")
    public void iAmAbleToVerifyAndSelectPlugAndTransactTokenGettingStartedGuideCategoryOnInnovationCategory() {
        innovation.getPlugAndTransactTokenGettingStartedGuide();
    }

    @Then("^Verify all available operation on Plug and Transact Token - Getting Started guide Article Page$")
    public void verifyAllAvailableOperationOnPlugAndTransactTokenGettingStartedGuideArticlePage() {
        innovation.verifyPlugAndTransactTokenGettingStartedGuide();
    }

    @And("^I am able to verify and select Global Video Banking video Category on Innovation Category$")
    public void iAmAbleToVerifyAndSelectGlobalVideoBankingVideoCategoryOnInnovationCategory() {
        innovation.getGlobalVideoBankingVideo();
    }

    @Then("^Verify all available operation on Global Video Banking video Article Page$")
    public void verifyAllAvailableOperationOnGlobalVideoBankingVideoArticlePage() {
        innovation.verifyGlobalVideoBankingVideo();
    }

    @And("^I am able to verify and select Notifications Launch Category on Innovation Category$")
    public void iAmAbleToVerifyAndSelectNotificationsLaunchCategoryOnInnovationCategory() {
        innovation.getNotificationsLaunch();
    }

    @Then("^Verify all available operation on Notifications Launch Article Page$")
    public void verifyAllAvailableOperationOnNotificationsLaunchArticlePage() {
        innovation.verifyNotificationsLaunch();
    }

    @And("^I am able to verify and select BST Workflow Demo Category on Innovation Category$")
    public void iAmAbleToVerifyAndSelectBSTWorkflowDemoCategoryOnInnovationCategory() {
        innovation.getBSTWorkflowDemo();
    }

    @Then("^Verify all available operation on BST Workflow Demo Article Page$")
    public void verifyAllAvailableOperationOnBSTWorkflowDemoArticlePage() {
        innovation.verifyBSTWorkflowDemo();
    }

    @And("^I am able to verify and select Design Thinking Our Innovation Approach Category on Innovation Category$")
    public void iAmAbleToVerifyAndSelectDesignThinkingOurInnovationApproachCategoryOnInnovationCategory() {
        innovation.getBSTWorkflowDemDesignThinkingOurInnovationApproach();
    }

    @Then("^Verify all available operation on Design Thinking Our Innovation Approach Article Page$")
    public void verifyAllAvailableOperationOnDesignThinkingOurInnovationApproachArticlePage() {
        innovation.verifyBSTWorkflowDemDesignThinkingOurInnovationApproach();
    }

    @And("^I am able to verify and select Market Edge Brochure Category on Innovation Category$")
    public void iAmAbleToVerifyAndSelectMarketEdgeBrochureCategoryOnInnovationCategory() {
        innovation.getMarketEdgeBrochure();
    }
}
