package cm_business_banking.tests;

import cm_business_banking.objects.*;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class AboutBusinessBankingTest {

    LaunchDriver loadBusinessBankingURL=new LaunchDriver("http://biscorpmempr/BB/Home/Navigation?CategoryId=1881");
    MoreCategories moreCategories = new MoreCategories(loadBusinessBankingURL.getDriver());
    BusinessLevel businessLevel = new BusinessLevel(loadBusinessBankingURL.getDriver());
    AboutBusinessBanking aboutBusinessBanking = new AboutBusinessBanking(loadBusinessBankingURL.getDriver());


    @And("^I am able to select and verify Take Business to Next Level Category on More Categories Category$")
    public void iAmAbleToSelectAndVerifyTakeBusinessToNextLevelCategoryOnMoreCategoriesCategory() {
        moreCategories.getTakingBusinessNextLevel();
    }

    @And("^I am able to select and verify About Business Banking Category on Take Business to Next Level Category$")
    public void iAmAbleToSelectAndVerifyAboutBusinessBankingCategoryOnTakeBusinessToNextLevelCategory() {
        businessLevel.getAboutBusinessBanking();
    }

    @And("^I am able to verify and select Whole-view Business Banking Banker guide Category on About Business Banking Category$")
    public void iAmAbleToVerifyAndSelectWholeViewBusinessBankingBankerGuideCategoryOnAboutBusinessBankingCategory() {
        aboutBusinessBanking.getWholeviewBusinessBankingBankerGuide();
    }

    @Then("^Verify all available operation on Whole-view Business Banking Banker guide Article Page$")
    public void verifyAllAvailableOperationOnWholeViewBusinessBankingBankerGuideArticlePage() {
        aboutBusinessBanking.verifyWholeviewBusinessBankingBankerGuide();
    }

    @And("^I am able to verify and select BB Background and History Category on About Business Banking Category$")
    public void iAmAbleToVerifyAndSelectBBBackgroundAndHistoryCategoryOnAboutBusinessBankingCategory() {
        aboutBusinessBanking.getBBBackgroundAndHistory();
    }

    @Then("^Verify all available operation on BB Background and History Article Page$")
    public void verifyAllAvailableOperationOnBBBackgroundAndHistoryArticlePage() {
        aboutBusinessBanking.verifyBBBackgroundAndHistory();
    }

    @And("^I am able to verify and select BB Purpose and Client Experience Category on About Business Banking Category$")
    public void iAmAbleToVerifyAndSelectBBPurposeAndClientExperienceCategoryOnAboutBusinessBankingCategory() {
        aboutBusinessBanking.getBBPurposeAndClientExperience();
    }

    @Then("^Verify all available operation on BB Purpose and Client Experience Article Page$")
    public void verifyAllAvailableOperationOnBBPurposeAndClientExperienceArticlePage() {
        aboutBusinessBanking.verifyBBPurposeAndClientExperience();
    }

    @And("^I am able to verify and select BB Structure Category on About Business Banking Category$")
    public void iAmAbleToVerifyAndSelectBBStructureCategoryOnAboutBusinessBankingCategory() {
        aboutBusinessBanking.getBBStructure();
    }

    @Then("^Verify all available operation on BB Structure Article Page$")
    public void verifyAllAvailableOperationOnBBStructureArticlePage() {
        aboutBusinessBanking.verifyBBStructure();
    }

    @And("^I am able to verify and select BB Value Proposition Category on About Business Banking Category$")
    public void iAmAbleToVerifyAndSelectBBValuePropositionCategoryOnAboutBusinessBankingCategory() {
        aboutBusinessBanking.getBBValueProposition();
    }

    @Then("^Verify all available operation on BB Value Proposition Article Page$")
    public void verifyAllAvailableOperationOnBBValuePropositionArticlePage() {
        aboutBusinessBanking.verifyBBValueProposition();
    }

    @And("^I am able to verify and select BB Structure Area Offices Category on About Business Banking Category$")
    public void iAmAbleToVerifyAndSelectBBStructureAreaOfficesCategoryOnAboutBusinessBankingCategory() {
        aboutBusinessBanking.getBBStructureAreaOffices();
    }

    @Then("^Verify all available operation on BB Structure Area Offices Article Page$")
    public void verifyAllAvailableOperationOnBBStructureAreaOfficesArticlePage() {
        aboutBusinessBanking.verifyBBStructureAreaOffices();
    }

    @And("^I am able to verify and select About our CST's Category on About Business Banking Category$")
    public void iAmAbleToVerifyAndSelectAboutOurCSTSCategoryOnAboutBusinessBankingCategory() {
        aboutBusinessBanking.getAboutOurCST();
    }

    @Then("^Verify all available operation on About our CST's Article Page$")
    public void verifyAllAvailableOperationOnAboutOurCSTSArticlePage() {
        aboutBusinessBanking.verifyAboutOurCST();
    }

    @And("^I am able to verify and select Strategic Objective Category on About Business Banking Category$")
    public void iAmAbleToVerifyAndSelectStrategicObjectiveCategoryOnAboutBusinessBankingCategory() {
        aboutBusinessBanking.getStrategicObjective();
    }

    @Then("^Verify all available operation on Strategic Objective Article Page$")
    public void verifyAllAvailableOperationOnStrategicObjectiveArticlePage() {
        aboutBusinessBanking.verifyStrategicObjective();
    }

    @And("^I am able to verify and select BB Past Successes Category on About Business Banking Category$")
    public void iAmAbleToVerifyAndSelectBBPastSuccessesCategoryOnAboutBusinessBankingCategory() {
        aboutBusinessBanking.getBBPastSuccesses();
    }

    @Then("^Verify all available operation on BB Past Successes Article Page$")
    public void verifyAllAvailableOperationOnBBPastSuccessesArticlePage() {
        aboutBusinessBanking.verifyBBPastSuccessesLabel();
    }
}
