package cm_business_banking.tests;

import cm_business_banking.objects.BusinessBankingNews;
import cm_business_banking.objects.BusinessLevel;
import cm_business_banking.objects.StaffEngagement;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class BusinessBankingNewsTest {
    LaunchDriver loadBusinessBankingURL=new LaunchDriver("http://biscorpmempr/BB/Home/Navigation?CategoryId=1163");
    BusinessLevel aboutBusinessBanking = new BusinessLevel(loadBusinessBankingURL.getDriver());
    BusinessBankingNews businessBankingNews = new BusinessBankingNews(loadBusinessBankingURL.getDriver());

    @And("^I am able to select and verify Business Banking News Category on Take Business to Next Level Category$")
    public void iAmAbleToSelectAndVerifyBusinessBankingNewsCategoryOnTakeBusinessToNextLevelCategory() {
        aboutBusinessBanking.getBusinessBankingNews();
    }

    @And("^I am able to verify and select BB News oneFour March Category on Business Banking News Category$")
    public void iAmAbleToVerifyAndSelectBBNewsOneFourMarchCategoryOnBusinessBankingNewsCategory() {
        businessBankingNews.getBBNews14March();
    }

    @Then("^Verify all available operation on BB News oneFour March Article Page$")
    public void verifyAllAvailableOperationOnBBNewsOneFourMarchArticlePage() {
        businessBankingNews.verifyBBNews14March();
    }

    @And("^I am able to verify and select BB News Nine March Category on Business Banking News Category$")
    public void iAmAbleToVerifyAndSelectBBNewsNineMarchCategoryOnBusinessBankingNewsCategory() {
        businessBankingNews.getBBNews09March();
    }

    @Then("^Verify all available operation on BB News Nine March September Article Page$")
    public void verifyAllAvailableOperationOnBBNewsNineMarchSeptemberArticlePage() {
        businessBankingNews.verifyBBNews09March();
    }

    @And("^I am able to verify and select Nedbank Accounting and other Third party vendors Category on Business Banking News Category$")
    public void iAmAbleToVerifyAndSelectNedbankAccountingAndOtherThirdPartyVendorsCategoryOnBusinessBankingNewsCategory() {
        businessBankingNews.getNedbankAccountingThirdPartyVendors();
    }

    @Then("^Verify all available operation on Nedbank Accounting and other Third party vendors Article Page$")
    public void verifyAllAvailableOperationOnNedbankAccountingAndOtherThirdPartyVendorsArticlePage() {
        businessBankingNews.verifyNedbankAccountingThirdPartyVendors();
    }

    @And("^I am able to verify and select NetBank Business notifications and alerts Category on Business Banking News Category$")
    public void iAmAbleToVerifyAndSelectNetBankBusinessNotificationsAndAlertsCategoryOnBusinessBankingNewsCategory() {
        businessBankingNews.getNetBankBusinessNotificationsAlerts();
    }

    @Then("^Verify all available operation on NetBank Business notifications and alerts Article Page$")
    public void verifyAllAvailableOperationOnNetBankBusinessNotificationsAndAlertsArticlePage() {
        businessBankingNews.verifyNetBankBusinessNotificationsAlerts();
    }

    @And("^I am able to verify and select NetBank Business enhancements Category on Business Banking News Category$")
    public void iAmAbleToVerifyAndSelectNetBankBusinessEnhancementsCategoryOnBusinessBankingNewsCategory() {
        businessBankingNews.getNetBankBusinessEnhancements();
    }

    @Then("^Verify all available operation on NetBank Business enhancements Article Page$")
    public void verifyAllAvailableOperationOnNetBankBusinessEnhancementsArticlePage() {
        businessBankingNews.verifyNetBankBusinessEnhancements();
    }

    @And("^I am able to verify and select BB News TwoNine June Category on Business Banking News Category$")
    public void iAmAbleToVerifyAndSelectBBNewsTwoNineJuneCategoryOnBusinessBankingNewsCategory() {
        businessBankingNews.getBBNews29June();
    }

    @Then("^Verify all available operation on BB News TwoNine June Article Page$")
    public void verifyAllAvailableOperationOnBBNewsTwoNineJuneArticlePage() {
        businessBankingNews.verifyBBNews29June();
    }

    @And("^I am able to verify and selectBusiness Banking News One July Category on Business Banking News Category$")
    public void iAmAbleToVerifyAndSelectBusinessBankingNewsOneJulyCategoryOnBusinessBankingNewsCategory() {
        businessBankingNews.getBBNews1July3();
    }

    @Then("^Verify all available operation on Business Banking News One July Article Page$")
    public void verifyAllAvailableOperationOnBusinessBankingNewsOneJulyArticlePage() {
        businessBankingNews.verifyBBNews1July3();
    }

    @And("^I am able to verify and select Business Banking News Four July (\\d+)er Category on Business Banking News Category$")
    public void iAmAbleToVerifyAndSelectBusinessBankingNewsFourJulyErCategoryOnBusinessBankingNewsCategory(int arg0) {
        businessBankingNews.getBusinessBankingNews4July2016();
    }

    @Then("^Verify all available operation on Business Banking News Four July (\\d+)er Article Page$")
    public void verifyAllAvailableOperationOnBusinessBankingNewsFourJulyErArticlePage() {
        businessBankingNews.verifyBusinessBankingNews4July2016();
    }

    @And("^I am able to verify and select BB News OneFive July (\\d+)er Category on Business Banking News Category$")
    public void iAmAbleToVerifyAndSelectBBNewsOneFiveJulyErCategoryOnBusinessBankingNewsCategory(int arg0) {
        businessBankingNews.getBBNews15July2016();
    }

    @Then("^Verify all available operation on BB News oneFive July (\\d+)er Article Page$")
    public void verifyAllAvailableOperationOnBBNewsOneFiveJulyErArticlePage(int arg0) {
        businessBankingNews.verifyBBNews15July2016();
    }

    @And("^I am able to verify and select BB News OneThree July Category on Business Banking News Category$")
    public void iAmAbleToVerifyAndSelectBBNewsOneThreeJulyCategoryOnBusinessBankingNewsCategory() {
        businessBankingNews.getBBNews13July();
    }

    @Then("^Verify all available operation on BB News OneThree July sessions Article Page$")
    public void verifyAllAvailableOperationOnBBNewsOneThreeJulySessionsArticlePage() {
        businessBankingNews.verifyBBNews13July();
    }

    @And("^I am able to verify and select BB News Eight July (\\d+)er Category on Business Banking News Category$")
    public void iAmAbleToVerifyAndSelectBBNewsEightJulyErCategoryOnBusinessBankingNewsCategory(int arg0) {
        businessBankingNews.getBBNews08July2016();
    }

    @Then("^Verify all available operation on BB News Eight July (\\d+)er Article Page$")
    public void verifyAllAvailableOperationOnBBNewsEightJulyErArticlePage(int arg0) {
        businessBankingNews.verifyBBNews08July2016();
    }

    @And("^I am able to verify and select SBV cash centre in Selby relocation Category on Business Banking News Category$")
    public void iAmAbleToVerifyAndSelectSBVCashCentreInSelbyRelocationCategoryOnBusinessBankingNewsCategory() {
        businessBankingNews.getSBVCashCentreInSelbyRelocation();
    }

    @Then("^Verify all available operation on SBV cash centre in Selby relocation Article Page$")
    public void verifyAllAvailableOperationOnSBVCashCentreInSelbyRelocationArticlePage() {
        businessBankingNews.verifySBVCashCentreInSelbyRelocation();
    }
}
