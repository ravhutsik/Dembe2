package cm_business_banking.tests;

import cm_business_banking.objects.HomeCategory;
import cm_business_banking.objects.PrincipleClientPortfolio;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PrincipleClientPortfolioTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmemqa/BB/Home");
    HomeCategory homeCategory = new HomeCategory(launchDriver.getDriver());
    PrincipleClientPortfolio principleClientPortfolio = new PrincipleClientPortfolio(launchDriver.getDriver());


    @When("^I am able to verify and select Principle Client Portfolio Category$")
    public void iAmAbleToVerifyAndSelectPrincipleClientPortfolioCategory() {
        homeCategory.getPrincipleClientPortfolio();
    }

    @And("^I am able to verify and select An PCP Service Pledge Category on Principle Client Portfolio Category$")
    public void iAmAbleToVerifyAndSelectAnPCPServicePledgeCategoryOnPrincipleClientPortfolioCategory() {
        principleClientPortfolio.getPCPServicePledge();
    }

    @Then("^Verify all available operation on An PCP Service Pledge Article Page$")
    public void verifyAllAvailableOperationOnAnPCPServicePledgeArticlePage() {
        principleClientPortfolio.verifyPCPServicePledge();
    }

    @And("^I am able to verify and select PCP - Script for client moving to PCP Category on Principle Client Portfolio Category$")
    public void iAmAbleToVerifyAndSelectPCPScriptForClientMovingToPCPCategoryOnPrincipleClientPortfolioCategory() {
        principleClientPortfolio.getPCPScriptForClientMovingToPCP();
    }

    @Then("^Verify all available operation on PCP - Script for client moving to PCP Article Page$")
    public void verifyAllAvailableOperationOnPCPScriptForClientMovingToPCPArticlePage() {
        principleClientPortfolio.verifyPCPScriptForClientMovingToPCP();
    }

    @And("^I am able to verify and select PCP - Script for relationship changes Category on Principle Client Portfolio Category$")
    public void iAmAbleToVerifyAndSelectPCPScriptForRelationshipChangesCategoryOnPrincipleClientPortfolioCategory() {
        principleClientPortfolio.getPCPScriptForRelationshipChanges();
    }

    @Then("^Verify all available operation on PCP - Script for relationship changes Article Page$")
    public void verifyAllAvailableOperationOnPCPScriptForRelationshipChangesArticlePage() {
        principleClientPortfolio.verifyPCPScriptForRelationshipChanges();
    }

    @And("^I am able to verify and select PCP Service Pledge presentations Category on Principle Client Portfolio Category$")
    public void iAmAbleToVerifyAndSelectPCPServicePledgePresentationsCategoryOnPrincipleClientPortfolioCategory() {
        principleClientPortfolio.getPCPServicePledgePresentations();
    }

    @Then("^Verify all available operation on PCP Service Pledge presentations Article Page$")
    public void verifyAllAvailableOperationOnPCPServicePledgePresentationsArticlePage() {
        principleClientPortfolio.verifyPCPServicePledgePresentationsLabel();
    }
    @And("^I am able to verify and select PCP Client Handover Document Category on Principle Client Portfolio Category$")
    public void iAmAbleToVerifyAndSelectPCPClientHandoverDocumentCategoryOnPrincipleClientPortfolioCategory() {
        principleClientPortfolio.getPCPClientHandoverDocument();
    }

    @Then("^Verify all available operation on PCP Client Handover Document Article Page$")
    public void verifyAllAvailableOperationOnPCPClientHandoverDocumentArticlePage() {
        principleClientPortfolio.verifyPCPClientHandoverDocument();
    }
}
