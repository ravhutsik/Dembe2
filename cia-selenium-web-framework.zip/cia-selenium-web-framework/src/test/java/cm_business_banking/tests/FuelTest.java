package cm_business_banking.tests;

import cm_business_banking.objects.ClientValuePropositions;
import cm_business_banking.objects.Fuel;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class FuelTest {
    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmempr/BB/Home/Navigation?CategoryId=1337");
    ClientValuePropositions clientValuePropositions = new ClientValuePropositions(launchDriver.getDriver());

    Fuel fuel = new Fuel(launchDriver.getDriver());

    @And("^I am able to verify and select Fuel Category from Client Value Propositions Category$")
    public void iAmAbleToVerifyAndSelectFuelCategoryFromClientValuePropositionsCategory() {
        clientValuePropositions.getFuel();
    }

    @And("^I am able to verify and select An BP Category on Fuel Category$")
    public void iAmAbleToVerifyAndSelectAnBPCategoryOnFuelCategory() {
        fuel.getBP();
    }

    @Then("^Verify all available operation on An BP Article Page$")
    public void verifyAllAvailableOperationOnAnBPArticlePage() {
        fuel.verifyBP();
    }

    @And("^I am able to verify and select Texan Petroleum Category on Fuel Category$")
    public void iAmAbleToVerifyAndSelectTexanPetroleumCategoryOnFuelCategory() {
        fuel.getTexanPetroleum();
    }

    @Then("^Verify all available operation on Texan Petroleum Article Page$")
    public void verifyAllAvailableOperationOnTexanPetroleumArticlePage() {
        fuel.verifyTexanPetroleum();
    }

    @And("^I am able to verify and select Green Petroleum Category on Fuel Category$")
    public void iAmAbleToVerifyAndSelectGreenPetroleumCategoryOnFuelCategory() {
        fuel.getGreenPetroleum();
    }

    @Then("^Verify all available operation on Green Petroleum Article Page$")
    public void verifyAllAvailableOperationOnGreenPetroleumArticlePage() {
        fuel.verifyGreenPetroleum();
    }

    @And("^I am able to verify and select Elegant Fuel Category on Fuel Category$")
    public void iAmAbleToVerifyAndSelectElegantFuelCategoryOnFuelCategory() {
        fuel.getElegantFuel();
    }

    @Then("^Verify all available operation on Elegant Fuel Article Page$")
    public void verifyAllAvailableOperationOnElegantFuelArticlePage() {
        fuel.verifyElegantFuel();
    }

    @And("^I am able to verify and select VIVA OIL Category on Fuel Category$")
    public void iAmAbleToVerifyAndSelectVIVAOILCategoryOnFuelCategory() {
        fuel.getVivaOil();
    }

    @Then("^Verify all available operation on VIVA OIL Article Page$")
    public void verifyAllAvailableOperationOnVIVAOILArticlePage() {
        fuel.verifyVivaOil();
    }

    @And("^I am able to verify and select An Puma Category on Fuel Category$")
    public void iAmAbleToVerifyAndSelectAnPumaCategoryOnFuelCategory() {
        fuel.getPuma();
    }

    @Then("^Verify all available operation on Puma Article Page$")
    public void verifyAllAvailableOperationOnPumaArticlePage() {
        fuel.verifyPuma();
    }

    @And("^I am able to verify and select quest petroleum Category on Fuel Category$")
    public void iAmAbleToVerifyAndSelectQuestPetroleumCategoryOnFuelCategory() {
        fuel.getQuestPetroleum();
    }

    @Then("^Verify all available operation on quest petroleum Article Page$")
    public void verifyAllAvailableOperationOnQuestPetroleumArticlePage() {
        fuel.verifyQuestPetroleum();
    }

    @And("^I am able to verify and select Engen Category on Fuel Category$")
    public void iAmAbleToVerifyAndSelectEngenCategoryOnFuelCategory() {
        fuel.getEngen();
    }

    @Then("^Verify all available operation on Engen Article Page$")
    public void verifyAllAvailableOperationOnEngenArticlePage() {
        fuel.verifyEngen();
    }

    @And("^I am able to verify and select Sasol Category on Fuel Category$")
    public void iAmAbleToVerifyAndSelectSasolCategoryOnFuelCategory() {
        fuel.getSasol();
    }

    @Then("^Verify all available operation on Sasol Article Page$")
    public void verifyAllAvailableOperationOnSasolArticlePage() {
        fuel.verifySasol();
    }

    @And("^I am able to verify and select Shell Category on Fuel Category$")
    public void iAmAbleToVerifyAndSelectShellCategoryOnFuelCategory() {
        fuel.getShell();
    }

    @Then("^Verify all available operation on Shell Article Page$")
    public void verifyAllAvailableOperationOnShellArticlePage() {
        fuel.verifyShell();
    }

    @And("^I am able to verify and select Total Category on Fuel Category$")
    public void iAmAbleToVerifyAndSelectTotalCategoryOnFuelCategory() {
        fuel.getTotal();
    }

    @Then("^Verify all available operation on Total Article Page$")
    public void verifyAllAvailableOperationOnTotalArticlePage() {
        fuel.verifyTotal();
    }

    @And("^I am able to verify and select MBT Petroleum Category on Fuel Category$")
    public void iAmAbleToVerifyAndSelectMBTPetroleumCategoryOnFuelCategory() {
        fuel.getMPTPetroleum();
    }

    @Then("^Verify all available operation on MBT Petroleum Article Page$")
    public void verifyAllAvailableOperationOnMBTPetroleumArticlePage() {
        fuel.verifyMPTPetroleum();
    }

    @And("^I am able to verify and select Global Oil Category on Fuel Category$")
    public void iAmAbleToVerifyAndSelectGlobalOilCategoryOnFuelCategory() {
        fuel.getGlobalOil();
    }

    @Then("^Verify all available operation on Global Oil Article Page$")
    public void verifyAllAvailableOperationOnGlobalOilArticlePage() {
        fuel.verifyGlobalOil();
    }

    @And("^I am able to verify and select Caltex Category on Fuel Category$")
    public void iAmAbleToVerifyAndSelectCaltexCategoryOnFuelCategory() {
        fuel.getCaltex();
    }

    @Then("^Verify all available operation on Caltex Article Page$")
    public void verifyAllAvailableOperationOnCaltexArticlePage() {
        fuel.verifyCaltex();
    }

    @And("^I am able to verify and select xfuels Category on Fuel Category$")
    public void iAmAbleToVerifyAndSelectXfuelsCategoryOnFuelCategory() {
        fuel.getXfuels();
    }

    @Then("^Verify all available operation on xfuels Article Page$")
    public void verifyAllAvailableOperationOnXfuelsArticlePage() {
        fuel.verifyXfuels();
    }

    @And("^I am able to verify and select Micaren excel Category on Fuel Category$")
    public void iAmAbleToVerifyAndSelectMicarenExcelCategoryOnFuelCategory() {
        fuel.getMicarenExcel();
    }

    @Then("^Verify all available operation on Micaren excel Article Page$")
    public void verifyAllAvailableOperationOnMicarenExcelArticlePage() {
        fuel.verifyMicarenExcel();
    }
}
