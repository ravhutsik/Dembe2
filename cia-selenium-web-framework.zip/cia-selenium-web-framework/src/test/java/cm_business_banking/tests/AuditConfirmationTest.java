package cm_business_banking.tests;

import cm_business_banking.objects.AuditConfirmation;
import cm_business_banking.objects.Communication;
import cm_business_banking.objects.Credit;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class AuditConfirmationTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmemqa/BB/Home/Navigation?CategoryId=1153");

    Credit credit = new Credit(launchDriver.getDriver());
    Communication communication = new Communication(launchDriver.getDriver());
    AuditConfirmation auditConfirmation = new AuditConfirmation(launchDriver.getDriver());


    @And("^I am able to select and verify Communication Category on Credit Category$")
    public void iAmAbleToSelectAndVerifyCommunicationCategoryOnCreditCategory() {
        credit.getCommunications();
    }

    @And("^I am able to select and verify Audit Confirmation Category on Credit Category$")
    public void iAmAbleToSelectAndVerifyAuditConfirmationCategoryOnCreditCategory() {
        communication.getAuditConfirmation();
    }

    @And("^I am able to verify and select Audit Confirmation Communications Category on Audit Confirmation Category$")
    public void iAmAbleToVerifyAndSelectAuditConfirmationCommunicationsCategoryOnAuditConfirmationCategory() {
        auditConfirmation.getAuditConfirmationCommunications();
    }

    @Then("^Verify all available operation on Audit Confirmation Communications Article Page$")
    public void verifyAllAvailableOperationOnAuditConfirmationCommunicationsArticlePage() {
        auditConfirmation.verifyAuditConfirmationCommunications();
    }
}
