package cm_business_banking.tests;

import cm_business_banking.objects.DebtorManagementTemplates;
import cm_business_banking.objects.DocumentLibrary;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class DebtorManagementTemplateTest {


    LaunchDriver launchDriver = new LaunchDriver("http://biscorpmemqa/BB/Home/Navigation?CategoryId=1167");

    DocumentLibrary documentLibrary = new DocumentLibrary(launchDriver.getDriver());
    DebtorManagementTemplates debtorManagementTemplate = new DebtorManagementTemplates(launchDriver.getDriver());



    @And("^I am able to select and verify Debtor Management \\(NDM\\) Templates Category on Document Library$")
    public void iAmAbleToSelectAndVerifyDebtorManagementNDMTemplatesCategoryOnDocumentLibrary() {
        documentLibrary.getDebtorManagementTemplates();
    }

    @And("^I am able to verify and select Whole-view Business Banking Afrikaans editorial Category on Debtor Management \\(NDM\\) Templates Category$")
    public void iAmAbleToVerifyAndSelectWholeViewBusinessBankingAfrikaansEditorialCategoryOnDebtorManagementNDMTemplatesCategory() {
        debtorManagementTemplate.getWholeViewBBEditorial();
    }

    @Then("^Verify all available operation on Whole-view Business Banking Afrikaans editorial Article Page$")
    public void verifyAllAvailableOperationOnWholeViewBusinessBankingAfrikaansEditorialArticlePage(){
        debtorManagementTemplate.verifyWholeViewBBEditorial();
    }

    @And("^I am able to verify and select NDM Template Category on Debtor Management \\(NDM\\) Templates Category$")
    public void iAmAbleToVerifyAndSelectNDMTemplateCategoryOnDebtorManagementNDMTemplatesCategory() {
        debtorManagementTemplate.getNDMTemplate();
    }

    @Then("^Verify all available operation on NDM Template Article Page$")
    public void verifyAllAvailableOperationOnNDMTemplateArticlePage() {
        debtorManagementTemplate.verifyNDMTemplate();
    }
}
