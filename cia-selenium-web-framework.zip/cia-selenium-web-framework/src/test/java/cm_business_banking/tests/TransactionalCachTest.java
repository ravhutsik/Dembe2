package cm_business_banking.tests;

import cm_business_banking.objects.CoreBankingSolution;
import cm_business_banking.objects.HomeCategory;
import cm_business_banking.objects.TransactionalCAAndEB;
import cm_business_banking.objects.TransactionalCash;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class TransactionalCachTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmempr/BB/Home/Navigation?CategoryId=1160");
    CoreBankingSolution coreBankingSolution = new CoreBankingSolution(launchDriver.getDriver());
    TransactionalCash transactionalCash = new TransactionalCash(launchDriver.getDriver());

    @And("^I am able to verify and select Transactional Cash Category on Core Banking Solutions Category$")
    public void iAmAbleToVerifyAndSelectTransactionalCashCategoryOnCoreBankingSolutionsCategory() {
        coreBankingSolution.getTransactionalCash();
    }

    @Then("^I am able to verify and View Cash Online Category on Transactional Cash Category$")
    public void iAmAbleToVerifyAndViewCashOnlineCategoryOnTransactionalCashCategory() {
        transactionalCash.getCashOnline();
    }

    @Then("^I am able to verify and View Cash Vault Category on Transactional Cash Category$")
    public void iAmAbleToVerifyAndViewCashVaultCategoryOnTransactionalCashCategory() {
        transactionalCash.getCashVault();
    }

    @Then("^I am able to verify and View Manual Cash Banking Category on Transactional Cash Category$")
    public void iAmAbleToVerifyAndViewManualCashBankingCategoryOnTransactionalCashCategory() {
        transactionalCash.getManualCashBanking();
    }
}
