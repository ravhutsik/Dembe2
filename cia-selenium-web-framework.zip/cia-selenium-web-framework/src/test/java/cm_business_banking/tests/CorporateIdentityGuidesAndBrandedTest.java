package cm_business_banking.tests;

import cm_business_banking.objects.*;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class CorporateIdentityGuidesAndBrandedTest {
    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmemqa/BB/Home/Navigation?CategoryId=1153");
    Credit credit = new Credit(launchDriver.getDriver());
    CreditRiskGovernance creditRiskGovernance = new CreditRiskGovernance(launchDriver.getDriver());
    CorporateIdentityGuidesAndBranded corporateIdentityGuidesAndBranded = new CorporateIdentityGuidesAndBranded(launchDriver.getDriver());


    @And("^I am able to select and verify Credit and Risk Governance Category on Credit Category$")
    public void iAmAbleToSelectAndVerifyCreditAndRiskGovernanceCategoryOnCreditCategory() {
        credit.getCreditRiskGovernance();

    }

    @And("^I am able to select and verify Corporate Identity Guides And Branded Category on Communication Category$")
    public void iAmAbleToSelectAndVerifyCorporateIdentityGuidesAndBrandedCategoryOnCommunicationCategory() {
        creditRiskGovernance.getCorporateIdentityGuidesAndBrandedTemplates();
    }

    @And("^I am able to verify and select Guides And Cheat Sheets Category on Corporate Identity Guides And Branded Category$")
    public void iAmAbleToVerifyAndSelectGuidesAndCheatSheetsCategoryOnCorporateIdentityGuidesAndBrandedCategory() {
        corporateIdentityGuidesAndBranded.getGuidesAndCheatSheets();
    }

    @Then("^Verify all available operation on Guides And Cheat Sheets Article Page$")
    public void verifyAllAvailableOperationOnGuidesAndCheatSheetsArticlePage() {
        corporateIdentityGuidesAndBranded.verifyGuidesAndCheatSheets();
    }

    @And("^I am able to verify and select Branded Templates Category on Corporate Identity Guides And Branded Category$")
    public void iAmAbleToVerifyAndSelectBrandedTemplatesCategoryOnCorporateIdentityGuidesAndBrandedCategory() {
        corporateIdentityGuidesAndBranded.getBrandedTemplates();
    }

    @Then("^Verify all available operation on Branded Templates Article Page$")
    public void verifyAllAvailableOperationOnBrandedTemplatesArticlePage() {
        corporateIdentityGuidesAndBranded.verifyBrandedTemplates();
    }


}
