package cm_business_banking.tests;

import cm_business_banking.objects.Assessments;
import cm_business_banking.objects.CoreBankingSolution;
import cm_business_banking.objects.TransactionalCard;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class AssessmentTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmempr/BB/Home/Navigation?CategoryId=1160");
    CoreBankingSolution coreBankingSolution = new CoreBankingSolution(launchDriver.getDriver());
    Assessments assessments = new Assessments(launchDriver.getDriver());


    @And("^I am able to verify and select Assessments Category on Core Banking Solutions Category$")
    public void iAmAbleToVerifyAndSelectAssessmentsCategoryOnCoreBankingSolutionsCategory() {
        coreBankingSolution.getAssessments();
    }

    @Then("^I am able to verify and View Training Category on Assessments Category$")
    public void iAmAbleToVerifyAndViewTrainingCategoryOnAssessmentsCategory() {
        assessments.getTraining();
    }

    @Then("^I am able to verify and View Core Banking Action Learning Category on Assessments Category$")
    public void iAmAbleToVerifyAndViewCoreBankingActionLearningCategoryOnAssessmentsCategory() {
        assessments.getCoreBankingActionLearning();
    }
}
