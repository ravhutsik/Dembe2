package cm_business_banking.tests;

import cm_business_banking.objects.AgriMarketingMaterialAndSalesSupport;
import cm_business_banking.objects.Agriculture;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class AgriMarketingMaterialAndSalesSupportTest {
    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmempr/BB/Home/Navigation?CategoryId=1346");
    Agriculture agriculture = new Agriculture(launchDriver.getDriver());
    AgriMarketingMaterialAndSalesSupport agriMarketingMaterialAndSalesSupport = new AgriMarketingMaterialAndSalesSupport(launchDriver.getDriver());

    @And("^I am able to select and verify Marketing Material and Sales Support Category on Agriculture Category$")
    public void iAmAbleToSelectAndVerifyMarketingMaterialAndSalesSupportCategoryOnAgricultureCategory() {
        agriculture.getMarketingMaterialAndSalesSupport();
    }

    @And("^I am able to verify and select Agriculture Marketing Material & Sales Support Category on Marketing Material and Sales Support Category$")
    public void iAmAbleToVerifyAndSelectAgricultureMarketingMaterialSalesSupportCategoryOnMarketingMaterialAndSalesSupportCategory() {
        agriMarketingMaterialAndSalesSupport.getAgricultureMarketingMaterialSalesSupport();
    }

    @Then("^Verify all available operation on Agriculture Marketing Material & Sales Support Article Page$")
    public void verifyAllAvailableOperationOnAgricultureMarketingMaterialSalesSupportArticlePage() {
        agriMarketingMaterialAndSalesSupport.verifyAgricultureMarketingMaterialSalesSupport();
    }

    @And("^I am able to verify and select Blank space tbc Category on Marketing Material and Sales Support Category$")
    public void iAmAbleToVerifyAndSelectBlankSpaceTbcCategoryOnMarketingMaterialAndSalesSupportCategory() {
        agriMarketingMaterialAndSalesSupport.getBlankSpaceTBC();
    }

    @Then("^Verify all available operation on Blank space tbc Article Page$")
    public void verifyAllAvailableOperationOnBlankSpaceTbcArticlePage() {
        agriMarketingMaterialAndSalesSupport.verifyBlankSpaceTBC();
    }

    @And("^I am able to verify and select Media Articles Category on Marketing Material and Sales Support Category$")
    public void iAmAbleToVerifyAndSelectMediaArticlesCategoryOnMarketingMaterialAndSalesSupportCategory() {
        agriMarketingMaterialAndSalesSupport.getMediaArticles();
    }

    @Then("^Verify all available operation on Media Articles Article Page$")
    public void verifyAllAvailableOperationOnMediaArticlesArticlePage() {
        agriMarketingMaterialAndSalesSupport.verifyMediaArticles();
    }

    @And("^I am able to verify and select Interviews with Wandile Sihlobo Category on Marketing Material and Sales Support Category$")
    public void iAmAbleToVerifyAndSelectInterviewsWithWandileSihloboCategoryOnMarketingMaterialAndSalesSupportCategory() {
        agriMarketingMaterialAndSalesSupport.getInterviewsWithWandileSihlobo();
    }

    @Then("^Verify all available operation on Interviews with Wandile Sihlobo Article Page$")
    public void verifyAllAvailableOperationOnInterviewsWithWandileSihloboArticlePage() {
        agriMarketingMaterialAndSalesSupport.verifyInterviewsWithWandileSihlobo();
    }

    @And("^I am able to verify and select Client Testimonial Videos Category on Marketing Material and Sales Support Category$")
    public void iAmAbleToVerifyAndSelectClientTestimonialVideosCategoryOnMarketingMaterialAndSalesSupportCategory() {
        agriMarketingMaterialAndSalesSupport.getClientTestimonialVideos();
    }

    @Then("^Verify all available operation on Client Testimonial Videos Article Page$")
    public void verifyAllAvailableOperationOnClientTestimonialVideosArticlePage() {
        agriMarketingMaterialAndSalesSupport.verifyClientTestimonialVideos();
    }
}
