package cm_business_banking.tests;

import cm_business_banking.objects.Communication;
import cm_business_banking.objects.PolicyProcedures;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class PolicyProcedureTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmemqa/BB/Home/Navigation?CategoryId=1237");
    Communication communication = new Communication(launchDriver.getDriver());
    PolicyProcedures policyProcedures = new PolicyProcedures(launchDriver.getDriver());

    @And("^I am able to select and verify Policy Procedure Category on Communication Category$")
    public void iAmAbleToSelectAndVerifyPolicyProcedureCategoryOnCommunicationCategory() {
        communication.getPolicyProcedures();
    }

    @And("^I am able to verify and select Business Banking Credit Policy Updates July Category on Policy Procedure Category$")
    public void iAmAbleToVerifyAndSelectBusinessBankingCreditPolicyUpdatesJulyCategoryOnPolicyProcedureCategory() {
        policyProcedures.getBusinessBankingCreditPolicyUpdatesJuly2019();
    }

    @Then("^Verify all available operation on Business Banking Credit Policy Updates July Article Page$")
    public void verifyAllAvailableOperationOnBusinessBankingCreditPolicyUpdatesJulyArticlePage() {
        policyProcedures.verifyBusinessBankingCreditPolicyUpdatesJuly2019();
    }

    @And("^I am able to verify and select Business Banking Credit Policy Updates June (\\d+) Category on Policy Procedure Category$")
    public void iAmAbleToVerifyAndSelectBusinessBankingCreditPolicyUpdatesJuneCategoryOnPolicyProcedureCategory(int arg0) {
        policyProcedures.getBusinessBankingCreditPolicyUpdatesJune2019();
    }

    @Then("^Verify all available operation on Business Banking Credit Policy Updates June (\\d+) Article Page$")
    public void verifyAllAvailableOperationOnBusinessBankingCreditPolicyUpdatesJuneArticlePage(int arg0) {
        policyProcedures.verifyBusinessBankingCreditPolicyUpdatesJune2019();
    }

    @And("^I am able to verify and select April Credit Policy Changes Category on Policy Procedure Category$")
    public void iAmAbleToVerifyAndSelectAprilCreditPolicyChangesCategoryOnPolicyProcedureCategory() {
        policyProcedures.getApril2019CreditPolicyChanges();
    }

    @Then("^Verify all available operation on April Credit Policy Changes Article Page$")
    public void verifyAllAvailableOperationOnAprilCreditPolicyChangesArticlePage() {
        policyProcedures.verifyApril2019CreditPolicyChanges();

    }

    @And("^I am able to verify and select November Credit Policy Changes Category on Policy Procedure Category$")
    public void iAmAbleToVerifyAndSelectNovemberCreditPolicyChangesCategoryOnPolicyProcedureCategory() {
        policyProcedures.getNovember2018CreditPolicyChanges();
    }

    @Then("^Verify all available operation on November Credit Policy Changes Article Page$")
    public void verifyAllAvailableOperationOnNovemberCreditPolicyChangesArticlePage() {
        policyProcedures.verifyNovember2018CreditPolicyChanges();
    }

    @And("^I am able to verify and select Rating Model Policy Changes Category on Policy Procedure Category$")
    public void iAmAbleToVerifyAndSelectRatingModelPolicyChangesCategoryOnPolicyProcedureCategory() {
        policyProcedures.getRatingModelPolicyChanges();
    }

    @Then("^Verify all available operation on Rating Model Policy Changes Article Page$")
    public void verifyAllAvailableOperationOnRatingModelPolicyChangesArticlePage() {
        policyProcedures.verifyRatingModelPolicyChanges();
    }

    @And("^I am able to verify and select February Credit Policy Changes Changes Category on Policy Procedure Category$")
    public void iAmAbleToVerifyAndSelectFebruaryCreditPolicyChangesChangesCategoryOnPolicyProcedureCategory() {
        policyProcedures.getFebruary2018CreditPolicyChanges();
    }

    @Then("^Verify all available operation on February Credit Policy Changes Changes Article Page$")
    public void verifyAllAvailableOperationOnFebruaryCreditPolicyChangesChangesArticlePage() {
        policyProcedures.verifyFebruary2018CreditPolicyChanges();
    }

    @And("^I am able to verify and select Risk Restructure Credit Policy Changes December Category on Policy Procedure Category$")
    public void iAmAbleToVerifyAndSelectRiskRestructureCreditPolicyChangesDecemberCategoryOnPolicyProcedureCategory() {
        policyProcedures.getRiskRestructureCreditPolicyChanges1Dec2018();
    }

    @Then("^Verify all available operation on Risk Restructure Credit Policy Changes December Article Page$")
    public void verifyAllAvailableOperationOnRiskRestructureCreditPolicyChangesDecemberArticlePage() {
        policyProcedures.verifyRiskRestructureCreditPolicyChanges1Dec2018();
    }

    @And("^I am able to verify and select January Credit Policy Updates Category on Policy Procedure Category$")
    public void iAmAbleToVerifyAndSelectJanuaryCreditPolicyUpdatesCategoryOnPolicyProcedureCategory() {
        policyProcedures.getJanuary2018CreditPolicyUpdates();
    }

    @Then("^Verify all available operation on January Credit Policy Updates Article Page$")
    public void verifyAllAvailableOperationOnJanuaryCreditPolicyUpdatesArticlePage() {
        policyProcedures.verifyJanuary2018CreditPolicyUpdates();
    }

    @And("^I am able to verify and select Annual Credit Policy Review Category on Policy Procedure Category$")
    public void iAmAbleToVerifyAndSelectAnnualCreditPolicyReviewCategoryOnPolicyProcedureCategory() {
        policyProcedures.getAnnualCreditPolicyReview();
    }

    @Then("^Verify all available operation on Annual Credit Policy Review Article Page$")
    public void verifyAllAvailableOperationOnAnnualCreditPolicyReviewArticlePage() {
        policyProcedures.verifyAnnualCreditPolicyReview();
    }

    @And("^I am able to verify and selectRBB Integration Credit Policy Changes Category on Policy Procedure Category$")
    public void iAmAbleToVerifyAndSelectRBBIntegrationCreditPolicyChangesCategoryOnPolicyProcedureCategory() {
        policyProcedures.getRBBIntegrationCreditPolicyChanges();
    }

    @Then("^Verify all available operation on RBB Integration Credit Policy Changes Article Page$")
    public void verifyAllAvailableOperationOnRBBIntegrationCreditPolicyChangesArticlePage() {
        policyProcedures.verifyRBBIntegrationCreditPolicyChanges();
    }

    @And("^I am able to verify and select Collateral Management And Security Documentation Category on Policy Procedure Category$")
    public void iAmAbleToVerifyAndSelectAutomatedBureauCallsCategoryOnPolicyProcedureCategory() {
        policyProcedures.getCollateralManagementAndSecurityDocumentation();
    }

    @Then("^Verify all available operation on Collateral Management And Security Documentation Article Page$")
    public void verifyAllAvailableOperationOnCollateralManagementAndSecurityDocumentationArticlePage() {
        policyProcedures.verifyCollateralManagementAndSecurityDocumentation();
    }
}
