package cm_business_banking.tests;

import cm_business_banking.objects.Assessments;
import cm_business_banking.objects.CoreBankingSolution;
import cm_business_banking.objects.Invest;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class InvestTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmempr/BB/Home/Navigation?CategoryId=1160");
    CoreBankingSolution coreBankingSolution = new CoreBankingSolution(launchDriver.getDriver());
    Invest invest = new Invest(launchDriver.getDriver());

    @And("^I am able to verify and select Invest Category on Core Banking Solutions Category$")
    public void iAmAbleToVerifyAndSelectInvestCategoryOnCoreBankingSolutionsCategory() {
        coreBankingSolution.getInvest();
    }

    @Then("^I am able to verify and View Notice Deposit Category on Invest Category$")
    public void iAmAbleToVerifyAndViewNoticeDepositCategoryOnInvestCategory() {
        invest.getNoticeDeposit();
    }

    @Then("^I am able to verify and View Term Deposit Category on Invest Category$")
    public void iAmAbleToVerifyAndViewTermDepositCategoryOnInvestCategory() {
        invest.getTermDeposit();
    }

    @Then("^I am able to verify and View Call Account Category on Invest Category$")
    public void iAmAbleToVerifyAndViewCallAccountCategoryOnInvestCategory() {
        invest.getCallAccount();
    }
}
