package cm_business_banking.tests;

import cm_business_banking.objects.BBProductCommunications;
import cm_business_banking.objects.Communication;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class BBProductCommunication {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmemqa/BB/Home/Navigation?CategoryId=1237");
    Communication communication = new Communication(launchDriver.getDriver());
    BBProductCommunications bbProductCommunications = new BBProductCommunications(launchDriver.getDriver());

    @And("^I am able to select and verify BB Product Communication Category on Communication Category$")
    public void iAmAbleToSelectAndVerifyBBProductCommunicationCategoryOnCommunicationCategory() {
        communication.getBBProductCommunications();
    }

    @And("^I am able to verify and select Small Sized Agric Clients Credit Assessment Category on BB Product Communication$")
    public void iAmAbleToVerifyAndSelectSmallSizedAgricClientsCreditAssessmentCategoryOnBBProductCommunication() {
        bbProductCommunications.getSmallSizedAgricClientsCreditAssessment();
    }

    @Then("^Verify all available operation on Small Sized Agric Clients Credit Assessment Article Page$")
    public void verifyAllAvailableOperationOnSmallSizedAgricClientsCreditAssessmentArticlePage() {
        bbProductCommunications.verifySmallSizedAgricClientsCreditAssessment();
    }

    @And("^I am able to verify and select Business Credit Card Category on BB Product Communication$")
    public void iAmAbleToVerifyAndSelectBusinessCreditCardCategoryOnBBProductCommunication() {
        bbProductCommunications.getBusinessCreditCard();
    }

    @Then("^Verify all available operation on Business Credit Card Article Page$")
    public void verifyAllAvailableOperationOnBusinessCreditCardArticlePage() {
        bbProductCommunications.verifyBusinessCreditCard();
    }
}
