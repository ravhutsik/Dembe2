package cm_business_banking.tests;

import cm_business_banking.objects.*;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class ExternalClientCommunicationTest {

    LaunchDriver launchDriver = new LaunchDriver("http://biscorpmemqa/BB/Home/Navigation?CategoryId=1167");
    CreditTemplateForm creditTemplateForm = new CreditTemplateForm(launchDriver.getDriver());
    ExternalClientCommunicationCategory externalClientCommunicationCategory = new ExternalClientCommunicationCategory(launchDriver.getDriver());
    DocumentLibrary documentLibrary = new DocumentLibrary(launchDriver.getDriver());



    @And("^I am able to select and verify Credit Templates And Forms on Document Library Category$")
    public void iAmAbleToSelectAndVerifyCreditTemplatesAndFormsOnDocumentLibraryCategory() throws Exception{
        try {
            documentLibrary.getCreditTemplatesAndForms();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @And("^I am able to select and verify External Client Communication Category on Credit Templates And Forms Category$")
    public void iAmAbleToSelectAndVerifyExternalClientCommunicationCategoryOnCreditTemplatesAndFormsCategory() {
        try {
            creditTemplateForm.getExternalClientCommunication();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @And("^I am able to verify and select Credit Granting Category on External Client Communication Category$")
    public void iAmAbleToVerifyAndSelectCreditGrantingCategoryOnExternalClientCommunicationCategory() {
        try {
            externalClientCommunicationCategory.getCreditGranting();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @Then("^Verify all available operation on Credit Granting Page$")
    public void verifyAllAvailableOperationOnCreditGrantingPage() {
        try {
            externalClientCommunicationCategory.verifyCreditGranting();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @And("^I am able to verify and select Credit Administration Category on External Client Communication Category$")
    public void iAmAbleToVerifyAndSelectCreditAdministrationCategoryOnExternalClientCommunicationCategory() {
        try {
            externalClientCommunicationCategory.getCreditAdministration();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @Then("^Verify all available operation on Credit Administration Page$")
    public void verifyAllAvailableOperationOnCreditAdministrationPage() {
        try {
            externalClientCommunicationCategory.verifyCreditAdministration();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @And("^I am able to verify and select Credit Portfolio Management Category on External Client Communication Category$")
    public void iAmAbleToVerifyAndSelectCreditPortfolioManagementCategoryOnExternalClientCommunicationCategory() {
        try {
            externalClientCommunicationCategory.getCreditPortfolioManagement();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @Then("^Verify all available operation on Credit Portfolio Management Page$")
    public void verifyAllAvailableOperationOnCreditPortfolioManagementPage() {
        try {
            externalClientCommunicationCategory.verifyCreditPortfolioManagement();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @And("^I am able to verify and select Debt Enforcement Category on External Client Communication Category$")
    public void iAmAbleToVerifyAndSelectDebtEnforcementCategoryOnExternalClientCommunicationCategory() {
        try {
            externalClientCommunicationCategory.getDebtEnforcementCreditRiskRecovery();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @Then("^Verify all available operation on Debt Enforcement Page$")
    public void verifyAllAvailableOperationOnDebtEnforcementPage() {
        try {
            externalClientCommunicationCategory.verifyDebtEnforcementCreditRiskRecovery();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }
}
