package cm_business_banking.tests;

import cm_business_banking.objects.ApplicationToolsCategory;
import cm_business_banking.objects.Credit;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class ApplicationToolsTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmemqa/BB/Home/Navigation?CategoryId=1153");
    Credit credit = new Credit(launchDriver.getDriver());
    ApplicationToolsCategory applicationToolsCategory = new ApplicationToolsCategory(launchDriver.getDriver());

    @And("^I am able to select and verify Application Tools Category on Credit Category$")
    public void iAmAbleToSelectAndVerifyApplicationToolsCategoryOnCreditCategory() {
        credit.getApplicationTools();
    }

    @And("^I am able to verify and select Application Tools Hyperlink Category on Application Tools Category$")
    public void iAmAbleToVerifyAndSelectApplicationToolsHyperlinkCategoryOnApplicationToolsCategory() {
        applicationToolsCategory.getApplicationToolsHyperlink();
    }

    @Then("^Verify all available operation on Application Tools Hyperlink Article Page$")
    public void verifyAllAvailableOperationOnApplicationToolsHyperlinkArticlePage() {
        applicationToolsCategory.verifyApplicationToolsHyperlink();
    }

    @And("^I am able to verify and select Global Bond Capturing Sheet Category on Application Tools Category$")
    public void iAmAbleToVerifyAndSelectGlobalBondCapturingSheetCategoryOnApplicationToolsCategory() {
        applicationToolsCategory.getGlobalBondCapturingSheet();
    }

    @Then("^Verify all available operation on Global Bond Capturing Sheet Article Page$")
    public void verifyAllAvailableOperationOnGlobalBondCapturingSheetArticlePage() {
        applicationToolsCategory.verifyGlobalBondCapturingSheet();
    }

    @And("^I am able to verify and select Bank Code Calculator Category on Application Tools Category$")
    public void iAmAbleToVerifyAndSelectBankCodeCalculatorCategoryOnApplicationToolsCategory() {
        applicationToolsCategory.getBankCodeCalculator();
    }

    @Then("^Verify all available operation on Bank Code Calculator Article Page$")
    public void verifyAllAvailableOperationOnBankCodeCalculatorArticlePage() {
        applicationToolsCategory.verifyBankCodeCalculator();
    }

    @And("^I am able to verify and select Discretionary Mandate Schedule Category on Application Tools Category$")
    public void iAmAbleToVerifyAndSelectDiscretionaryMandateScheduleCategoryOnApplicationToolsCategory() {
        applicationToolsCategory.getDiscretionaryMandateSchedule();
    }

    @Then("^Verify all available operation on Discretionary Mandate Schedule Article Page$")
    public void verifyAllAvailableOperationOnDiscretionaryMandateScheduleArticlePage() {
        applicationToolsCategory.verifyDiscretionaryMandateSchedule();
    }

    @And("^I am able to verify and select Debtors Analysis Sheet Category on Application Tools Category$")
    public void iAmAbleToVerifyAndSelectDebtorsAnalysisSheetCategoryOnApplicationToolsCategory() {
        applicationToolsCategory.getDebtorsAnalysisSheet();
    }

    @Then("^Verify all available operation on Debtors Analysis Sheet Article Page$")
    public void verifyAllAvailableOperationOnDebtorsAnalysisSheetArticlePage() {
        applicationToolsCategory.verifyOperationalManagement();
    }

    @And("^I am able to verify and select NCA Initiation Fee Calculator Category on Application Tools Category$")
    public void iAmAbleToVerifyAndSelectNCAInitiationFeeCalculatorCategoryOnApplicationToolsCategory() {
        applicationToolsCategory.getApplicationToolsHyperlink();
    }

    @Then("^Verify all available operation on NCA Initiation Fee Calculator Article Page$")
    public void verifyAllAvailableOperationOnNCAInitiationFeeCalculatorArticlePage() {
        applicationToolsCategory.verifyNCAInitiationFeeCalculator();
    }
}
