package cm_business_banking.tests;

import cm_business_banking.objects.*;
import cucumber.api.java.en.And;

public class StrategyAndApproachTest {

    LaunchDriver loadBusinessBankingURL=new LaunchDriver("http://biscorpmempr/BB/Home/Navigation?CategoryId=1881");
    MoreCategories moreCategories = new MoreCategories(loadBusinessBankingURL.getDriver());
    ClientExperience clientExperience = new ClientExperience(loadBusinessBankingURL.getDriver());
    StrategyAndApproach strategyAndApproach = new StrategyAndApproach(loadBusinessBankingURL.getDriver());

    @And("^I am able to verify and select Taking Client Experience To The Next Level Category on More Categories Category$")
    public void iAmAbleToVerifyAndSelectTakingClientExperienceToTheNextLevelCategoryOnMoreCategoriesCategory() {
        moreCategories.getTakingClientExperienceNextLevel();
    }

    @And("^I am able to verify and select Strategy and Approach Category on Taking Client Experience To The Next Level Category$")
    public void iAmAbleToVerifyAndSelectStrategyAndApproachCategoryOnTakingClientExperienceToTheNextLevelCategory() {
        clientExperience.getStrategyAndApproach();
    }

    @And("^I am able to verify and select BB Purpose and Client Experience Category on Strategy and Approach Category$")
    public void iAmAbleToVerifyAndSelectBBPurposeAndClientExperienceCategoryOnStrategyAndApproachCategory() {
        strategyAndApproach.getBBPurposeAndClientExperience();
    }

    @And("^I am able to verify and select BB Value Proposition Category on Strategy and Approach Category$")
    public void iAmAbleToVerifyAndSelectBBValuePropositionCategoryOnStrategyAndApproachCategory() {
        strategyAndApproach.getBBValueProposition();
    }
}
