package cm_business_banking.tests;

import cm_business_banking.objects.Franchising;
import cm_business_banking.objects.FuelAndRentalGuarantees;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class FuelAndRentalGuaranteesTest {
    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmempr/BB/Home/Navigation?CategoryId=1337");
    Franchising franchising = new Franchising(launchDriver.getDriver());
    FuelAndRentalGuarantees fuelAndRentalGuarantees = new FuelAndRentalGuarantees(launchDriver.getDriver());

    @And("^I am able to verify and select Fuel and Rental Guarantees Category from Franchising Category$")
    public void iAmAbleToVerifyAndSelectFuelAndRentalGuaranteesCategoryFromFranchisingCategory() {
        franchising.getFuelAndRentalGuarantees();
    }

    @And("^I am able to verify and select Fuel and Rental Guarantees Category on Fuel and Rental Guarantees Category$")
    public void iAmAbleToVerifyAndSelectFuelAndRentalGuaranteesCategoryOnFuelAndRentalGuaranteesCategory() {
        fuelAndRentalGuarantees.getFuelRentalGuarantees();
    }

    @Then("^Verify all available operation on Fuel and Rental Guarantees Article Page$")
    public void verifyAllAvailableOperationOnFuelAndRentalGuaranteesArticlePage() {
        fuelAndRentalGuarantees.verifyOperationalManagement();
    }
}
