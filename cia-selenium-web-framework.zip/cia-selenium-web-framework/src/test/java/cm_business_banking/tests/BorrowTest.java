package cm_business_banking.tests;

import cm_business_banking.objects.Borrow;
import cm_business_banking.objects.CoreBankingSolution;
import cm_business_banking.objects.Invest;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class BorrowTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmempr/BB/Home/Navigation?CategoryId=1160");
    CoreBankingSolution coreBankingSolution = new CoreBankingSolution(launchDriver.getDriver());
    Borrow borrow = new Borrow(launchDriver.getDriver());

    @And("^I am able to verify and select Borrow Category on Core Banking Solutions Category$")
    public void iAmAbleToVerifyAndSelectBorrowCategoryOnCoreBankingSolutionsCategory() {
        coreBankingSolution.getBorrow();
    }

    @Then("^I am able to verify and View Overdraft Category on Borrow Category$")
    public void iAmAbleToVerifyAndViewOverdraftCategoryOnBorrowCategory() {
        borrow.getOverdraft();
    }

    @Then("^I am able to verify and View Asset Based Finance \\(ABF\\) Category on Borrow Category$")
    public void iAmAbleToVerifyAndViewAssetBasedFinanceABFCategoryOnBorrowCategory() {
        borrow.getAssetBasedFinance();
    }

    @Then("^I am able to verify and View Commercial Bond Category on Borrow Category$")
    public void iAmAbleToVerifyAndViewCommercialBondCategoryOnBorrowCategory() {
        borrow.getCommercialBond();
    }

    @Then("^I am able to verify and View Local Guarantees Category on Borrow Category$")
    public void iAmAbleToVerifyAndViewLocalGuaranteesCategoryOnBorrowCategory() {
        borrow.getLocalGuarantees();
    }

    @Then("^I am able to verify and View Residential Home Loan \\(RHL\\) Category on Borrow Category$")
    public void iAmAbleToVerifyAndViewResidentialHomeLoanRHLCategoryOnBorrowCategory() {
        borrow.getResidentialHomeLoan();
    }

    @Then("^I am able to verify and View Medium Term Loan \\(MTL\\) Category on Borrow Category$")
    public void iAmAbleToVerifyAndViewMediumTermLoanMTLCategoryOnBorrowCategory() {
        borrow.getMediumTermLoan();
    }
}
