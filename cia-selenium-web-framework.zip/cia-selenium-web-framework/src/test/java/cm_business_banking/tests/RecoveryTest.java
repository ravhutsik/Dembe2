package cm_business_banking.tests;

import cm_business_banking.objects.DocumentLibrary;
import cm_business_banking.objects.RecoveryCategory;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class RecoveryTest {

    LaunchDriver launchDriver = new LaunchDriver("http://biscorpmemqa/BB/Home/Navigation?CategoryId=1167");

    DocumentLibrary documentLibrary = new DocumentLibrary(launchDriver.getDriver());
    RecoveryCategory recoveryCategory = new RecoveryCategory(launchDriver.getDriver());

    @And("^I am able to select and verify Recoveries Category on Document Library$")
    public void iAmAbleToSelectAndVerifyRecoveriesCategoryOnDocumentLibrary() {
        documentLibrary.getRecoveries();
    }

    @And("^I am able to verify and select RECOVERIES TAKE ON SHEET Category on Recoveries Category$")
    public void iAmAbleToVerifyAndSelectRECOVERIESTAKEONSHEETCategoryOnRecoveriesCategory() {
        recoveryCategory.getRecoverySheet();
    }

    @Then("^Verify all available operation on RECOVERIES TAKE ON SHEET Article Page$")
    public void verifyAllAvailableOperationOnRECOVERIESTAKEONSHEETArticlePage() {
        recoveryCategory.verifyRecoverySheet();
    }

    @And("^I am able to verify and select Write-off Template Category on Recoveries Category$")
    public void iAmAbleToVerifyAndSelectWriteOffTemplateCategoryOnRecoveriesCategory() {
        recoveryCategory.getWriteOffTemplate();
    }

    @Then("^Verify all available operation on Write-off Template Article Page$")
    public void verifyAllAvailableOperationOnWriteOffTemplateArticlePage() {
        recoveryCategory.verifyWriteOffTemplate();
    }

    @And("^I am able to verify and select TN Test Article Category on Recoveries Category$")
    public void iAmAbleToVerifyAndSelectTNTestArticleCategoryOnRecoveriesCategory() {
        recoveryCategory.getTNTestArticle();
    }

    @Then("^Verify all available operation on TN Test Article Article Page$")
    public void verifyAllAvailableOperationOnTNTestArticleArticlePage() {
        recoveryCategory.verifyTNTestArticle();
    }

    @And("^I am able to verify and select Whole-view BB Afrikaans editorial Category on Recoveries Category$")
    public void iAmAbleToVerifyAndSelectWholeViewBBAfrikaansEditorialCategoryOnRecoveriesCategory() {
        recoveryCategory.getWholeViewBBEditorial();
    }

    @Then("^Verify all available operation on Whole-view BB Afrikaans editorial Article Page$")
    public void verifyAllAvailableOperationOnWholeViewBBAfrikaansEditorialArticlePage() {
        recoveryCategory.verifyWholeViewBBEditorial();
    }

    @And("^I am able to verify and select Nedbank PRB ENG Lawyer Mix Category on Recoveries Category$")
    public void iAmAbleToVerifyAndSelectNedbankPRBENGLawyerMixCategoryOnRecoveriesCategory() {
        recoveryCategory.getPBREngLawyer();
    }

    @Then("^Verify all available operation on Nedbank PRB ENG Lawyer MixArticle Page$")
    public void verifyAllAvailableOperationOnNedbankPRBENGLawyerMixArticlePage() {
        recoveryCategory.verifyPBREngLawyer();
    }

    @And("^I am able to verify and select Boxer Campaign Category on Recoveries Category$")
    public void iAmAbleToVerifyAndSelectBoxerCampaignCategoryOnRecoveriesCategory() {
        recoveryCategory.getBoxerCampaign();
    }

    @Then("^Verify all available operation on Boxer Campaign Article Page$")
    public void verifyAllAvailableOperationOnBoxerCampaignArticlePage() {
        recoveryCategory.verifyBoxerCampaign();
    }

    @And("^I am able to verify and select Wholeview Digital banners product Category on Recoveries Category$")
    public void iAmAbleToVerifyAndSelectWholeviewDigitalBannersProductCategoryOnRecoveriesCategory() {
        recoveryCategory.getWholeViewDigitalBannerProduct();
    }

    @Then("^Verify all available operation on Wholeview Digital banners product Article Page$")
    public void verifyAllAvailableOperationOnWholeviewDigitalBannersProductArticlePage() {
        recoveryCategory.verifyWholeViewDigitalBannerProduct();
    }

    @And("^I am able to verify and select Debtor Management Campaign radio advert Category on Recoveries Category$")
    public void iAmAbleToVerifyAndSelectDebtorManagementCampaignRadioAdvertCategoryOnRecoveriesCategory() {
        recoveryCategory.getDebtorManagementCampaign();
    }

    @Then("^Verify all available operation on Debtor Management Campaign radio advert Article Page$")
    public void verifyAllAvailableOperationOnDebtorManagementCampaignRadioAdvertArticlePage() {
        recoveryCategory.verifyDebtorManagementCampaign();
    }
}
