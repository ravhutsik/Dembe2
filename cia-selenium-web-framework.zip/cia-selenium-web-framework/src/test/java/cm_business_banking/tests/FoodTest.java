package cm_business_banking.tests;

import cm_business_banking.objects.*;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class FoodTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmempr/BB/Home/Navigation?CategoryId=1337");
    ClientValuePropositions clientValuePropositions = new ClientValuePropositions(launchDriver.getDriver());

    Food food = new Food(launchDriver.getDriver());

    @And("^I am able to verify and select Food Category from Client Value Propositions Category$")
    public void iAmAbleToVerifyAndSelectFoodCategoryFromClientValuePropositionsCategory() {
        clientValuePropositions.getFood();
    }

    @And("^I am able to verify and select An Adega Category on Food Category$")
    public void iAmAbleToVerifyAndSelectAnAdegaCategoryOnFoodCategory() {
        food.getAdega();
    }

    @Then("^Verify all available operation on An Adega Article Page$")
    public void verifyAllAvailableOperationOnAnAdegaArticlePage() {
        food.verifyAdega();
    }

    @And("^I am able to verify and select Andiccio (\\d+) Category on Food Category$")
    public void iAmAbleToVerifyAndSelectAndiccioCategoryOnFoodCategory() {
        food.getAndiccio24();
    }

    @Then("^Verify all available operation on Andiccio (\\d+) Article Page$")
    public void verifyAllAvailableOperationOnAndiccioArticlePage() {
        food.verifyAndiccio24();
    }

    @And("^I am able to verify and select Chicken Licken Category on Food Category$")
    public void iAmAbleToVerifyAndSelectChickenLickenCategoryOnFoodCategory() {
        food.getChickenLicken();
    }

    @And("^Verify all available operation on Chicken Licken Article Page$")
    public void verifyAllAvailableOperationOnChickenLickenCategoryOnFoodCategory() {
        food.verifyChickenLicken();
    }

    @And("^I am able to verify and select Boost Juice Category on Food Category$")
    public void iAmAbleToVerifyAndSelectBoostJuiceCategoryOnFoodCategory() {
        food.getBoostJuice();
    }

    @Then("^Verify all available operation on Boost Juice Article Page$")
    public void verifyAllAvailableOperationOnBoostJuiceArticlePage() {
        food.verifyBoostJuice();
    }

    @And("^I am able to verify and select Bread Basket Category on Food Category$")
    public void iAmAbleToVerifyAndSelectBreadBasketCategoryOnFoodCategory() {
        food.getBreadBasket();
    }

    @Then("^Verify all available operation on Bread Basket Article Page$")
    public void verifyAllAvailableOperationOnBreadBasketArticlePage() {
        food.verifyBreadBasket();
    }

    @And("^I am able to verify and select An Burger King Category on Food Category$")
    public void iAmAbleToVerifyAndSelectAnBurgerKingCategoryOnFoodCategory() {
        food.getTigerBurgerKing();
    }

    @Then("^Verify all available operation on Burger King Article Page$")
    public void verifyAllAvailableOperationOnBurgerKingArticlePage() {
        food.verifyBurgerKing();
    }

    @And("^I am able to verify and select Coffee Couture Category on Food Category$")
    public void iAmAbleToVerifyAndSelectCoffeeCoutureCategoryOnFoodCategory() {
        food.getCoffeeCouture();
    }

    @Then("^Verify all available operation on Coffee Couture Article Page$")
    public void verifyAllAvailableOperationOnCoffeeCoutureArticlePage() {
        food.verifyCoffeeCouture();
    }

    @And("^I am able to verify and select Cape Town Fish Market Category on Food Category$")
    public void iAmAbleToVerifyAndSelectCapeTownFishMarketCategoryOnFoodCategory() {
        food.getCapeTownFishMarket();
    }

    @Then("^Verify all available operation on Cape Town Fish Market Article Page$")
    public void verifyAllAvailableOperationOnCapeTownFishMarketArticlePage() {
        food.verifyCapeTownFishMarket();
    }

    @And("^I am able to verify and select Debonairs Category on Food Category$")
    public void iAmAbleToVerifyAndSelectDebonairsCategoryOnFoodCategory() {
        food.getDebonairs();
    }

    @Then("^Verify all available operation on Debonairs Article Page$")
    public void verifyAllAvailableOperationOnDebonairsArticlePage() {
        food.verifyDebonairs();
    }

    @And("^I am able to verify and select cafe (\\d+) go Category on Food Category$")
    public void iAmAbleToVerifyAndSelectCafeGoCategoryOnFoodCategory() {
        food.getCafe2Go();
    }

    @Then("^Verify all available operation on cafe (\\d+) go Article Page$")
    public void verifyAllAvailableOperationOnCafeGoArticlePage() {
        food.verifyCafe2Go();
    }
}
