package cm_business_banking.tests;

import cm_business_banking.objects.Credit;
import cm_business_banking.objects.ProceduralManualCategory;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class ProceduralManualTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmemqa/BB/Home/Navigation?CategoryId=1153");
    Credit credit = new Credit(launchDriver.getDriver());
    ProceduralManualCategory proceduralManualTest = new ProceduralManualCategory(launchDriver.getDriver());


    @And("^I am able to select and verify Procedural Manual Category on Credit Category$")
    public void iAmAbleToSelectAndVerifyProceduralManualCategoryOnCreditCategory() {
        credit.getProceduralManuals();
    }

    @And("^I am able to verify and select E-watchList Category on Procedural Manual Category$")
    public void iAmAbleToVerifyAndSelectEWatchListCategoryOnProceduralManualCategory() {
        proceduralManualTest.getWatchList();
    }

    @Then("^Verify all available operation on E-watchList Page$")
    public void verifyAllAvailableOperationOnEWatchListPage() {
        proceduralManualTest.verifyWatchList();
    }

    @And("^I am able to verify and select Impairment Write-Off Procedures Category on Procedural Manual Category$")
    public void iAmAbleToVerifyAndSelectImpairmentWriteOffProceduresCategoryOnProceduralManualCategory() {
        proceduralManualTest.getImpairmentWriteOffProcedures();
    }

    @Then("^Verify all available operation on Impairment Write-Off Procedures Page$")
    public void verifyAllAvailableOperationOnImpairmentWriteOffProceduresPage() {
        proceduralManualTest.verifyImpairmentWriteOffProcedures();
    }

    @And("^I am able to verify and select Internal Bureau Credit Procedure Category on Procedural Manual Category$")
    public void iAmAbleToVerifyAndSelectInternalBureauCreditProcedureCategoryOnProceduralManualCategory() {
        proceduralManualTest.getInternalBureauCreditProcedure();
    }

    @Then("^Verify all available operation on Internal Bureau Credit Procedure Article Page$")
    public void verifyAllAvailableOperationOnInternalBureauCreditProcedureArticlePage() {
        proceduralManualTest.verifyInternalBureauCreditProcedure();
    }

    @And("^I am able to verify and select Nedbank Owned Property Category on Procedural Manual Category$")
    public void iAmAbleToVerifyAndSelectImpairmentNedbankOwnedPropertyCategoryOnProceduralManualCategory() {
        proceduralManualTest.getNedbankOwnedProperty();
    }

    @Then("^Verify all available operation on Nedbank Owned Property Article Page$")
    public void verifyAllAvailableOperationOnNedbankOwnedPropertyArticlePage() {
        proceduralManualTest.verifyNedbankOwnedProperty();
    }

    @And("^I am able to verify and select Recoveries Procedural Manual Category on Procedural Manual Category$")
    public void iAmAbleToVerifyAndSelectRecoveriesProceduralManualCategoryOnProceduralManualCategory() {
        proceduralManualTest.getRecoveriesProceduralManual();
    }

    @Then("^Verify all available operation on Recoveries Procedural Manual Article Page$")
    public void verifyAllAvailableOperationOnRecoveriesProceduralManualArticlePage() {
        proceduralManualTest.verifyRecoveriesProceduralManual();
    }

    @And("^I am able to verify and select Experian Procedure Category on Procedural Manual Category$")
    public void iAmAbleToVerifyAndSelectExperianProcedureCategoryOnProceduralManualCategory() {
        proceduralManualTest.getExperianProcedure();
    }

    @Then("^Verify all available operation on Experian Procedure Article Page$")
    public void verifyAllAvailableOperationOnExperianProcedureArticlePage() {
        proceduralManualTest.verifyExperianProcedure();
    }

    @And("^I am able to verify and select Actual Recovery Quick Reference Category on Procedural Manual Category$")
    public void iAmAbleToVerifyAndSelectActualRecoveryQuickReferenceCategoryOnProceduralManualCategory() {
        proceduralManualTest.getActualRecoveryQuickReference();
    }

    @Then("^Verify all available operation on Actual Recovery Quick Reference Article Page$")
    public void verifyAllAvailableOperationOnActualRecoveryQuickReferenceArticlePage() {
        proceduralManualTest.verifyActualRecoveryQuickReference();
    }
}
