package cm_business_banking.tests;

import cm_business_banking.objects.Borrow;
import cm_business_banking.objects.CoreBankingSolution;
import cm_business_banking.objects.CoreBankingTools;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class CoreBankingToolsTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmempr/BB/Home/Navigation?CategoryId=1160");
    CoreBankingSolution coreBankingSolution = new CoreBankingSolution(launchDriver.getDriver());
    CoreBankingTools coreBankingTools = new CoreBankingTools(launchDriver.getDriver());

    @And("^I am able to verify and select Core Banking Tools Category on Core Banking Solutions Category$")
    public void iAmAbleToVerifyAndSelectCoreBankingToolsCategoryOnCoreBankingSolutionsCategory() {
        coreBankingSolution.getCoreBankingTools();
    }

    @Then("^I am able to verify and View Pre-work Core Banking Category on Core Banking Tools Category$")
    public void iAmAbleToVerifyAndViewPreWorkCoreBankingCategoryOnCoreBankingToolsCategory() {
        coreBankingTools.getPreWorkCoreBanking();
    }

    @Then("^I am able to verify and View Sales Pitch tool Category on Core Banking Tools Category$")
    public void iAmAbleToVerifyAndViewSalesPitchToolCategoryOnCoreBankingToolsCategory() {
        coreBankingTools.getSalesPitchTool();
    }

    @Then("^I am able to verify and View Master Client Proposal Template Category on Core Banking Tools Category$")
    public void iAmAbleToVerifyAndViewMasterClientProposalTemplateCategoryOnCoreBankingToolsCategory() {
        coreBankingTools.getMasterClientProposalTemplate();
    }

    @Then("^I am able to verify and View Banker Toolkit Category on Core Banking Tools Category$")
    public void iAmAbleToVerifyAndViewBankerToolkitCategoryOnCoreBankingToolsCategory() {
        coreBankingTools.getBankerToolkit();
    }
}
