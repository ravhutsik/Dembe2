package cm_business_banking.tests;

import cm_business_banking.objects.BedreshKeyCommunications;
import cm_business_banking.objects.Communication;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class BedreshKeyCommunicationsTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmemqa/BB/Home/Navigation?CategoryId=1237");
    Communication communication = new Communication(launchDriver.getDriver());
    BedreshKeyCommunications bedreshKeyCommunications = new BedreshKeyCommunications(launchDriver.getDriver());


    @And("^I am able to select and verify Bedresh Key Communications Category on Communication Category$")
    public void iAmAbleToSelectAndVerifyBedreshKeyCommunicationsCategoryOnCommunicationCategory() {
        communication.getBBProductCommunications();
    }

    @And("^I am able to verify and select System Access Controls Category on Bedresh Key Communications$")
    public void iAmAbleToVerifyAndSelectSystemAccessControlsCategoryOnBedreshKeyCommunications() {
        bedreshKeyCommunications.getSystemAccessControls();
    }

    @Then("^Verify all available operation on System Access Controls Article Page$")
    public void verifyAllAvailableOperationOnSystemAccessControlsArticlePage() {
        bedreshKeyCommunications.verifySystemAccessControls();
    }

    @And("^I am able to verify and select Emerald eReview Facility Letter Category on Bedresh Key Communications$")
    public void iAmAbleToVerifyAndSelectEmeraldEReviewFacilityLetterCategoryOnBedreshKeyCommunications() {
        bedreshKeyCommunications.getEmeraldEReviewFacilityLetter();
    }

    @Then("^Verify all available operation on Emerald eReview Facility Letter Article Page$")
    public void verifyAllAvailableOperationOnEmeraldEReviewFacilityLetterArticlePage() {
        bedreshKeyCommunications.verifyEmeraldEReviewFacilityLetter();
    }

    @And("^I am able to verify and select Credit And Credit Risk News letter Category on Bedresh Key Communications$")
    public void iAmAbleToVerifyAndSelectCreditAndCreditRiskNewsLetterCategoryOnBedreshKeyCommunications() {
        bedreshKeyCommunications.getCreditAndCreditRiskNewsletter();
    }

    @Then("^Verify all available operation on Credit And Credit Risk News letter Article Page$")
    public void verifyAllAvailableOperationOnCreditAndCreditRiskNewsLetterArticlePage() {
        bedreshKeyCommunications.verifyCreditAndCreditRiskNewsletter();
    }
}
