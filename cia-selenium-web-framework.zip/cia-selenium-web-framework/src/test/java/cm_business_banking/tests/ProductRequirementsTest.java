package cm_business_banking.tests;

import cm_business_banking.objects.ProductRequirements;
import cm_business_banking.objects.PublicSector;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class ProductRequirementsTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmemqa/BB/Home/Navigation?CategoryId=1251");

    PublicSector publicSector = new PublicSector(launchDriver.getDriver());
    ProductRequirements productRequirements = new ProductRequirements(launchDriver.getDriver());

    @And("^I am able to select and verify Product Requirements Category on Public Sector Category$")
    public void iAmAbleToSelectAndVerifyProductRequirementsCategoryOnPublicSectorCategory() {
        publicSector.getProductRequirements();
    }

    @And("^I am able to verify and select Public Sector Product Requirements Category on Solution And Service Category$")
    public void iAmAbleToVerifyAndSelectPublicSectorProductRequirementsCategoryOnSolutionAndServiceCategory() {
        productRequirements.getPublicSectorProductRequirements();
    }

    @Then("^Verify all available operation on Public Sector Product Requirements Article Page$")
    public void verifyAllAvailableOperationOnPublicSectorProductRequirementsArticlePage() {
        productRequirements.verifyPublicSectorProductRequirements();
    }
}
