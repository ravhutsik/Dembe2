package cm_business_banking.tests;

import cm_business_banking.objects.HomeCategory;
import cm_business_banking.objects.LeadershipInsights;
import cm_business_banking.objects.MoreCategories;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LeadershipInsightsTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmemqa/BB/Home");
    HomeCategory homeCategory = new HomeCategory(launchDriver.getDriver());
    MoreCategories moreCategories = new MoreCategories(launchDriver.getDriver());
    LeadershipInsights leadershipInsights = new LeadershipInsights(launchDriver.getDriver());



    @When("^I am able to verify and select More Categories Category$")
    public void iAmAbleToVerifyAndSelectMoreCategoriesCategory() {
        homeCategory.getMoreCategories();
    }

    @And("^I am able to verify and select Leadership Insights Category on More CategoriesCategory$")
    public void iAmAbleToVerifyAndSelectLeadershipInsightsCategoryOnMoreCategoriesCategory() {
        moreCategories.getLeadershipInsights();
    }
    @And("^I am able to verify and select An How Great Leaders Inspire Action Category on Leadership Insights Category$")
    public void iAmAbleToVerifyAndSelectAnHowGreatLeadersInspireActionCategoryOnLeadershipInsightsCategory() {
        leadershipInsights.getGreatLeadersInspireAction();
    }

    @Then("^Verify all available operation on An How Great Leaders Inspire Action Article Page$")
    public void verifyAllAvailableOperationOnAnHowGreatLeadersInspireActionArticlePage() {
        leadershipInsights.verifyGreatLeadersInspireAction();
    }

    @And("^I am able to verify and select Bend - High Performance Teams Category on Leadership Insights Category$")
    public void iAmAbleToVerifyAndSelectBendHighPerformanceTeamsCategoryOnLeadershipInsightsCategory() {
        leadershipInsights.getBendHighPerformanceTeams();
    }

    @Then("^Verify all available operation on Bend - High Performance Teams Article Page$")
    public void verifyAllAvailableOperationOnBendHighPerformanceTeamsArticlePage() {
        leadershipInsights.verifyBendHighPerformanceTeams();
    }

    @And("^I am able to verify and select Voices of Bank Transformation Category on Leadership Insights Category$")
    public void iAmAbleToVerifyAndSelectVoicesOfBankTransformationCategoryOnLeadershipInsightsCategory() {
        leadershipInsights.getVoicesOfBankTransformation();

    }

    @Then("^Verify all available operation on Voices of Bank Transformation Article Page$")
    public void verifyAllAvailableOperationOnVoicesOfBankTransformationArticlePage() {
        leadershipInsights.verifyVoicesOfBankTransformation();
    }

    @And("^I am able to verify and select Commercial Insight As the New Sales Currency Category on Leadership Insights Category$")
    public void iAmAbleToVerifyAndSelectCommercialInsightAsTheNewSalesCurrencyCategoryOnLeadershipInsightsCategory() {
        leadershipInsights.getCommercialInsightAsTheNewSalesCurrency();
    }

    @Then("^Verify all available operation on Commercial Insight As the New Sales Currency Article Page$")
    public void verifyAllAvailableOperationOnCommercialInsightAsTheNewSalesCurrencyArticlePage() {
        leadershipInsights.verifyCommercialInsightAsTheNewSalesCurrency();
    }

    @And("^I am able to verify and select Nedbank RBB Induction Video Category on Leadership Insights Category$")
    public void iAmAbleToVerifyAndSelectNedbankRBBInductionVideoCategoryOnLeadershipInsightsCategory() {
        leadershipInsights.getNedbankRBBInductionVideo();
    }

    @Then("^Verify all available operation on Nedbank RBB Induction Video Article Page$")
    public void verifyAllAvailableOperationOnNedbankRBBInductionVideoArticlePage() {
        leadershipInsights.verifyNedbankRBBInductionVideoLabel();
    }


}
