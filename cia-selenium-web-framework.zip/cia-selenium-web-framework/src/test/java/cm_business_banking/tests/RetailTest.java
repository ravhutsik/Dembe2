package cm_business_banking.tests;

import cm_business_banking.objects.ClientValuePropositions;
import cm_business_banking.objects.Retail;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class RetailTest {
    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmempr/BB/Home/Navigation?CategoryId=1337");
    ClientValuePropositions clientValuePropositions = new ClientValuePropositions(launchDriver.getDriver());

    Retail retail = new Retail(launchDriver.getDriver());

    @And("^I am able to verify and select Retail Category from Client Value Propositions Category$")
    public void iAmAbleToVerifyAndSelectRetailCategoryFromClientValuePropositionsCategory() {
        clientValuePropositions.getRetail();
    }

    @And("^I am able to verify and select An OK CVP Category on Retail Category$")
    public void iAmAbleToVerifyAndSelectAnOKCVPCategoryOnRetailCategory() {
        retail.getOKCVP();
    }

    @Then("^Verify all available operation on An OK CVP Article Page$")
    public void verifyAllAvailableOperationOnAnOKCVPArticlePage() {
        retail.verifyOKCVP();
    }

    @And("^I am able to verify and select ACDC Express Category on Retail Category$")
    public void iAmAbleToVerifyAndSelectACDCExpressCategoryOnRetailCategory() {
        retail.getTexanACDCExpress();
    }

    @Then("^Verify all available operation on ACDC Express Article Page$")
    public void verifyAllAvailableOperationOnACDCExpressArticlePage() {
        retail.verifyTexanACDCExpress();
    }

    @And("^I am able to verify and select Build It Category on Retail Category$")
    public void iAmAbleToVerifyAndSelectBuildItCategoryOnRetailCategory() {
        retail.getBuildIt();
    }

    @Then("^Verify all available operation on Build It Article Page$")
    public void verifyAllAvailableOperationOnBuildItArticlePage() {
        retail.verifyBuildIt();
    }


    @And("^I am able to verify and select Bakers Bin Category on Retail Category$")
    public void iAmAbleToVerifyAndSelectBakersBinCategoryOnRetailCategory() {
        retail.getBakersBin();
    }

    @Then("^Verify all available operation on Bakers Bin Article Page$")
    public void verifyAllAvailableOperationOnBakersBinArticlePage() {
        retail.verifyBakersBin();
    }

    @And("^I am able to verify and select Food Lover's Market Category on Retail Category$")
    public void iAmAbleToVerifyAndSelectFoodLoverSMarketCategoryOnRetailCategory() {
        retail.getFoodLoversMarket();
    }

    @Then("^Verify all available operation on Food Lover's Market Article Page$")
    public void verifyAllAvailableOperationOnFoodLoverSMarketArticlePage() {
        retail.verifyFoodLoversMarket();
    }

    @And("^I am able to verify and select Cell C Category on Retail Category$")
    public void iAmAbleToVerifyAndSelectCellCCategoryOnRetailCategory() {
        retail.getCellC();
    }

    @Then("^Verify all available operation on Cell C Article Page$")
    public void verifyAllAvailableOperationOnCellCArticlePage() {
        retail.verifyCellC();
    }

    @And("^I am able to verify and select Dream Nails Category on Retail Category$")
    public void iAmAbleToVerifyAndSelectDreamNailsCategoryOnRetailCategory() {
        retail.getDreamNails();
    }

    @Then("^Verify all available operation on Dream Nails Article Page$")
    public void verifyAllAvailableOperationOnDreamNailsArticlePage() {
        retail.verifyDreamNails();
    }

    @And("^I am able to verify and select Fresh Stop Category on Retail Category$")
    public void iAmAbleToVerifyAndSelectFreshStopCategoryOnRetailCategory() {
        retail.getFreshStop();
    }

    @Then("^Verify all available operation on Fresh Stop Article Page$")
    public void verifyAllAvailableOperationOnFreshStopArticlePage() {
        retail.verifyFreshStop();
    }

    @And("^I am able to verify and select IFix Category on Retail Category$")
    public void iAmAbleToVerifyAndSelectIFixCategoryOnRetailCategory() {
        retail.getIFix();
    }

    @Then("^Verify all available operation on IFix Article Page$")
    public void verifyAllAvailableOperationOnIFixArticlePage() {
        retail.verifyIFix();
    }

    @And("^I am able to verify and select Elite Star Trading Category on Retail Category$")
    public void iAmAbleToVerifyAndSelectEliteStarTradingCategoryOnRetailCategory() {
        retail.getEliteStarTrading();
    }

    @Then("^Verify all available operation on Elite Star Trading Article Page$")
    public void verifyAllAvailableOperationOnEliteStarTradingArticlePage() {
        retail.verifyEliteStarTrading();
    }

    @And("^I am able to verify and select Cash Converters Category on Retail Category$")
    public void iAmAbleToVerifyAndSelectCashConvertersCategoryOnRetailCategory() {
        retail.getCashConverters();
    }

    @Then("^Verify all available operation on Cash Converters Article Page$")
    public void verifyAllAvailableOperationOnCashConvertersArticlePage() {
        retail.verifyCashConverters();
    }


    @And("^I am able to verify and select Mica Category on Retail Category$")
    public void iAmAbleToVerifyAndSelectMicaCategoryOnRetailCategory() {
        retail.getMica();
    }

    @Then("^Verify all available operation on Mica Article Page$")
    public void verifyAllAvailableOperationOnMicaArticlePage() {
        retail.verifyMica();
    }

    @And("^I am able to verify and select Cash Crusaders Category on Retail Category$")
    public void iAmAbleToVerifyAndSelectCashCrusadersCategoryOnRetailCategory() {
        retail.getCashCrusaders();
    }

    @Then("^Verify all available operation on Cash Crusaders Article Page$")
    public void verifyAllAvailableOperationOnCashCrusadersArticlePage() {
        retail.verifyCashCrusaders();
    }

    @And("^I am able to verify and select NWJ Category on Retail Category$")
    public void iAmAbleToVerifyAndSelectNWJCategoryOnRetailCategory() {
        retail.getNWJ();
    }

    @Then("^Verify all available operation on NWJ Article Page$")
    public void verifyAllAvailableOperationOnNWJArticlePage() {
        retail.verifyNWJ();
    }

    @And("^I am able to verify and select Essential Group Category on Retail Category$")
    public void iAmAbleToVerifyAndSelectEssentialGroupCategoryOnRetailCategory() {
        retail.getEssentialGroup();
    }

    @Then("^Verify all available operation on Essential Group Article Page$")
    public void verifyAllAvailableOperationOnEssentialGroupArticlePage() {
        retail.verifyEssentialGroup();
    }

    @And("^I am able to verify and select Overland Category on Retail Category$")
    public void iAmAbleToVerifyAndSelectOverlandCategoryOnRetailCategory() {
        retail.getOverland();
    }

    @Then("^Verify all available operation on Overland Article Page$")
    public void verifyAllAvailableOperationOnOverlandArticlePage() {
        retail.verifyOverland();
    }
}
