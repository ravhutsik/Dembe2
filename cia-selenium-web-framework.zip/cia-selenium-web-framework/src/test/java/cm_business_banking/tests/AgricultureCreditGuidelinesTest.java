package cm_business_banking.tests;

import cm_business_banking.objects.Agriculture;
import cm_business_banking.objects.AgricultureCreditGuidelines;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class AgricultureCreditGuidelinesTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmempr/BB/Home/Navigation?CategoryId=1346");
    Agriculture agriculture = new Agriculture(launchDriver.getDriver());
    AgricultureCreditGuidelines agricultureCreditGuidelines = new AgricultureCreditGuidelines(launchDriver.getDriver());

    @And("^I am able to select and verify Agriculture Credit Guidelines Category on Agriculture Category$")
    public void iAmAbleToSelectAndVerifyAgricultureCreditGuidelinesCategoryOnAgricultureCategory() {
        agriculture.getAgricultureCreditGuidelines();

    }

    @And("^I am able to verify and select Agriculture Credit Guidelines Category on Agriculture Credit Guidelines Category$")
    public void iAmAbleToVerifyAndSelectAgricultureCreditGuidelinesCategoryOnAgricultureCreditGuidelinesCategory() {
        agricultureCreditGuidelines.getAgricultureCreditGuidelines();
    }

    @Then("^Verify all available operation on Agriculture Credit Guidelines Article Page$")
    public void verifyAllAvailableOperationOnAgricultureCreditGuidelinesArticlePage() {
        agricultureCreditGuidelines.verifyAgricultureCreditGuidelines();
    }
}
