package cm_business_banking.tests;

import cm_business_banking.objects.CorporateIdentityGuidesAndBranded;
import cm_business_banking.objects.CreditRiskGovernance;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class FrameworkAndCharters {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmemqa/BB/Home/Navigation?CategoryId=1581");
    CreditRiskGovernance creditRiskGovernance = new CreditRiskGovernance(launchDriver.getDriver());
    CorporateIdentityGuidesAndBranded corporateIdentityGuidesAndBranded = new CorporateIdentityGuidesAndBranded(launchDriver.getDriver());


    @And("^I am able to select and verify Framework And Charters Category on Credit and Risk Governance Category$")
    public void iAmAbleToSelectAndVerifyFrameworkAndChartersCategoryOnCreditAndRiskGovernanceCategory() {
    }

    @And("^I am able to verify and select Bad Debt Write-Off Impairment Committee Charter Category on Framework And Charters Category$")
    public void iAmAbleToVerifyAndSelectBadDebtWriteOffImpairmentCommitteeCharterCategoryOnFrameworkAndChartersCategory() {
    }

    @Then("^Verify all available operation on Bad Debt Write-Off Impairment Committee Charter Article Page$")
    public void verifyAllAvailableOperationOnBadDebtWriteOffImpairmentCommitteeCharterArticlePage() {
    }

    @And("^I am able to verify and select BUCC Charter Category on Framework And Charters Category$")
    public void iAmAbleToVerifyAndSelectBUCCCharterCategoryOnFrameworkAndChartersCategory() {
    }

    @Then("^Verify all available operation on BUCC Charter Article Page$")
    public void verifyAllAvailableOperationOnBUCCCharterArticlePage() {
    }

    @And("^I am able to verify and select Buscram Charter Category on Framework And Charters Category$")
    public void iAmAbleToVerifyAndSelectBuscramCharterCategoryOnFrameworkAndChartersCategory() {
    }

    @Then("^Verify all available operation on Buscram Charter Article Page$")
    public void verifyAllAvailableOperationOnBuscramCharterArticlePage() {
    }

    @And("^I am able to verify and select Credit Risk Framework Category on Framework And Charters Category$")
    public void iAmAbleToVerifyAndSelectCreditRiskFrameworkCategoryOnFrameworkAndChartersCategory() {
    }

    @Then("^Verify all available operation on Credit Risk Framework Article Page$")
    public void verifyAllAvailableOperationOnCreditRiskFrameworkArticlePage() {
    }

    @And("^I am able to verify and select CPPC Charter Category on Framework And Charters Category$")
    public void iAmAbleToVerifyAndSelectCPPCCharterCategoryOnFrameworkAndChartersCategory() {
    }

    @Then("^Verify all available operation on CPPC Charter Article Page$")
    public void verifyAllAvailableOperationOnCPPCCharterArticlePage() {
    }
}
