package cm_business_banking.tests;

import cm_business_banking.objects.HomeCategory;
import cm_business_banking.objects.SalesOpportunity;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SalesOpportunityTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmemqa/BB/Home");
    HomeCategory homeCategory = new HomeCategory(launchDriver.getDriver());
    SalesOpportunity salesOpportunity = new SalesOpportunity(launchDriver.getDriver());

    @When("^I am able to verify and select Sales Opportunity Category$")
    public void iAmAbleToVerifyAndSelectSalesOpportunityCategory() {
        homeCategory.getSalesOpportunities();
    }

    @And("^I am able to verify and select An Sales Levers Category on Sales Opportunity Category$")
    public void iAmAbleToVerifyAndSelectAnSalesLeversCategoryOnSalesOpportunityCategory() {
        salesOpportunity.getSalesLevers();
    }

    @Then("^Verify all available operation on An Sales Levers Article Page$")
    public void verifyAllAvailableOperationOnAnSalesLeversArticlePage() {
        salesOpportunity.verifySalesLevers();
    }

    @And("^I am able to verify and select Sales Initiatives Category on Sales Opportunity Category$")
    public void iAmAbleToVerifyAndSelectSalesInitiativesCategoryOnSalesOpportunityCategory() {
        salesOpportunity.getSalesInitiatives();
    }

    @Then("^Verify all available operation on BB RRB Acquisition Article Page$")
    public void verifyAllAvailableOperationOnBBRRBAcquisitionArticlePage() {
        salesOpportunity.verifyBBRRBAcquisition();
    }

    @Then("^Verify all available operation on MFC Collaboration Article Page$")
    public void verifyAllAvailableOperationOnMFCCollaborationArticlePage() {
        salesOpportunity.verifyMFCCollaboration();
    }
}
