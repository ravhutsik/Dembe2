package cm_business_banking.tests;

import cm_business_banking.objects.CoreBankingSolution;
import cm_business_banking.objects.TransactionalCash;
import cm_business_banking.objects.TransactionalGlobal;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class TransactionalGlobalTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmempr/BB/Home/Navigation?CategoryId=1160");
    CoreBankingSolution coreBankingSolution = new CoreBankingSolution(launchDriver.getDriver());
    TransactionalGlobal transactionalGlobal = new TransactionalGlobal(launchDriver.getDriver());

    @And("^I am able to verify and select Transactional Global Category on Core Banking Solutions Category$")
    public void iAmAbleToVerifyAndSelectTransactionalGlobalCategoryOnCoreBankingSolutionsCategory() {
        coreBankingSolution.getTransactionalGlobal();
    }

    @Then("^I am able to verify and View CFC Account Category on Transactional Global Category$")
    public void iAmAbleToVerifyAndViewCFCAccountCategoryOnTransactionalGlobalCategory() {
        transactionalGlobal.getCFCAccount();
    }

    @Then("^I am able to verify and View NedTreasury Category on Transactional Global Category$")
    public void iAmAbleToVerifyAndViewNedTreasuryCategoryOnTransactionalGlobalCategory() {
        transactionalGlobal.getNedTreasury();
    }

    @Then("^I am able to verify and View Forex Category on Transactional Global Category$")
    public void iAmAbleToVerifyAndViewForexCategoryOnTransactionalGlobalCategory() {
        transactionalGlobal.getForex();
    }

    @Then("^I am able to verify and View GEMS Category on Transactional Global Category$")
    public void iAmAbleToVerifyAndViewGEMSCategoryOnTransactionalGlobalCategory() {
        transactionalGlobal.getGEMS();
    }
}
