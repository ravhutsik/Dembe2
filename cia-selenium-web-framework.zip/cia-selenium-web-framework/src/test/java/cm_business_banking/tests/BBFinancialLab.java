package cm_business_banking.tests;

import cm_business_banking.objects.BusinessBankingFinancialLab;
import cm_business_banking.objects.Credit;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class BBFinancialLab {
    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmemqa/BB/Home/Navigation?CategoryId=1153");
    Credit credit = new Credit(launchDriver.getDriver());
    BusinessBankingFinancialLab businessBankingFinancialLab = new BusinessBankingFinancialLab(launchDriver.getDriver());


    @And("^I am able to select and verify BB Financial Lab Category on Credit Category$")
    public void iAmAbleToSelectAndVerifyBBFinancialLabCategoryOnCreditCategory() {
        credit.getBBFinancialLad();
    }

    @And("^I am able to verify and select IPRE User Guide Category on BB Financial Lab$")
    public void iAmAbleToVerifyAndSelectIPREUserGuideCategoryOnBBFinancialLab() {
        businessBankingFinancialLab.getIPREUserGuide();
    }

    @Then("^Verify all available operation on IPRE User Guide Article Page$")
    public void verifyAllAvailableOperationOnIPREUserGuideArticlePage() {
        businessBankingFinancialLab.verifyIPREUserGuide();
    }

    @And("^I am able to verify and select Introduction Into AIRB And IFRS Models Category on BB Financial Lab$")
    public void iAmAbleToVerifyAndSelectIntroductionIntoAIRBAndIFRSModelsCategoryOnBBFinancialLab() {
        businessBankingFinancialLab.getIntroductionIntoAIRBAndIFRS9Models();

    }

    @Then("^Verify all available operation on Introduction Into AIRB And IFRS Models Article Page$")
    public void verifyAllAvailableOperationOnIntroductionIntoAIRBAndIFRSModelsArticlePage() {
        businessBankingFinancialLab.verifyIntroductionIntoAIRBAndIFRS9Models();
    }

    @And("^I am able to verify and select BB Financial Lab Business Queries Category on BB Financial Lab$")
    public void iAmAbleToVerifyAndSelectBBFinancialLabBusinessQueriesCategoryOnBBFinancialLab() {
        businessBankingFinancialLab.getBBFinancialLabBusinessQueries();
    }

    @Then("^Verify all available operation on BB Financial Lab Business Queries Article Page$")
    public void verifyAllAvailableOperationOnBBFinancialLabBusinessQueriesArticlePage() {
        businessBankingFinancialLab.verifyBBFinancialLabBusinessQueries();
    }

    @And("^I am able to verify and select Rating Tool Help Document Category on BB Financial Lab$")
    public void iAmAbleToVerifyAndSelectRatingToolHelpDocumentCategoryOnBBFinancialLab() {
        businessBankingFinancialLab.getRatingToolHelpDocument();
    }

    @Then("^Verify all available operation on Rating Tool Help Document Article Page$")
    public void verifyAllAvailableOperationOnRatingToolHelpDocumentArticlePage() {
        businessBankingFinancialLab.verifyRatingToolHelpDocument();
    }

    @And("^I am able to verify and select BB Impairment Predictor Tool Category on BB Financial Lab$")
    public void iAmAbleToVerifyAndSelectBBImpairmentPredictorToolCategoryOnBBFinancialLab() {
        businessBankingFinancialLab.getBBImpairmentPredictorTool();
    }

    @Then("^Verify all available operation on BB Impairment Predictor Tool Article Page$")
    public void verifyAllAvailableOperationOnBBImpairmentPredictorToolArticlePage() {
        businessBankingFinancialLab.verifyBBImpairmentPredictorTool();
    }

    @And("^I am able to verify and select Whole View TV Category on BB Financial Lab$")
    public void iAmAbleToVerifyAndSelectWholeViewTVCategoryOnBBFinancialLab() {
        businessBankingFinancialLab.getWholeViewTV();
    }

    @Then("^Verify all available operation on Whole View TV Article Page$")
    public void verifyAllAvailableOperationOnWholeViewTVArticlePage() {
        businessBankingFinancialLab.verifyWholeViewTV();
    }
}
