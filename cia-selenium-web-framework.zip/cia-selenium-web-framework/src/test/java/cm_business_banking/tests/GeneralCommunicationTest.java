package cm_business_banking.tests;

import cm_business_banking.objects.Communication;
import cm_business_banking.objects.GeneralCommunication;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class GeneralCommunicationTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmemqa/BB/Home/Navigation?CategoryId=1237");
    Communication communication = new Communication(launchDriver.getDriver());
    GeneralCommunication generalCommunication = new GeneralCommunication(launchDriver.getDriver());


    @And("^I am able to select and verify General Category on Communication Category$")
    public void iAmAbleToSelectAndVerifyGeneralCategoryOnCommunicationCategory() {
        communication.getGeneral();
    }

    @And("^I am able to verify and select BB Positioning Category on Credit System$")
    public void iAmAbleToVerifyAndSelectBBPositioningCategoryOnCreditSystem() {
        generalCommunication.getBBPositioning();
    }

    @Then("^Verify all available operation BB Positioning Article Page$")
    public void verifyAllAvailableOperationBBPositioningArticlePage() {
        generalCommunication.verifyBBPositioning();
    }

    @And("^I am able to verify and select Debtor Management Campaign Radio Advert Category on General Category$")
    public void iAmAbleToVerifyAndSelectDebtorManagementCampaignRadioAdvertCategoryOnGeneralCategory() {
        generalCommunication.getDebtorManagementCampaignRadioAdvert();
    }

    @Then("^Verify all available operation on Debtor Management Campaign Radio Advert Article Page$")
    public void verifyAllAvailableOperationOnDebtorManagementCampaignRadioAdvertArticlePage() {
        generalCommunication.verifyDebtorManagementCampaignRadioAdvert();
    }
}
