package cm_business_banking.tests;

import cm_business_banking.objects.Credit;
import cm_business_banking.objects.StandardGuidelines;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class StandardGuidelinesTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmemqa/BB/Home/Navigation?CategoryId=1153");
    Credit credit = new Credit(launchDriver.getDriver());
    StandardGuidelines standardGuidelines = new StandardGuidelines(launchDriver.getDriver());


    @And("^I am able to select and verify Standard Guidelines Category on Credit Category$")
    public void iAmAbleToSelectAndVerifyStandardGuidelinesCategoryOnCreditCategory() {
        credit.getStandardsGuidelines();
    }

    @And("^I am able to verify and select Agriculture Finance Guideline Category on Standard Guidelines$")
    public void iAmAbleToVerifyAndSelectAgricultureFinanceGuidelineCategoryOnStandardGuidelines() {
        standardGuidelines.getAgricultureFinanceGuideline();
    }

    @Then("^Verify all available operation on Agriculture Finance Guideline Article Page$")
    public void verifyAllAvailableOperationOnAgricultureFinanceGuidelineArticlePage() {
        standardGuidelines.verifyAgricultureFinanceGuideline();
    }

    @And("^I am able to verify and select Auto Review Credit Standard Category on Standard Guidelines$")
    public void iAmAbleToVerifyAndSelectAutoReviewCreditStandardCategoryOnStandardGuidelines() {
        standardGuidelines.getAutoReviewCreditStandard();
    }

    @Then("^Verify all available operation on Auto Review Credit Standard Article Page$")
    public void verifyAllAvailableOperationOnAutoReviewCreditStandardArticlePage() {
        standardGuidelines.verifyAutoReviewCreditStandard();
    }

    @And("^I am able to verify and select Capital Movable Assets Suppliers Credit Standards Category on Standard Guidelines$")
    public void iAmAbleToVerifyAndSelectCapitalMovableAssetsSuppliersCreditStandardsCategoryOnStandardGuidelines() {
        standardGuidelines.getCapitalMovableAssetsSuppliersCreditStandards();
    }

    @Then("^Verify all available operation on Capital Movable Assets Suppliers Credit Standards Article Page$")
    public void verifyAllAvailableOperationOnCapitalMovableAssetsSuppliersCreditStandardsArticlePage() {
        standardGuidelines.verifyCapitalMovableAssetsSuppliersCreditStandards();
    }

    @And("^I am able to verify and select Credit Risk Guideline Category on Standard Guidelines$")
    public void iAmAbleToVerifyAndSelectCreditRiskGuidelineCategoryOnStandardGuidelines() {
        standardGuidelines.getCreditRiskGuideline();
    }

    @Then("^Verify all available operation on Credit Risk Guideline Article Page$")
    public void verifyAllAvailableOperationOnCreditRiskGuidelineArticlePage() {
        standardGuidelines.verifyCreditRiskGuideline();
    }

    @And("^I am able to verify and select Debtor Management Credit Standards Category on Standard Guidelines$")
    public void iAmAbleToVerifyAndSelectDebtorManagementCreditStandardsCategoryOnStandardGuidelines() {
        standardGuidelines.getDebtorManagementCreditStandards();
    }

    @Then("^Verify all available operation on Debtor Management Credit Standards Article Page$")
    public void verifyAllAvailableOperationOnDebtorManagementCreditStandardsArticlePage() {
        standardGuidelines.verifyDebtorManagementCreditStandards();
    }

    @And("^I am able to verify and select Electronic Banking Guidelines Category on Standard Guidelines$")
    public void iAmAbleToVerifyAndSelectElectronicBankingGuidelinesCategoryOnStandardGuidelines() {
        standardGuidelines.getElectronicBankingGuidelines();
    }

    @Then("^Verify all available operation on Electronic Banking Guidelines Article Page$")
    public void verifyAllAvailableOperationOnElectronicBankingGuidelinesArticlePage() {
        standardGuidelines.verifyElectronicBankingGuidelines();
    }

    @And("^I am able to verify and select Emerald Credit Standards Category on Standard Guidelines$")
    public void iAmAbleToVerifyAndSelectEmeraldCreditStandardsCategoryOnStandardGuidelines() {
        standardGuidelines.getEmeraldCreditStandards();
    }

    @Then("^Verify all available operation on Emerald Credit Standards Article Page$")
    public void verifyAllAvailableOperationOnEmeraldCreditStandardsArticlePage() {
        standardGuidelines.verifyEmeraldCreditStandards();
    }

    @And("^I am able to verify and select Immovable Property Valuations Standards Category on Standard Guidelines$")
    public void iAmAbleToVerifyAndSelectImmovablePropertyValuationsStandardsCategoryOnStandardGuidelines() {
        standardGuidelines.getImmovablePropertyValuationsStandards();
    }

    @Then("^Verify all available operation on Immovable Property Valuations Standards Article Page$")
    public void verifyAllAvailableOperationOnImmovablePropertyValuationsStandardsArticlePage() {
        standardGuidelines.verifyImmovablePropertyValuationsStandards();
    }

    @And("^I am able to verify and select National Credit Act Credit Standards Category on Standard Guidelines$")
    public void iAmAbleToVerifyAndSelectNationalCreditActCreditStandardsCategoryOnStandardGuidelines() {
        standardGuidelines.getNationalCreditActCreditStandards();
    }

    @Then("^Verify all available operation on National Credit Act Credit Standards Article Page$")
    public void verifyAllAvailableOperationOnNationalCreditActCreditStandardsArticlePage() {
        standardGuidelines.verifyNationalCreditActCreditStandards();
    }

    @And("^I am able to verify and select Perfection Of Notarial Bond Procedural Category on Standard Guidelines$")
    public void iAmAbleToVerifyAndSelectPerfectionOfNotarialBondProceduralCategoryOnStandardGuidelines() {
        standardGuidelines.getPerfectionOfNotarialBondProceduralGuideline();
    }

    @Then("^Verify all available operation on Perfection Of Notarial Bond Procedural Article Page$")
    public void verifyAllAvailableOperationOnPerfectionOfNotarialBondProceduralArticlePage() {
        standardGuidelines.verifyPerfectionOfNotarialBondProceduralGuideline();
    }

    @And("^I am able to verify and select Public Sector Guidelines Procedures Category on Standard Guidelines$")
    public void iAmAbleToVerifyAndSelectPublicSectorGuidelinesProceduresCategoryOnStandardGuidelines() {
        standardGuidelines.getPublicSectorGuidelinesProcedures();
    }

    @Then("^Verify all available operation on Public Sector Guidelines Procedures Article Page$")
    public void verifyAllAvailableOperationOnPublicSectorGuidelinesProceduresArticlePage() {
        standardGuidelines.verifyPublicSectorGuidelinesProcedures();
    }

    @And("^I am able to verify and select Rental Discounting Credit Standards Category on Standard Guidelines$")
    public void iAmAbleToVerifyAndSelectRentalDiscountingCreditStandardsCategoryOnStandardGuidelines() {
        standardGuidelines.getRentalDiscountingCreditStandards();
    }

    @Then("^Verify all available operation on Rental Discounting Credit Standards Article Page$")
    public void verifyAllAvailableOperationOnRentalDiscountingCreditStandardsArticlePage() {
        standardGuidelines.verifyRentalDiscountingCreditStandards();
    }

    @And("^I am able to verify and select Social And Environmental Risk Credit Standards Category on Standard Guidelines$")
    public void iAmAbleToVerifyAndSelectSocialAndEnvironmentalRiskCreditStandardsCategoryOnStandardGuidelines() {
        standardGuidelines.getSocialAndEnvironmentalRiskCreditStandards();
    }

    @Then("^Verify all available operation on Social And Environmental Risk Credit Standards Article Page$")
    public void verifyAllAvailableOperationOnSocialAndEnvironmentalRiskCreditStandardsArticlePage() {
        standardGuidelines.verifySocialAndEnvironmentalRiskCreditStandards();
    }

    @And("^I am able to verify and select Specialised Finance Credit Standards Category on Standard Guidelines$")
    public void iAmAbleToVerifyAndSelectSpecialisedFinanceCreditStandardsCategoryOnStandardGuidelines() {
        standardGuidelines.getSpecialisedFinanceCreditStandards();
    }

    @Then("^Verify all available operation on Specialised Finance Credit Standards Article Page$")
    public void verifyAllAvailableOperationOnSpecialisedFinanceCreditStandardsArticlePage() {
        standardGuidelines.verifySpecialisedFinanceCreditStandards();
    }

    @And("^I am able to verify and select Stock Finance Credit Standard Category on Standard Guidelines$")
    public void iAmAbleToVerifyAndSelectStockFinanceCreditStandardCategoryOnStandardGuidelines() {
        standardGuidelines.getStockFinanceCreditStandard();
    }

    @Then("^Verify all available operation on Stock Finance Credit Standard Article Page$")
    public void verifyAllAvailableOperationOnStockFinanceCreditStandardArticlePage() {
        standardGuidelines.verifyStockFinanceCreditStandard();
    }

    @And("^I am able to verify and select Timber Finance Credit Standard Category on Standard Guidelines$")
    public void iAmAbleToVerifyAndSelectTimberFinanceCreditStandardCategoryOnStandardGuidelines() {
        standardGuidelines.getTimberFinanceCreditStandard();
    }

    @Then("^Verify all available operation on Timber Finance Credit Standard Article Page$")
    public void verifyAllAvailableOperationOnTimberFinanceCreditStandardArticlePage() {
        standardGuidelines.verifyTimberFinanceCreditStandard();
    }

    @And("^I am able to verify and select Trade Finance Credit Standard Category on Standard Guidelines$")
    public void iAmAbleToVerifyAndSelectTradeFinanceCreditStandardCategoryOnStandardGuidelines() {
        standardGuidelines.getTradeFinanceCreditStandard();
    }

    @Then("^Verify all available operation on Trade Finance Credit Standard Article Page$")
    public void verifyAllAvailableOperationOnTradeFinanceCreditStandardArticlePage() {
        standardGuidelines.verifyTradeFinanceCreditStandard();
    }
}
