package cm_business_banking.tests;

import cm_business_banking.objects.CoreBankingSolution;
import cm_business_banking.objects.HomeCategory;
import cm_business_banking.objects.MoreCategories;
import cm_business_banking.objects.TransactionalCAAndEB;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TransactionalCAAndEBTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmemqa/BB/Home");
    HomeCategory homeCategory = new HomeCategory(launchDriver.getDriver());
    CoreBankingSolution coreBankingSolution = new CoreBankingSolution(launchDriver.getDriver());
    TransactionalCAAndEB transactionalCAAndEB = new TransactionalCAAndEB(launchDriver.getDriver());

    @When("^I am able to verify and select Core Banking Solutions Category$")
    public void iAmAbleToVerifyAndSelectCoreBankingSolutionsCategory() {
        homeCategory.getCoreBankingSolutions();
    }

    @And("^I am able to verify and select Transactional CA And EB Category on Core Banking Solutions Category$")
    public void iAmAbleToVerifyAndSelectTransactionalCAAndEBCategoryOnCoreBankingSolutionsCategory() {
        coreBankingSolution.getTransactionalCAAndEB();
    }

    @Then("^I am able to verify Current Account Category on Transactional CA And EB Category$")
    public void iAmAbleToVerifyCurrentAccountCategoryOnTransactionalCAAndEBCategory() {
        transactionalCAAndEB.verifyCurrentAccount();
    }

    @Then("^I am able to verify AVS Category on Transactional CA And EB Category$")
    public void iAmAbleToVerifyAVSCategoryOnTransactionalCAAndEBCategory() {
        transactionalCAAndEB.verifyAVS();
    }

    @Then("^I am able to verify e-Statements Category on Transactional CA And EB Category$")
    public void iAmAbleToVerifyEStatementsCategoryOnTransactionalCAAndEBCategory() {
        transactionalCAAndEB.verifyEStatements();
    }

    @Then("^I am able to verify Notifcations Category on Transactional CA And EB Category$")
    public void iAmAbleToVerifyNotifcationsCategoryOnTransactionalCAAndEBCategory() {
        transactionalCAAndEB.verifyNotifications();
    }

    @Then("^I am able to verify NBB Category on Transactional CA And EB Category$")
    public void iAmAbleToVerifyNBBCategoryOnTransactionalCAAndEBCategory() {
        transactionalCAAndEB.verifyNBB();
    }
}
