package cm_business_banking.tests;

import cm_business_banking.objects.Franchising;
import cm_business_banking.objects.PodcastsAndTestimonialVideos;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class PodcastsAndTestimonialVideosTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmempr/BB/Home/Navigation?CategoryId=1336");
    Franchising franchising = new Franchising(launchDriver.getDriver());
    PodcastsAndTestimonialVideos podcastsAndTestimonialVideos = new PodcastsAndTestimonialVideos(launchDriver.getDriver());

    @And("^I am able to verify and select Podcasts And Testimonial Videos Category from Franchising Category$")
    public void iAmAbleToVerifyAndSelectPodcastsAndTestimonialVideosCategoryFromFranchisingCategory() {
        franchising.getPodcastsAndTestimonialVideos();
    }

    @And("^I am able to verify and select How Nedbanks helps new businesses Category on Podcasts And Testimonial Videos Category$")
    public void iAmAbleToVerifyAndSelectHowNedbanksHelpsNewBusinessesCategoryOnPodcastsAndTestimonialVideosCategory() {
        podcastsAndTestimonialVideos.getHowNedbanksHelpsNewBusinesses();
    }

    @Then("^Verify all available operation on How Nedbanks helps new businesses Article Page$")
    public void verifyAllAvailableOperationOnHowNedbanksHelpsNewBusinessesArticlePage() {
        podcastsAndTestimonialVideos.verifyHowNedbanksHelpsNewBusinesses();
    }

    @And("^I am able to verify and select HThe Consumer Protection Act and the impact thereof Category on Podcasts And Testimonial Videos Category$")
    public void iAmAbleToVerifyAndSelectHTheConsumerProtectionActAndTheImpactThereofCategoryOnPodcastsAndTestimonialVideosCategory() {
        podcastsAndTestimonialVideos.getConsumerProtectionActAndTheImpactThereof();
    }

    @Then("^Verify all available operation on The Consumer Protection Act and the impact thereof Article Page$")
    public void verifyAllAvailableOperationOnTheConsumerProtectionActAndTheImpactThereofArticlePage() {
        podcastsAndTestimonialVideos.verifyConsumerProtectionActAndTheImpactThereof();
    }

    @And("^I am able to verify and select Lucia Nonkwelo - BP franchisee Category on Podcasts And Testimonial Videos Category$")
    public void iAmAbleToVerifyAndSelectLuciaNonkweloBPFranchiseeCategoryOnPodcastsAndTestimonialVideosCategory() {
        podcastsAndTestimonialVideos.getLuciaNonkweloBPFranchisee();
    }

    @Then("^Verify all available operation on Lucia Nonkwelo - BP franchisee Article Page$")
    public void verifyAllAvailableOperationOnLuciaNonkweloBPFranchiseeArticlePage() {
        podcastsAndTestimonialVideos.verifyLuciaNonkweloBPFranchisee();
    }

    @And("^I am able to verify and select Nedbank Franchising - Krispy Kreme Category on Podcasts And Testimonial Videos Category$")
    public void iAmAbleToVerifyAndSelectNedbankFranchisingKrispyKremeCategoryOnPodcastsAndTestimonialVideosCategory() {
        podcastsAndTestimonialVideos.getNedbankFranchisingKrispyKreme();
    }

    @Then("^Verify all available operation on Nedbank Franchising - Krispy Kreme Article Page$")
    public void verifyAllAvailableOperationOnNedbankFranchisingKrispyKremeArticlePage() {
        podcastsAndTestimonialVideos.verifyNedbankFranchisingKrispyKreme();
    }

    @And("^I am able to verify and select Nedbank Franchising - Sales Tool Category on Podcasts And Testimonial Videos Category$")
    public void iAmAbleToVerifyAndSelectNedbankFranchisingSalesToolCategoryOnPodcastsAndTestimonialVideosCategory() {
        podcastsAndTestimonialVideos.getNedbankFranchisingSalesTool();
    }

    @Then("^Verify all available operation on Nedbank Franchising - Sales Tool Article Page$")
    public void verifyAllAvailableOperationOnNedbankFranchisingSalesToolArticlePage() {
        podcastsAndTestimonialVideos.verifyNedbankFranchisingSalesTool();
    }

    @And("^I am able to verify and select Franchising Video - Dalene Rowe Category on Podcasts And Testimonial Videos Category$")
    public void iAmAbleToVerifyAndSelectFranchisingVideoDaleneRoweCategoryOnPodcastsAndTestimonialVideosCategory() {
        podcastsAndTestimonialVideos.getTigerFranchisingVideoDaleneRowe();
    }

    @Then("^Verify all available operation on Franchising Video - Dalene Rowe Article Page$")
    public void verifyAllAvailableOperationOnFranchisingVideoDaleneRoweArticlePage() {
        podcastsAndTestimonialVideos.verifyFranchisingVideoDaleneRowe();
    }

    @And("^I am able to verify and select Franchising Video - Mark Rose Category on Podcasts And Testimonial Videos Category$")
    public void iAmAbleToVerifyAndSelectFranchisingVideoMarkRoseCategoryOnPodcastsAndTestimonialVideosCategory() {
        podcastsAndTestimonialVideos.getFranchisingVideoMarkRose();
    }

    @Then("^Verify all available operation on Franchising Video - Mark Rose Article Page$")
    public void verifyAllAvailableOperationOnFranchisingVideoMarkRoseArticlePage() {
        podcastsAndTestimonialVideos.verifyFranchisingVideoMarkRose();
    }

    @And("^I am able to verify and select Franchising Video - Naresh Babu Category on Podcasts And Testimonial Videos Category$")
    public void iAmAbleToVerifyAndSelectFranchisingVideoNareshBabuCategoryOnPodcastsAndTestimonialVideosCategory() {
        podcastsAndTestimonialVideos.getNedbankFranchisingNareshBabu();
    }

    @Then("^Verify all available operation on Franchising Video - Naresh Babu Article Page$")
    public void verifyAllAvailableOperationOnFranchisingVideoNareshBabuArticlePage() {
        podcastsAndTestimonialVideos.verifyNedbankFranchisingNareshBabu();
    }

    @And("^I am able to verify and select Nedbank Franchising - Sacha Du Plessis Category on Podcasts And Testimonial Videos Category$")
    public void iAmAbleToVerifyAndSelectNedbankFranchisingSachaDuPlessisCategoryOnPodcastsAndTestimonialVideosCategory() {
        podcastsAndTestimonialVideos.getNedbankFranchisingSachaDuPlessis();
    }

    @Then("^Verify all available operation on Nedbank Franchising - Sacha Du Plessis Article Page$")
    public void verifyAllAvailableOperationOnNedbankFranchisingSachaDuPlessisArticlePage() {
        podcastsAndTestimonialVideos.verifyNedbankFranchisingSachaDuPlessis();
    }

    @And("^I am able to verify and select Nedbank Franchising - Engen Category on Podcasts And Testimonial Videos Category$")
    public void iAmAbleToVerifyAndSelectNedbankFranchisingEngenCategoryOnPodcastsAndTestimonialVideosCategory() {
        podcastsAndTestimonialVideos.getNedbankFranchisingEngen();
    }

    @Then("^Verify all available operation on Nedbank Franchising - Engen Article Page$")
    public void verifyAllAvailableOperationOnNedbankFranchisingEngenArticlePage() {
        podcastsAndTestimonialVideos.verifyNedbankFranchisingEngen();
    }

    @And("^I am able to verify and select Why entrepreneurs should attend Nedbank Seminars Category on Podcasts And Testimonial Videos Category$")
    public void iAmAbleToVerifyAndSelectWhyEntrepreneursShouldAttendNedbankSeminarsCategoryOnPodcastsAndTestimonialVideosCategory() {
        podcastsAndTestimonialVideos.getEntrepreneursShouldAttendNedbankSeminars();
    }

    @Then("^Verify all available operation on Why entrepreneurs should attend Nedbank Seminars Article Page$")
    public void verifyAllAvailableOperationOnWhyEntrepreneursShouldAttendNedbankSeminarsArticlePage() {
        podcastsAndTestimonialVideos.verifyEntrepreneursShouldAttendNedbankSeminars();
    }
}
