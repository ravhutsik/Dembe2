package cm_business_banking.tests;

import cm_business_banking.objects.Marketing;
import cm_business_banking.objects.PublicSector;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class MarketingTest {

    LaunchDriver launchDriver = new LaunchDriver("http://biscorpmemqa/BB/Home/Navigation?CategoryId=1251");
    PublicSector publicSector = new PublicSector(launchDriver.getDriver());
    Marketing marketing = new Marketing(launchDriver.getDriver());

    @And("^I am able to select and verify Marketing Category on Public Sector Category$")
    public void iAmAbleToSelectAndVerifyMarketingCategoryOnPublicSectorCategory() {
        publicSector.getMarketing();
    }

    @And("^I am able to verify and select Public Sector Brochure Category on Legislation Category$")
    public void iAmAbleToVerifyAndSelectPublicSectorBrochureCategoryOnLegislationCategory() {
        marketing.getPublicSectorBrochure();
    }

    @Then("^Verify all available operation on Public Sector Brochure Article Page$")
    public void verifyAllAvailableOperationOnPublicSectorBrochureArticlePage() {
        marketing.verifyPublicSectorBrochure();
    }

    @And("^I am able to verify and select FX Derivatives by Nedbank Category on Legislation Category$")
    public void iAmAbleToVerifyAndSelectFXDerivativesByNedbankCategoryOnLegislationCategory() {
        marketing.getFXDerivativesByNedbank();
    }

    @Then("^Verify all available operation on FX Derivatives by Nedbank Article Page$")
    public void verifyAllAvailableOperationOnFXDerivativesByNedbankArticlePage() {
        marketing.verifyFXDerivativesByNedbank();
    }
}
