package cm_business_banking.tests;

import cm_business_banking.objects.ClientExperience;
import cm_business_banking.objects.ClientStories;
import cm_business_banking.objects.MoreCategories;
import cm_business_banking.objects.StrategyAndApproach;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class ClientStoriesTest {

    LaunchDriver loadBusinessBankingURL=new LaunchDriver("http://biscorpmempr/BB/Home/Navigation?CategoryId=1161");
    ClientExperience clientExperience = new ClientExperience(loadBusinessBankingURL.getDriver());
    ClientStories clientStories = new ClientStories(loadBusinessBankingURL.getDriver());

    @And("^I am able to verify and select Client Stories Category on Taking Client Experience To The Next Level Category$")
    public void iAmAbleToVerifyAndSelectClientStoriesCategoryOnTakingClientExperienceToTheNextLevelCategory() {
        clientExperience.getClientStories();
    }

    @And("^I am able to verify and select Client Testimonials- Various Category on Client Stories Category$")
    public void iAmAbleToVerifyAndSelectClientTestimonialsVariousCategoryOnClientStoriesCategory() {
        clientStories.getBBPurposeAndClientExperience();
    }

    @Then("^Verify all available operation on Client Testimonials- Various Article Page$")
    public void verifyAllAvailableOperationOnClientTestimonialsVariousArticlePage() {
        clientStories.verifyAPurposeAndClientExperience();
    }

    @And("^I am able to verify and select BB Value Proposition Category on Client Stories Category$")
    public void iAmAbleToVerifyAndSelectBBValuePropositionCategoryOnClientStoriesCategory() {
        clientStories.getBBValueProposition();
    }
}
