package cm_business_banking.tests;

import cm_business_banking.objects.*;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SolutionAndServiceTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmemqa/BB/Home");
    HomeCategory homeCategory = new HomeCategory(launchDriver.getDriver());
    Specialisation specialisation = new Specialisation(launchDriver.getDriver());
    PublicSector publicSector = new PublicSector(launchDriver.getDriver());
    SolutionsAndServices solutionsAndServices = new SolutionsAndServices(launchDriver.getDriver());

    @When("^I am able to verify and select Specialisation Category$")
    public void iAmAbleToVerifyAndSelectSpecialisationCategory() {
        homeCategory.getSpecialisation();
    }

    @And("^I am able view available options under Specialisation Category$")
    public void iAmAbleViewAvailableOptionsUnderSpecialisationCategory() {

    }

    @And("^I am able to select and verify Public Sector Category on Specialisation Category$")
    public void iAmAbleToSelectAndVerifyPublicSectorCategoryOnSpecialisationCategory() {
        specialisation.getPublicSector();
    }

    @And("^I am able to select and verify Solution And Service Category on Public Sector Category$")
    public void iAmAbleToSelectAndVerifySolutionAndServiceCategoryOnPublicSectorCategory() {
        publicSector.getSolutionsAndServices();
    }

    @And("^I am able to verify and select Public Sector Solutions Services Category on Solution And Service Category$")
    public void iAmAbleToVerifyAndSelectPublicSectorSolutionsServicesCategoryOnSolutionAndServiceCategory() {
        solutionsAndServices.getPublicSectorSolutionsServices();
    }

    @Then("^Verify all available operation on Public Sector Solutions Services Article Page$")
    public void verifyAllAvailableOperationOnPublicSectorSolutionsServicesArticlePage() {
        solutionsAndServices.verifyPublicSectorSolutionsServices();
    }
}
