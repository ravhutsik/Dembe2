package cm_business_banking.tests;

import cm_business_banking.objects.BusinessBankingProcesses;
import cm_business_banking.objects.Credit;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class BusinessBankingProcessesTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmemqa/BB/Home/Navigation?CategoryId=1153");
    Credit credit = new Credit(launchDriver.getDriver());
    BusinessBankingProcesses businessBankingProcesses = new BusinessBankingProcesses(launchDriver.getDriver());


    @And("^I am able to select and verify Business Banking Processes Category on Credit Category$")
    public void iAmAbleToSelectAndVerifyBusinessBankingProcessesCategoryOnCreditCategory() {
        credit.getBusinessBankingProcesses();
    }

    @And("^I am able to verify and select BB Processes HyperLink Category on Business Banking Processes Category$")
    public void iAmAbleToVerifyAndSelectBBProcessesHyperLinkCategoryOnBusinessBankingProcessesCategory() {
        businessBankingProcesses.getBBProcessesHyperLink();
    }

    @Then("^Verify all available operation on BB Processes HyperLink Article page$")
    public void verifyAllAvailableOperationOnBBProcessesHyperLinkArticlePage() {
        businessBankingProcesses.verifyBBProcessesHyperLink();
    }

    @And("^I am able to verify and select Credit Report Monthly Category on Business Banking Processes Category$")
    public void iAmAbleToVerifyAndSelectCreditReportMonthlyCategoryOnBusinessBankingProcessesCategory() {
        businessBankingProcesses.getCreditReportMonthly();
    }

    @Then("^Verify all available operation on Credit Report Monthly Article Page$")
    public void verifyAllAvailableOperationOnCreditReportMonthlyArticlePage() {
        businessBankingProcesses.verifyCreditReportMonthly();
    }

    @And("^I am able to verify and select Electronic Security Signing Category on Business Banking Processes Category$")
    public void iAmAbleToVerifyAndSelectElectronicSecuritySigningCategoryOnBusinessBankingProcessesCategory() {
        businessBankingProcesses.getElectronicSecuritySigning();
    }

    @Then("^Verify all available operation on Electronic Security Signing Article Page$")
    public void verifyAllAvailableOperationOnElectronicSecuritySigningArticlePage() {
        businessBankingProcesses.verifyElectronicSecuritySigning();
    }

    @And("^I am able to verify and select Email Notification Category on Business Banking Processes Category$")
    public void iAmAbleToVerifyAndSelectEmailNotificationCategoryOnBusinessBankingProcessesCategory() {
        businessBankingProcesses.getEmailNotification();
    }

    @Then("^Verify all available operation on Email Notification Article Page$")
    public void verifyAllAvailableOperationOnEmailNotificationArticlePage() {
        businessBankingProcesses.verifyEmailNotification();
    }

    @And("^I am able to verify and select Visitation Capture Procedure Category on Business Banking Processes Category$")
    public void iAmAbleToVerifyAndSelectVisitationCaptureProcedureCategoryOnBusinessBankingProcessesCategory() {
        businessBankingProcesses.getVisitationCaptureProcedure();
    }

    @Then("^Verify all available operation on Visitation Capture Procedure Article Page$")
    public void verifyAllAvailableOperationOnVisitationCaptureProcedureArticlePage() {
        businessBankingProcesses.verifyVisitationCaptureProcedure();
    }
}
