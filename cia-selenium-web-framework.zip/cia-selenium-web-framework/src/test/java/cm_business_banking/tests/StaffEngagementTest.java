package cm_business_banking.tests;

import cm_business_banking.objects.AboutBusinessBanking;
import cm_business_banking.objects.BusinessLevel;
import cm_business_banking.objects.MoreCategories;
import cm_business_banking.objects.StaffEngagement;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class StaffEngagementTest {
    LaunchDriver loadBusinessBankingURL=new LaunchDriver("http://biscorpmempr/BB/Home/Navigation?CategoryId=1163");
    BusinessLevel aboutBusinessBanking = new BusinessLevel(loadBusinessBankingURL.getDriver());
    StaffEngagement staffEngagement = new StaffEngagement(loadBusinessBankingURL.getDriver());

    @And("^I am able to select and verify Staff Engagement Category on Take Business to Next Level Category$")
    public void iAmAbleToSelectAndVerifyStaffEngagementCategoryOnTakeBusinessToNextLevelCategory() {
        aboutBusinessBanking.getStaffEngagements();
    }

    @And("^I am able to verify and select Staff Engagements Feb/Mar Category on Staff Engagement Category$")
    public void iAmAbleToVerifyAndSelectStaffEngagementsFebMarCategoryOnStaffEngagementCategory() {
        staffEngagement.getStaffEngagementsFebMar2016();
    }

    @Then("^Verify all available operation on Staff Engagements Feb/Mar Article Page$")
    public void verifyAllAvailableOperationOnStaffEngagementsFebMarArticlePage() {
        staffEngagement.verifyStaffEngagementsFebMar2016();
    }

    @And("^I am able to verify and select BB Staff Roadshows September Category on Staff Engagement Category$")
    public void iAmAbleToVerifyAndSelectBBStaffRoadshowsSeptemberCategoryOnStaffEngagementCategory() {
        staffEngagement.getBBStaffRoadshowsSeptember2015();
    }

    @Then("^Verify all available operation on BB Staff Roadshows September Article Page$")
    public void verifyAllAvailableOperationOnBBStaffRoadshowsSeptemberArticlePage() {
        staffEngagement.verifyBBStaffRoadshowsSeptember2015();
    }

    @And("^I am able to verify and select Bend - High Performance Teams Category on Staff Engagement Category$")
    public void iAmAbleToVerifyAndSelectBendHighPerformanceTeamsCategoryOnStaffEngagementCategory() {
        staffEngagement.verifybendHighPerformanceTeams();
    }

    @And("^I am able to verify and select BB Roadshows August Category on Staff Engagement Category$")
    public void iAmAbleToVerifyAndSelectBBRoadshowsAugustCategoryOnStaffEngagementCategory() {
        staffEngagement.getBBRoadshowsAugust2015();
    }

    @Then("^Verify all available operation on BB Roadshows August Article Page$")
    public void verifyAllAvailableOperationOnBBRoadshowsAugustArticlePage() {
        staffEngagement.verifyBBRoadshowsAugust2015();
    }

    @And("^I am able to verify and select Philip's Staff Conversations Category on Staff Engagement Category$")
    public void iAmAbleToVerifyAndSelectPhilipSStaffConversationsCategoryOnStaffEngagementCategory() {
        staffEngagement.getPhilipStaffConversations();
    }

    @Then("^Verify all available operation on Philip's Staff Conversations Article Page$")
    public void verifyAllAvailableOperationOnPhilipSStaffConversationsArticlePage() {
        staffEngagement.verifyPhilipStaffConversations();

    }

    @And("^I am able to verify and select BB Roadshows August OneFour Category on Staff Engagement Category$")
    public void iAmAbleToVerifyAndSelectBBRoadshowsAugustOneFourCategoryOnStaffEngagementCategory() {
        staffEngagement.getBBRoadshowsAugust2014();
    }

    @Then("^Verify all available operation on BB Roadshows August OneFour Article Page$")
    public void verifyAllAvailableOperationOnBBRoadshowsAugustOneFourArticlePage() {
        staffEngagement.verifyBBRoadshowsAugust2014();
    }
    @And("^I am able to verify and select BB Roadshows August OneThree Category on Staff Engagement Category$")
    public void iAmAbleToVerifyAndSelectBBRoadshowsAugustOneThreeCategoryOnStaffEngagementCategory() {
        staffEngagement.getBBRoadshowsAugust2013();
    }

    @Then("^Verify all available operation on BB Roadshows August OneThree Article Page$")
    public void verifyAllAvailableOperationOnBBRoadshowsAugustOneThreeArticlePage() {
        staffEngagement.verifyBBRoadshowsAugust2013();
    }

    @And("^I am able to verify and select Ciko RBB Roadshow Category on Staff Engagement Category$")
    public void iAmAbleToVerifyAndSelectCikoRBBRoadshowCategoryOnStaffEngagementCategory() {
        staffEngagement.getCikoRBBRoadshow();
    }

    @Then("^Verify all available operation on Ciko RBB Roadshow Article Page$")
    public void verifyAllAvailableOperationOnCikoRBBRoadshowArticlePage() {
        staffEngagement.verifyCikoRBBRoadshow();
    }

    @And("^I am able to verify and select Sandile's Roadshows August (\\d+) Category on Staff Engagement Category$")
    public void iAmAbleToVerifyAndSelectSandileSRoadshowsAugustCategoryOnStaffEngagementCategory(int arg0) {
        staffEngagement.getSandileRoadshowsAugust2016();
    }

    @Then("^Verify all available operation on Sandile's Roadshows August (\\d+) Article Page$")
    public void verifyAllAvailableOperationOnSandileSRoadshowsAugustArticlePage() {
        staffEngagement.verifySandileRoadshowsAugust2016();
    }

    @And("^I am able to verify and select Staff Engagement sessions Category on Staff Engagement Category$")
    public void iAmAbleToVerifyAndSelectStaffEngagementSessionsCategoryOnStaffEngagementCategory() {
        staffEngagement.getStaffEngagementSessions();
    }

    @Then("^Verify all available operation on Staff Engagement sessions Article Page$")
    public void verifyAllAvailableOperationOnStaffEngagementSessionsArticlePage() {
        staffEngagement.verifyStaffEngagementSessions();
    }
}
