package cm_business_banking.tests;

import cm_business_banking.objects.CoreBankingSolution;
import cm_business_banking.objects.Invest;
import cm_business_banking.objects.Processes;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class ProcessesTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmempr/BB/Home/Navigation?CategoryId=1160");
    CoreBankingSolution coreBankingSolution = new CoreBankingSolution(launchDriver.getDriver());
    Processes processes = new Processes(launchDriver.getDriver());

    @And("^I am able to verify and select Processes Category on Core Banking Solutions Category$")
    public void iAmAbleToVerifyAndSelectProcessesCategoryOnCoreBankingSolutionsCategory() {
        coreBankingSolution.getProcesses();
    }

    @Then("^I am able to verify and View Index - Core Banking Processes Category on Processes Category$")
    public void iAmAbleToVerifyAndViewIndexCoreBankingProcessesCategoryOnProcessesCategory() {
        processes.getIndexCoreBankingProcesses();
    }
}
