package cm_business_banking.tests;

import cm_business_banking.objects.*;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cm_business_banking.objects.DocumentLibrary;
public class CreditReportTemplateTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmemqa/BB/Home");
    HomeCategory homeCategory = new HomeCategory(launchDriver.getDriver());
    Credit credit = new Credit(launchDriver.getDriver());
    DocumentLibrary documentLibrary = new DocumentLibrary(launchDriver.getDriver());
    CreditReportTemplate creditReportTemplate = new CreditReportTemplate(launchDriver.getDriver());

    @Given("^I am at Business Banking home page$")
    public void openHomePage() {

        try{
            launchDriver.getDriver();

        }catch (Exception e){
                       e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @When("^I am able to verify and select Credit Category$")
    public void iAmAbleToVerifyAndSelectCreditCategory() {
        try{
            homeCategory.getCredit();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @And("^I am able view available options under Credit Category$")
    public void iAmAbleViewAvailableOptionsUnderCreditCategory() {
        try{
//            credit.getDOCUMENT_LIBRARY();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }



    @And("^I am able to select and verify Document Library Category on Credit Category$")
    public void iAmAbleToSelectAndVerifyDocumentLibraryCategoryOnCreditCategory() {
        try{
            credit.getDocumentLibrary();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @And("^I am able to select and verify Credit Report Template Category on Document Library$")
    public void iAmAbleToSelectAndVerifyCreditReportTemplateCategoryOnDocumentLibrary() {
        try{

            documentLibrary.getCreditReportTemplates();

        }catch (Exception e){
                       e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @And("^I am able to verify and select RBB NEW NEDBANK PRESENTATION Category on Credit Report Template Category$")
    public void iAmAbleToVerifyAndSelectRBBNEWNEDBANKPRESENTATIONCategoryOnCreditReportTemplateCategory() {
        try{
            creditReportTemplate.getRBB_NEW_NEDBANK_PRESENTATION();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @Then("^Verify all available operation on RBB NEW NEDBANK PRESENTATION Page$")
    public void verifyAllAvailableOperationOnRBBNEWNEDBANKPRESENTATIONPage() {
        try{
            creditReportTemplate.verifyRBBNewNedbankPresentationPage();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @And("^I am able to verify and select Wholeview Digital banners – product Category on Credit Report Template Category$")
    public void iAmAbleToVerifyAndSelectWholeviewDigitalBannersProductCategoryOnCreditReportTemplateCategory() {
        try{
            creditReportTemplate.getWholeView_Digital_Banners_Product();

        }catch (Exception e){
                       e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @Then("^Verify all available operation on Wholeview Digital banners – product Page$")
    public void verifyAllAvailableOperationOnWholeviewDigitalBannersProductPage() {
        try{
            creditReportTemplate.verifyWholeViewDigitalBannerProductPage();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @And("^I am able to verify and select FX Derivatives - by Nedbank Category on Credit Report Template Category$")
    public void iAmAbleToVerifyAndSelectFXDerivativesByNedbankCategoryOnCreditReportTemplateCategory() {
        try{
            creditReportTemplate.getFX_Derivatives_Nedbank();

        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @Then("^Verify all available operation on FX Derivatives - by Nedbank Page$")
    public void verifyAllAvailableOperationOnFXDerivativesByNedbankPage() {
        try{
            creditReportTemplate.verifyFXDerivativesNedbankPage();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @And("^I am able to verify and select Whole-view Business Banking Afrikaans editorial Category on Credit Report Template Category$")
    public void iAmAbleToVerifyAndSelectWholeViewBusinessBankingAfrikaansEditorialCategoryOnCreditReportTemplateCategory() {
        try{
            creditReportTemplate.getWhole_View_BB_Afrikaans_Editorial();

        }catch (Exception e){
                       e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @Then("^Verify all available operation on Whole-view Business Banking Afrikaans editorial Page$")
    public void verifyAllAvailableOperationOnWholeViewBusinessBankingAfrikaansEditorialPage() {
        try{

            creditReportTemplate.verifyWholeViewEditorialPage();

        }catch (Exception e){
                       e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @And("^I am able to verify and select BB INTERNAL REPORTING PRESENTATION Category on Credit Report Template Category$")
    public void iAmAbleToVerifyAndSelectBBINTERNALREPORTINGPRESENTATIONCategoryOnCreditReportTemplateCategory() {
        try{
            creditReportTemplate.getBB_INTERNAL_REPORTING_PRESENTATION();

        }catch (Exception e){
                       e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @Then("^Verify all available operation on BB INTERNAL REPORTING PRESENTATION Page$")
    public void verifyAllAvailableOperationOnBBINTERNALREPORTINGPRESENTATIONPage() {
        try{
            creditReportTemplate.verifyInternalReportingPage();
        }catch (Exception e){
                       e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }
}
