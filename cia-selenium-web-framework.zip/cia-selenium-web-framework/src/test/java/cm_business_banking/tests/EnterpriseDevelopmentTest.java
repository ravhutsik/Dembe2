package cm_business_banking.tests;

import cm_business_banking.objects.EnterpriseDevelopment;
import cm_business_banking.objects.Specialisation;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class EnterpriseDevelopmentTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmemqa/BB/Home/Navigation?CategoryId=1251");

    Specialisation specialisation = new Specialisation(launchDriver.getDriver());
    EnterpriseDevelopment enterpriseDevelopment = new EnterpriseDevelopment(launchDriver.getDriver());


    @And("^I am able to select and verify Enterprise Development Category on Public Sector Category$")
    public void iAmAbleToSelectAndVerifyEnterpriseDevelopmentCategoryOnPublicSectorCategory() {
        specialisation.getEnterpriseDevelopment();
    }

    @And("^I am able to verify and select ED Proposition Category on Enterprise Development Category$")
    public void iAmAbleToVerifyAndSelectEDPropositionCategoryOnEnterpriseDevelopmentCategory() {
        enterpriseDevelopment.getEDProposition();
    }

    @Then("^Verify all available operation on ED Proposition Article Page$")
    public void verifyAllAvailableOperationOnEDPropositionArticlePage() {
        enterpriseDevelopment.verifyEDProposition();
    }
}
