package cm_business_banking.tests;

import cm_business_banking.objects.AgriKeyContact;
import cm_business_banking.objects.Agriculture;
import cm_business_banking.objects.Specialisation;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class AgriKeyContactTest {


    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmempr/BB/Home/Navigation?CategoryId=1248");
    Specialisation specialisation = new Specialisation(launchDriver.getDriver());
    Agriculture agriculture = new Agriculture(launchDriver.getDriver());
    AgriKeyContact agriKeyContact = new AgriKeyContact(launchDriver.getDriver());


    @And("^I am able to select and verify Agriculture Category on Specialisation Category$")
    public void iAmAbleToSelectAndVerifyAgricultureCategoryOnSpecialisationCategory() {
        specialisation.getAgriculture();
    }

    @And("^I am able to select and verify Key Contact Category on Agriculture Category$")
    public void iAmAbleToSelectAndVerifyKeyContactCategoryOnAgricultureCategory() {
        agriculture.getKeyContacts();
    }

    @And("^I am able to verify and select Agriculture Team Category on Key Contact Category$")
    public void iAmAbleToVerifyAndSelectAgricultureTeamCategoryOnKeyContactCategory() {
        agriKeyContact.getAgricultureTeam();
    }
    @Then("^Verify all available operation on Agriculture Team Article Page$")
    public void verifyAllAvailableOperationOnAgricultureTeamArticlePage() {
        agriKeyContact.verifyAgricultureTeam();

    }
}
