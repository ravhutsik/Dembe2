package cm_business_banking.tests;

import cm_business_banking.objects.AgriSustainability;
import cm_business_banking.objects.Agriculture;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class AgriSustainabilityTest {
    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmempr/BB/Home/Navigation?CategoryId=1346");
    Agriculture agriculture = new Agriculture(launchDriver.getDriver());
    AgriSustainability agriSustainability = new AgriSustainability(launchDriver.getDriver());



    @And("^I am able to select and verify Agriculture Sustainability Category on Agriculture Category$")
    public void iAmAbleToSelectAndVerifyAgricultureSustainabilityCategoryOnAgricultureCategory() {
        agriculture.getSustainability();
    }

    @And("^I am able to verify and select Shade-netting Category on Agriculture Sustainability Category$")
    public void iAmAbleToVerifyAndSelectShadeNettingCategoryOnAgricultureSustainabilityCategory() {
        agriSustainability.getShadeNetting();
    }

    @Then("^Verify all available operation on Shade-netting Article Page$")
    public void verifyAllAvailableOperationOnShadeNettingArticlePage() {
        agriSustainability.verifyShadeNetting();
    }
}
