//package cm_business_banking.tests;
//
//import cm_business_banking.objects.BusinessBankingObjects;
//import cm_business_banking.objects.CategoryObject;
//import cm_utils.DriverFactory;
//import cm_utils.BusinessBankingHelper;
//import cucumber.api.java.en.And;
//import cucumber.api.java.en.Given;
//import cucumber.api.java.en.When;
//import cucumber.api.java.en.Then;
//
//public class Mandates {
//
//    private String businessBankingURL = "http://biscorpmemqa/BB/Home";
//    BusinessBankingObjects bankingObjects = new BusinessBankingObjects(DriverFactory.getDriver(businessBankingURL));
//    BusinessBankingHelper businessBankingHelper = new BusinessBankingHelper(DriverFactory.getDriver(businessBankingURL));
//    CategoryObject categoryObject = new CategoryObject(DriverFactory.getDriver(businessBankingURL));
//
//    @Given("^I am at Business Banking home page$")
//    public void openHomePage() {
//
//        try{
//            DriverFactory.getDriver(businessBankingURL);
//            businessBankingHelper.verifyPage("HOME", bankingObjects.homeText);
//
//        }catch (Exception e){
//            e.printStackTrace();
//        }
//
////        homePage.closePage();
//    }
//    @When("^I am able to select and view Enterprisewide Risk, Compliance and Governance$")
//    public void isEnterPriseWideRiskAndComplianceClickable(){
//
//        try{
//            businessBankingHelper.clickElement(bankingObjects.categoriesDiv);
//            businessBankingHelper.takeSnapShot("EnterPriseWideRiskAndCompliance");
//        }catch (Exception e){e.printStackTrace();}
//    }
//    @And("^I am able to select and view options under Enterprise Risk Management$")
//    public void isEnterpriseRiskManagementClickable() throws Exception {
//
//        businessBankingHelper.verifyPage("Enterprisewide Risk Management", bankingObjects.erm);
//        businessBankingHelper.verifyPage("Archive (Old Categories)", bankingObjects.oldCategory);
//        businessBankingHelper.verifyPage("Cluster Risk Support Services", bankingObjects.clusterRiskSupport);
//        businessBankingHelper.verifyPage("Compliance and Governance", bankingObjects.compliance);
//        businessBankingHelper.clickElement(bankingObjects.erm);
//        businessBankingHelper.takeSnapShot("enterpriseWideRiskManagement");
//
//    }
//    @And("^I am able to select and view options under Operational Risk$")
//    public void isOperationalRiskClickable()  {
//        try{
//            businessBankingHelper.takeSnapShot("OperationalRisk");
//            businessBankingHelper.verifyPage("Operational Risk", bankingObjects.riskOperation);
//            businessBankingHelper.clickElement(bankingObjects.riskOperation);
//            businessBankingHelper.takeSnapShot("OperationalRisk");
//        }catch (Exception e){
//            e.printStackTrace();
//        }
//
//
//    }
//    @And("^I am able to select and view options under MANDATES$")
//    public void isMandateOptionClickable(){
//        try{
//            businessBankingHelper.verifyPage("MANDATES", bankingObjects.mandate);
//            businessBankingHelper.clickElement(bankingObjects.mandate);
//            businessBankingHelper.takeSnapShot("mandates");
//        }catch (Exception e){e.printStackTrace();}
//
//    }
//    @And("^I am able to select and view Mandates Management & SODAS option$")
//    public void selectMandatesManagementAndSODAS(){
//        try {
//            businessBankingHelper.verifyPage("Mandates Management & SODAS", bankingObjects.mandateManagement);
//            businessBankingHelper.clickElement(bankingObjects.mandateManagement);
//            businessBankingHelper.takeSnapShot("MandatesManagementAndSODAS");
//
//        }catch (Exception e){
//            e.printStackTrace();
//        }
//    }
//    @And("^I am able to select and view Authority to Act and Sign on behalf of Nedbank option$")
//    public void selectAndViewAuth(){
//
//        try{
//            businessBankingHelper.verifyPage("Authority to Act and Sign on behalf of Nedbank", bankingObjects.authorityToAct);
//            businessBankingHelper.clickElement(bankingObjects.authorityToAct);
//            businessBankingHelper.takeSnapShot("authorityToAct");
//
//        }catch (Exception e){
//            e.printStackTrace();
//        }
//
//    }
//    @Then("^Verify if I can download and view Mandates Management & SODAS documents$")
//    public void verifyAndViewMandatesManagementPage(){
//        try{
//            businessBankingHelper.verifyPage("Mandates Management & SODAS", bankingObjects.mandateManagementLabel);
//            businessBankingHelper.takeSnapShot("MandatesManagementSODASPage");
//
//        }catch (Exception e){
//            e.printStackTrace();
//        }
//
//    }
//
//    @Then("^Verify if I can download and view Authority to Act and Sign documents$")
//    public void verifyAndViewAuthorityToActAndSignPage() {
//
//        try{
//            businessBankingHelper.verifyPage("Authority to Act and Sign on behalf of Nedbank", bankingObjects.authorityToActLabel);
//            businessBankingHelper.takeSnapShot("AuthorityToActAndSignPage");
////            businessBankingHelper.closePage();
//        } catch (Exception e){
//            e.printStackTrace();
//        }
//
//    }
//
//    @And("^I am able to view and select Risk Event Report page$")
//    public void iAmAbleToViewAndSelectRiskEventReportPage() {
//        try{
//            businessBankingHelper.verifyPage("Risk Event Report", bankingObjects.riskEventReportLabel);
//            businessBankingHelper.takeSnapShot("riskEventReport");
//            businessBankingHelper.clickElement(bankingObjects.riskEventReportLabel);
//
//        }catch (Exception e){
//            e.printStackTrace();
//        }
//
//
//    }
//
//    @And("^I am able to view and select Risk Event Escalation Process page$")
//    public void iAmAbleToViewAndSelectRiskEventEscalationProcessPage() {
//        try{
//            businessBankingHelper.verifyPage("Risk Event Escalation Process", bankingObjects.riskEventEscalation);
//            businessBankingHelper.takeSnapShot("riskEventEscalationProcess");
//            businessBankingHelper.clickElement(bankingObjects.riskEventEscalation);
//        }catch (Exception e){
//            e.printStackTrace();
//        }
//
//    }
//
//    @Then("^Verify if I can view and select various option under Risk Event Escalation Process page$")
//    public void verifyIfICanViewAndSelectVariousOptionUnderRiskEventEscalationProcessPage() {
//        try{
//            businessBankingHelper.verifyPage("Risk Event Escalation Process", bankingObjects.riskEventEscalation);
//            businessBankingHelper.takeSnapShot("riskEventEscalationProcessPage");
//
//        }catch (Exception e){
//            e.printStackTrace();
//        }
//
//    }
//
//    @And("^I am able to view and select RBB and BB Policies and Processes page$")
//    public void iAmAbleToViewAndSelectRBBAndBBPoliciesAndProcessesPage() {
//        try{
//            businessBankingHelper.verifyPage("RBB and BB Policies and Processes", bankingObjects.rbbPolicies);
//            businessBankingHelper.takeSnapShot("RBBAndBBPoliciesAndProcessesPage");
//            businessBankingHelper.clickElement(bankingObjects.rbbPolicies);
//        }catch (Exception e){
//            e.printStackTrace();
//        }
//
//    }
//
//    @And("^I am able to view and select Finance Accounting and Tax page$")
//    public void iAmAbleToViewAndSelectFinanceAccountingAndTaxPage() {
//        try{
//            businessBankingHelper.verifyPage("Finance Accounting and Tax", bankingObjects.financialAccountingLabel);
//            businessBankingHelper.takeSnapShot("financeAccountingAndTax");
//            businessBankingHelper.clickElement(bankingObjects.financialAccountingLabel);
//        }catch (Exception e){
//            e.printStackTrace();
//        }
//    }
//
//    @Then("^Verify if I can view and select various option under Finance and Accounting Tax page$")
//    public void verifyIfICanViewAndSelectVariousOptionUnderFinanceAndAccountingTaxPage() {
//        try{
//            businessBankingHelper.verifyPage("Finance Accounting and Tax", bankingObjects.financialAccountingLabel);
//            businessBankingHelper.closePage();
//        }catch (Exception e){
//            e.printStackTrace();
//        }
//
//    }
//}
