package cm_business_banking.tests;

import cm_business_banking.objects.AgriOverview;
import cm_business_banking.objects.Agriculture;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class AgriOverviewTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmempr/BB/Home/Navigation?CategoryId=1346");
    Agriculture agriculture = new Agriculture(launchDriver.getDriver());
    AgriOverview agriOverview = new AgriOverview(launchDriver.getDriver());

    @And("^I am able to select and verify Agriculture Overview Category on Agriculture Category$")
    public void iAmAbleToSelectAndVerifyAgricultureOverviewCategoryOnAgricultureCategory() {
        agriculture.getOverview();
    }

    @And("^I am able to verify and select Overview of the agriculture industry Category on Agriculture Overview Category$")
    public void iAmAbleToVerifyAndSelectOverviewOfTheAgricultureIndustryCategoryOnAgricultureOverviewCategory() {
        agriOverview.getOverviewAgricultureIndustry();
    }

    @Then("^Verify all available operation on Overview of the agriculture industry Article Page$")
    public void verifyAllAvailableOperationOnOverviewOfTheAgricultureIndustryArticlePage() {
        agriOverview.verifyOverviewAgricultureIndustry();
    }
}
