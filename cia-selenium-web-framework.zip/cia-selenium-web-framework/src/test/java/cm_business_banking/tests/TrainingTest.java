package cm_business_banking.tests;

import cm_business_banking.objects.Credit;
import cm_business_banking.objects.Training;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class TrainingTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmemqa/BB/Home/Navigation?CategoryId=1153");
    Credit credit = new Credit(launchDriver.getDriver());
    Training training = new Training(launchDriver.getDriver());

    @And("^I am able to select and verify Training Category on Credit Category$")
    public void iAmAbleToSelectAndVerifyTrainingCategoryOnCreditCategory() {
        credit.getTraining();
    }

    @And("^I am able to verify and select ACM Mitigant And Document Management Procedure Category on Training Category$")
    public void iAmAbleToVerifyAndSelectACMMitigantAndDocumentManagementProcedureCategoryOnTrainingCategory() {
        training.getACMMitigantAndDocumentManagementProcedure();
    }

    @Then("^Verify all available operation on ACM Mitigant And Document Management Procedure Article Page$")
    public void verifyAllAvailableOperationOnACMMitigantAndDocumentManagementProcedureArticlePage() {
        training.verifyACMMitigantAndDocumentManagementProcedure();
    }

    @And("^I am able to verify and select ACM Facility Management Procedure Category on Training Category$")
    public void iAmAbleToVerifyAndSelectACMFacilityManagementProcedureCategoryOnTrainingCategory() {
        training.getACMFacilityManagementProcedure();
    }

    @Then("^Verify all available operation on ACM Facility Management Procedure Article Page$")
    public void verifyAllAvailableOperationOnACMFacilityManagementProcedureArticlePage() {
        training.verifyACMFacilityManagementProcedure();

    }

    @And("^I am able to verify and select ACM Entity Management Procedure Category on Training Category$")
    public void iAmAbleToVerifyAndSelectACMEntityManagementProcedureCategoryOnTrainingCategory() {
        training.getACMEntityManagementProcedure();
    }

    @Then("^Verify all available operation on ACM Entity Management Procedure Article Page$")
    public void verifyAllAvailableOperationOnACMEntityManagementProcedureArticlePage() {
        training.verifyACMEntityManagementProcedure();
    }

    @And("^I am able to verify and select Training Hyperlinks Category on Training Category$")
    public void iAmAbleToVerifyAndSelectTrainingHyperlinksCategoryOnTrainingCategory() {
        training.getTrainingHyperlinks();
    }

    @Then("^Verify all available operation on Training Hyperlinks Article Page$")
    public void verifyAllAvailableOperationOnTrainingHyperlinksArticlePage() {
        training.verifyTrainingHyperlinks();
    }

    @And("^I am able to verify and select Credit Pipeline Category on Training Category$")
    public void iAmAbleToVerifyAndSelectCreditPipelineCategoryOnTrainingCategory() {
        training.getCreditPipeline();
    }

    @Then("^Verify all available operation on Credit Pipeline Article Page$")
    public void verifyAllAvailableOperationOnCreditPipelineArticlePage() {
        training.verifyCreditPipeline();
    }

    @And("^I am able to verify and select RMM Risk Management Measure Category on Training Category$")
    public void iAmAbleToVerifyAndSelectRMMRiskManagementMeasureCategoryOnTrainingCategory() {
        training.getRMMRiskManagementMeasure();
    }

    @Then("^Verify all available operation on RMM Risk Management Measure Article Page$")
    public void verifyAllAvailableOperationOnRMMRiskManagementMeasureArticlePage() {
        training.verifyRMMRiskManagementMeasure();
    }

    @And("^I am able to verify and select Impairment Portal Introduction Category on Training Category$")
    public void iAmAbleToVerifyAndSelectImpairmentPortalIntroductionCategoryOnTrainingCategory() {
        training.getImpairmentPortalIntroduction();
    }

    @Then("^Verify all available operation on Impairment Portal Introduction Article Page$")
    public void verifyAllAvailableOperationOnImpairmentPortalIntroductionArticlePage() {
        training.verifyImpairmentPortalIntroduction();
    }

    @And("^Verify all available operation on eSoda Quick Training Guide Article Page$")
    public void iAmAbleToVerifyAndSelectESodaQuickTrainingGuideCategoryOnTrainingCategory() {
        training.getESodaQuickTrainingGuide();
    }

    @Then("^Verify all available operation oneSoda Quick Training Guide Article Page$")
    public void verifyAllAvailableOperationOneSodaQuickTrainingGuideArticlePage() {
        training.verifyESodaQuickTrainingGuide();
    }

    @And("^I am able to verify and select eCAS Quick Guide Category on Training Category$")
    public void iAmAbleToVerifyAndSelectECASQuickGuideCategoryOnTrainingCategory() {
        training.getECASQuickGuide();
    }

    @Then("^Verify all available operation on eCAS Quick Guide Article Page$")
    public void verifyAl() {
        training.verifyECASQuickGuide();
    }

    @And("^I am able to verify and select Plug And Transact Token Afr Radio Category on Training Category$")
    public void iAmAbleToVerifyAndSelectPlugAndTransactTokenAfrRadioCategoryOnTrainingCategory() {
        training.getPlugAndTransactTokenAfrRadio();
    }

    @Then("^Verify all available operation on Plug And Transact Token Afr Radio Article Page$")
    public void verifyAllAvailableOperationOnPlugAndTransactTokenAfrRadioArticlePage() {
        training.verifyPlugAndTransactTokenAfrRadio();
    }
}
