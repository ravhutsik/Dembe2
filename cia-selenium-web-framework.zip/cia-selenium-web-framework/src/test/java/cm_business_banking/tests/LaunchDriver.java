package cm_business_banking.tests;

import cm_utils.DriverFactory;
import org.openqa.selenium.WebDriver;

public class LaunchDriver {


    private String businessBankingURL;

    public LaunchDriver(String businessBankingURL) {
        this.businessBankingURL = businessBankingURL;
    }

    public WebDriver getDriver() {
        return DriverFactory.getDriver(businessBankingURL);
    }
}
