package cm_business_banking.tests;

import cm_business_banking.objects.DocumentLibrary;
import cm_business_banking.objects.GeneralBusinessBanking;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class GeneralBBCategoryTest {

    LaunchDriver launchDriver = new LaunchDriver("http://biscorpmemqa/BB/Home/Navigation?CategoryId=1167");
    DocumentLibrary documentLibrary = new DocumentLibrary(launchDriver.getDriver());

    GeneralBusinessBanking generalBusinessBanking = new GeneralBusinessBanking(launchDriver.getDriver());

    @And("^I am able to select and verify General Category on Document Library$")
    public void iAmAbleToSelectAndVerifyGeneralCategoryOnDocumentLibrary() {
        try {
            documentLibrary.getGeneral();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @And("^I am able to verify and select Day Take Over Report Category on General Category$")
    public void iAmAbleToVerifyAndSelectDayTakeOverReportCategoryOnGeneralCategory() {
        try {
            generalBusinessBanking.getTakeOverReport();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }

    }

    @Then("^Verify all available operation on Day Take Over Report Page$")
    public void verifyAllAvailableOperationOnDayTakeOverReportPage() {
        try {
            generalBusinessBanking.verifyDayTakeOverReportPage();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @And("^I am able to verify and select Common Fraud Database Checklist Category on General Category$")
    public void iAmAbleToVerifyAndSelectCommonFraudDatabaseChecklistCategoryOnGeneralCategory() {
        try {

            generalBusinessBanking.getCommonFraudDBChecklist();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @Then("^Verify all available operation on Common Fraud Database Checklist Article Page$")
    public void verifyAllAvailableOperationOnCommonFraudDatabaseChecklistArticlePage() {
        try {
            generalBusinessBanking.verifyCommonFraudDatabaseChecklistPage();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @And("^I am able to verify and select Testing Category on General Category$")
    public void iAmAbleToVerifyAndSelectTestingCategoryOnGeneralCategory() {
        try {
            generalBusinessBanking.getTesting();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @Then("^Verify all available operation on Testing Article Page$")
    public void verifyAllAvailableOperationOnTestingArticlePage() {
        try {
            generalBusinessBanking.verifyTestingPage();

        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @And("^I am able to verify and select TN Testing Video Category on General Category$")
    public void iAmAbleToVerifyAndSelectTNTestingVideoCategoryOnGeneralCategory() {
        try {
            generalBusinessBanking.getTN_Test_Video();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @Then("^Verify all available operation on TN Testing Video Article Page$")
    public void verifyAllAvailableOperationOnTNTestingVideoArticlePage() {
        try {
            generalBusinessBanking.verifyTNTestVideoPage();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @And("^I am able to verify and select TIER Two & Three Template Category on General Category$")
    public void iAmAbleToVerifyAndSelectTIERTwoThreeTemplateCategoryOnGeneralCategory() {
        try {
            generalBusinessBanking.getTIER_TEMPLATE();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @Then("^Verify all available operation on TIER Two & Three Template Article Page$")
    public void verifyAllAvailableOperationOnTIERTwoThreeTemplateArticlePage() {
        try {
            generalBusinessBanking.verifyTieTemplatePage();

        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @And("^I am able to verify and select PRECCA Reporting Template Category on General Category$")
    public void iAmAbleToVerifyAndSelectPRECCAReportingTemplateCategoryOnGeneralCategory() {
        try {
            generalBusinessBanking.getPRECCA_REPORTING_TEMPLATE();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @Then("^Verify all available operation on PRECCA Reporting Template Article Page$")
    public void verifyAllAvailableOperationOnPRECCAReportingTemplateArticlePage() {
        try {
            generalBusinessBanking.verifyPRECCAReportingTemplatePage();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @And("^I am able to verify and select Facility Letters Category on General Category$")
    public void iAmAbleToVerifyAndSelectFacilityLettersCategoryOnGeneralCategory() {
        try {
            generalBusinessBanking.getFACILITY_LETTERS();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @Then("^Verify all available operation on Facility Letters Article Page$")
    public void verifyAllAvailableOperationOnFacilityLettersArticlePage() {
        try {
            generalBusinessBanking.verifyFacilityLetterPage();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @And("^I am able to verify and select TN Testing Audio Category on General Category$")
    public void iAmAbleToVerifyAndSelectTNTestingAudioCategoryOnGeneralCategory() {
        try {
            generalBusinessBanking.getTN_Test_Audio();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @Then("^Verify all available operation on TN Testing Audio Article Page$")
    public void verifyAllAvailableOperationOnTNTestingAudioArticlePage() {
        try {
            generalBusinessBanking.verifyTNTestAudioPage();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @And("^I am able to verify and select Handover Checklist Category on General Category$")
    public void iAmAbleToVerifyAndSelectHandoverChecklistCategoryOnGeneralCategory() {
        try {
            generalBusinessBanking.getHandover_Checklist();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    @Then("^Verify all available operation on Handover Checklist Article Page$")
    public void verifyAllAvailableOperationOnHandoverChecklistArticlePage() {
        try {
            generalBusinessBanking.verifyHandoverChecklistPage();
        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }
}
