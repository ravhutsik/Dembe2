package cm_business_banking.tests;

import cm_business_banking.objects.Franchising;
import cm_business_banking.objects.MarketingMaterial;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class MarketingMaterialTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmempr/BB/Home/Navigation?CategoryId=1336");
    Franchising franchising = new Franchising(launchDriver.getDriver());
    MarketingMaterial marketingMaterial = new MarketingMaterial(launchDriver.getDriver());

    @And("^I am able to verify and select Marketing Material Category from Franchising Category$")
    public void iAmAbleToVerifyAndSelectMarketingMaterialCategoryFromFranchisingCategory() {
        franchising.getMarketingMaterial();
    }

    @And("^I am able to verify and select An Franchise Brochure Category on Marketing Material Category$")
    public void iAmAbleToVerifyAndSelectAnFranchiseBrochureCategoryOnMarketingMaterialCategory() {
        marketingMaterial.getFranchiseBrochure();
    }

    @Then("^Verify all available operation on An Franchise Brochure Article Page$")
    public void verifyAllAvailableOperationOnAnFranchiseBrochureArticlePage() {
        marketingMaterial.verifyFranchiseBrochure();
    }

    @And("^I am able to verify and select Franchise Leaflet Category on Marketing Material Category$")
    public void iAmAbleToVerifyAndSelectFranchiseLeafletCategoryOnMarketingMaterialCategory() {
        marketingMaterial.getFranchiseLeaflet();
    }

    @Then("^Verify all available operation on Franchise Leaflet Article Page$")
    public void verifyAllAvailableOperationOnFranchiseLeafletArticlePage() {
        marketingMaterial.verifyFranchiseLeaflet();
    }

    @And("^I am able to verify and select Financing Renewable Energy Category on Marketing Material Category$")
    public void iAmAbleToVerifyAndSelectFinancingRenewableEnergyCategoryOnMarketingMaterialCategory() {
        marketingMaterial.getFinancingRenewableEnergy();
    }

    @Then("^Verify all available operation on Financing Renewable Energy Article Page$")
    public void verifyAllAvailableOperationOnFinancingRenewableEnergyArticlePage() {
        marketingMaterial.verifyFinancingRenewableEnergy();
    }

    @And("^I am able to verify and select Consumer Protection: Know your rights Category on Marketing Material Category$")
    public void iAmAbleToVerifyAndSelectConsumerProtectionKnowYourRightsCategoryOnMarketingMaterialCategory() {
        marketingMaterial.getConsumerProtection();
    }

    @Then("^Verify all available operation on Consumer Protection: Know your rights Article Page$")
    public void verifyAllAvailableOperationOnConsumerProtectionKnowYourRightsArticlePage() {
        marketingMaterial.verifyConsumerProtection();
    }

    @And("^I am able to verify and select Franchise Brochure - Automotive Category on Marketing Material Category$")
    public void iAmAbleToVerifyAndSelectFranchiseBrochureAutomotiveCategoryOnMarketingMaterialCategory() {
        marketingMaterial.getFranchiseBrochureAutomotive();
    }

    @Then("^Verify all available operation on Franchise Brochure - Automotive Article Page$")
    public void verifyAllAvailableOperationOnFranchiseBrochureAutomotiveArticlePage() {
        marketingMaterial.verifyFranchiseBrochureAutomotive();
    }

    @And("^I am able to verify and select Franchise Brochure - Fuel Category on Marketing Material Category$")
    public void iAmAbleToVerifyAndSelectFranchiseBrochureFuelCategoryOnMarketingMaterialCategory() {
        marketingMaterial.getFranchiseBrochureFuel();
    }

    @Then("^Verify all available operation on Franchise Brochure - Fuel Article Page$")
    public void verifyAllAvailableOperationOnFranchiseBrochureFuelArticlePage() {
        marketingMaterial.verifyFranchiseBrochureFuel();
    }

    @And("^I am able to verify and select GAP Access Brochure Category on Marketing Material Category$")
    public void iAmAbleToVerifyAndSelectGAPAccessBrochureCategoryOnMarketingMaterialCategory() {
        marketingMaterial.getGAPAccessBrochure();
    }

    @Then("^Verify all available operation on GAP Access Brochure Article Page$")
    public void verifyAllAvailableOperationOnGAPAccessBrochureArticlePage() {
        marketingMaterial.verifyGAPAccessBrochure();
    }

    @And("^I am able to verify and select Market Edge Brochure Category on Marketing Material Category$")
    public void iAmAbleToVerifyAndSelectMarketEdgeBrochureCategoryOnMarketingMaterialCategory() {
        marketingMaterial.getMarketEdgeBrochure();
    }

    @Then("^Verify all available operation on Market Edge Brochure Article Page$")
    public void verifyAllAvailableOperationOnMarketEdgeBrochureArticlePage() {
        marketingMaterial.verifyMarketEdgeBrochure();
    }

    @And("^I am able to verify and select Franchise Brochure - Retail Category on Marketing Material Category$")
    public void iAmAbleToVerifyAndSelectFranchiseBrochureRetailCategoryOnMarketingMaterialCategory() {
        marketingMaterial.getFranchiseBrochureRetail();
    }

    @Then("^Verify all available operation on Franchise Brochure - Retail Article Page$")
    public void verifyAllAvailableOperationOnFranchiseBrochureRetailArticlePage() {
        marketingMaterial.verifyFranchiseBrochureRetail();
    }

    @And("^I am able to verify and select What is franchising Category on Marketing Material Category$")
    public void iAmAbleToVerifyAndSelectWhatIsFranchisingCategoryOnMarketingMaterialCategory() {
        marketingMaterial.getWhatIsFranchising();
    }

    @Then("^Verify all available operation on What is franchising Article Page$")
    public void verifyAllAvailableOperationOnWhatIsFranchisingArticlePage() {
        marketingMaterial.verifyWhatIsFranchising();
    }

    @Then("^Verify all available operation on Infographic - How to apply for franchise finance Article Page$")
    public void verifyAllAvailableOperationOnInfographicHowToApplyForFranchiseFinanceArticlePage() {
        marketingMaterial.getInfographic();
    }

    @And("^I am able to verify and select Infographic - How to apply for franchise finance Category on Marketing Material Category$")
    public void iAmAbleToVerifyAndSelectInfographicHowToApplyForFranchiseFinanceCategoryOnMarketingMaterialCategory() {
        marketingMaterial.verifyInfographic();
    }
}
