package cm_business_banking.tests;

import cm_business_banking.objects.Legislation;
import cm_business_banking.objects.PublicSector;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class LegislationTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmemqa/BB/Home/Navigation?CategoryId=1251");
    PublicSector publicSector = new PublicSector(launchDriver.getDriver());
    Legislation legislation = new Legislation(launchDriver.getDriver());

    @And("^I am able to select and verify Legislation Category on Public Sector Category$")
    public void iAmAbleToSelectAndVerifyLegislationCategoryOnPublicSectorCategory() {
        publicSector.getLegislation();
    }

    @And("^I am able to verify and select MFMA Category on Legislation Category$")
    public void iAmAbleToVerifyAndSelectMFMACategoryOnLegislationCategory() {
        legislation.getMFMA();
    }

    @Then("^Verify all available operation on MFMA Article Page$")
    public void verifyAllAvailableOperationOnMFMAArticlePage() {
        legislation.verifyMFMA();
    }

    @And("^I am able to verify and select Municipal Systems Act Category on Legislation Category$")
    public void iAmAbleToVerifyAndSelectMunicipalSystemsActCategoryOnLegislationCategory() {
        legislation.getFXDerivativesByNedbank();
    }

    @Then("^Verify all available operation on Municipal Systems Act Article Page$")
    public void verifyAllAvailableOperationOnMunicipalSystemsActArticlePage() {
        legislation.verifyFXDerivativesByNedbank();
    }

    @And("^I am able to verify and select PFMA Category on Legislation Category$")
    public void iAmAbleToVerifyAndSelectPFMACategoryOnLegislationCategory() {
        legislation.getPFMA();
    }

    @Then("^Verify all available operation on PFMA Article Page$")
    public void verifyAllAvailableOperationOnPFMAArticlePage() {
        legislation.verifyPFMA();
    }
}
