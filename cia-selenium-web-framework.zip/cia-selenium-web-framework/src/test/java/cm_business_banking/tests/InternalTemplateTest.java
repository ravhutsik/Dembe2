package cm_business_banking.tests;

import cm_business_banking.objects.CreditTemplateForm;
import cm_business_banking.objects.InternalTemplateCategory;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class InternalTemplateTest {

    LaunchDriver launchDriver = new LaunchDriver("http://biscorpmemqa/BB/Home/Navigation?CategoryId=1167");
    CreditTemplateForm creditTemplateForm = new CreditTemplateForm(launchDriver.getDriver());
    InternalTemplateCategory internalTemplateCategory = new InternalTemplateCategory(launchDriver.getDriver());


    @And("^I am able to select and verify Internal Template Category on Credit Templates And Forms Category$")
    public void iAmAbleToSelectAndVerifyInternalTemplateCategoryOnCreditTemplatesAndFormsCategory(){
        creditTemplateForm.getInternalTemplates();
    }

    @And("^I am able to verify and select Operational Management on Internal Template$")
    public void iAmAbleToVerifyAndSelectOperationalManagementOnInternalTemplate(){
        internalTemplateCategory.getOperationalManagement();
    }

    @Then("^Verify all available operation on Operational Management Page$")
    public void verifyAllAvailableOperationOnOperationalManagementPage()throws Exception{
        internalTemplateCategory.verifyOperationalManagement();
    }
}
