package cm_business_banking.tests;

import cm_business_banking.objects.CoreBankingSolution;
import cm_business_banking.objects.TransactionalCard;
import cm_business_banking.objects.TransactionalCash;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class TransactionalCardTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmempr/BB/Home/Navigation?CategoryId=1160");
    CoreBankingSolution coreBankingSolution = new CoreBankingSolution(launchDriver.getDriver());
    TransactionalCard transactionalCard = new TransactionalCard(launchDriver.getDriver());



    @And("^I am able to verify and select Transactional Card Category on Core Banking Solutions Category$")
    public void iAmAbleToVerifyAndSelectTransactionalCardCategoryOnCoreBankingSolutionsCategory() {
        coreBankingSolution.getTransactionalCard();
    }

    @Then("^I am able to verify and View Nedbank Business Card Category on Transactional Card Category$")
    public void iAmAbleToVerifyAndViewNedbankBusinessCardCategoryOnTransactionalCardCategory() {
        transactionalCard.getNedbankBusinessCard();
    }

    @Then("^I am able to verify and View Nedbank Cheque Card Category on Transactional Card Category$")
    public void iAmAbleToVerifyAndViewNedbankChequeCardCategoryOnTransactionalCardCategory() {
        transactionalCard.getNedbankChequeCard();
    }

    @Then("^I am able to verify and View Rewards Revolve Card Category on Transactional Card Category$")
    public void iAmAbleToVerifyAndViewRewardsRevolveCardCategoryOnTransactionalCardCategory() {
        transactionalCard.getRewardsRevolveCard();
    }

    @Then("^I am able to verify and View Portable POS Category on Transactional Card Category$")
    public void iAmAbleToVerifyAndViewPortablePOSCategoryOnTransactionalCardCategory() {
        transactionalCard.getPortablePOS();
    }

    @Then("^I am able to verify and View Nedbank Purchase Card Category on Transactional Card Category$")
    public void iAmAbleToVerifyAndViewNedbankPurchaseCardCategoryOnTransactionalCardCategory() {
        transactionalCard.getNedbankPurchaseCard();
    }

    @Then("^I am able to verify and View Desktop POS Category on Transactional Card Category$")
    public void iAmAbleToVerifyAndViewDesktopPOSCategoryOnTransactionalCardCategory() {
        transactionalCard.getDesktopPOS();
    }

    @Then("^I am able to verify and View Garage Card Category on Transactional Card Category$")
    public void iAmAbleToVerifyAndViewGarageCardCategoryOnTransactionalCardCategory() {
        transactionalCard.getGarageCard();
    }

    @Then("^I am able to verify and View Business Travel Account \\(BTA\\) Category on Transactional Card Category$")
    public void iAmAbleToVerifyAndViewBusinessTravelAccountBTACategoryOnTransactionalCardCategory() {
        transactionalCard.getBusinessTravelAccount();
    }
}
