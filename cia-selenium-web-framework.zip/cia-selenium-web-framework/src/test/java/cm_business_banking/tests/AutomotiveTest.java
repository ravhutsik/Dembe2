package cm_business_banking.tests;

import cm_business_banking.objects.*;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class AutomotiveTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmempr/BB/Home/Navigation?CategoryId=1248");
    Specialisation specialisation = new Specialisation(launchDriver.getDriver());
    Franchising franchising = new Franchising(launchDriver.getDriver());
    ClientValuePropositions clientValuePropositions = new ClientValuePropositions(launchDriver.getDriver());
    Automotive automotive = new Automotive(launchDriver.getDriver());

    @And("^I am able to verify and select Franchising Category from Specialisation Category$")
    public void iAmAbleToVerifyAndSelectFranchisingCategoryFromSpecialisationCategory() {
        specialisation.getFranchising();
    }

    @And("^I am able to verify and select Client Value Propositions Category from Franchising Category$")
    public void iAmAbleToVerifyAndSelectClientValuePropositionsCategoryFromFranchisingCategory() {
        franchising.getClientValuePropositions();
    }

    @And("^I am able to verify and select Automotive Category from Client Value Propositions Category$")
    public void iAmAbleToVerifyAndSelectAutomotiveCategoryFromClientValuePropositionsCategory() {
        clientValuePropositions.getAutomotive();
    }

    @And("^I am able to verify and select An Goldwagen Category on Automotive Category$")
    public void iAmAbleToVerifyAndSelectAnGoldwagenCategoryOnAutomotiveCategory() {
        automotive.getGoldwagen();
    }

    @Then("^Verify all available operation on An Goldwagen Article Page$")
    public void verifyAllAvailableOperationOnAnGoldwagenArticlePage() {
        automotive.verifyGoldwagen();
    }

    @And("^I am able to verify and select Kwik-Fit Category on Automotive Category$")
    public void iAmAbleToVerifyAndSelectKwikFitCategoryOnAutomotiveCategory() {
        automotive.getKwikFit();
    }

    @Then("^Verify all available operation on Kwik-Fit Article Page$")
    public void verifyAllAvailableOperationOnKwikFitArticlePage() {
        automotive.verifyKwikFit();
    }

    @And("^I am able to verify and select Mandarin Parts Category on Automotive Category$")
    public void iAmAbleToVerifyAndSelectMandarinPartsCategoryOnAutomotiveCategory() {
        automotive.getMandarinParts();
    }

    @Then("^Verify all available operation on Mandarin Parts Article Page$")
    public void verifyAllAvailableOperationOnMandarinPartsArticlePage() {
        automotive.verifyMandarinParts();
    }

    @And("^I am able to verify and select Tyremart Category on Automotive Category$")
    public void iAmAbleToVerifyAndSelectTyremartCategoryOnAutomotiveCategory() {
        automotive.getTyremart();
    }

    @Then("^Verify all available operation on Tyremart Article Page$")
    public void verifyAllAvailableOperationOnTyremartArticlePage() {
        automotive.verifyTyremart();
    }

    @And("^I am able to verify and select Hi-Q Category on Automotive Category$")
    public void iAmAbleToVerifyAndSelectHiQCategoryOnAutomotiveCategory() {
        automotive.getHiQ();
    }

    @Then("^Verify all available operation on Hi-Q Article Page$")
    public void verifyAllAvailableOperationOnHiQArticlePage() {
        automotive.verifyHiQ();
    }

    @And("^I am able to verify and select Tiger Wheel and Tyre Category on Automotive Category$")
    public void iAmAbleToVerifyAndSelectTigerWheelAndTyreCategoryOnAutomotiveCategory() {
        automotive.getTigerWheelAndTyre();
    }

    @Then("^Verify all available operation on Tiger Wheel and Tyre Article Page$")
    public void verifyAllAvailableOperationOnTigerWheelAndTyreArticlePage() {
        automotive.verifyTigerWheelAndTyre();
    }

    @And("^I am able to verify and select Tyre Plus Category on Automotive Category$")
    public void iAmAbleToVerifyAndSelectTyrePlusCategoryOnAutomotiveCategory() {
        automotive.getTyrePlus();
    }

    @Then("^Verify all available operation on Tyre Plus Article Page$")
    public void verifyAllAvailableOperationOnTyrePlusArticlePage() {
        automotive.verifyTyrePlus();
    }

    @And("^I am able to verify and select Tyres and More Category on Automotive Category$")
    public void iAmAbleToVerifyAndSelectTyresAndMoreCategoryOnAutomotiveCategory() {
        automotive.getTyresAndMore();
    }

    @Then("^Verify all available operation on Tyres and More Article Page$")
    public void verifyAllAvailableOperationOnTyresAndMoreArticlePage() {
        automotive.verifyTyresAndMore();
    }

    @And("^I am able to verify and select POINT S Category on Automotive Category$")
    public void iAmAbleToVerifyAndSelectPOINTSCategoryOnAutomotiveCategory() {
        automotive.getPoints();
    }

    @Then("^Verify all available operation on POINT S Article Page$")
    public void verifyAllAvailableOperationOnPOINTSArticlePage() {
        automotive.verifyPoints();
    }

    @And("^I am able to verify and select Car Service City Category on Automotive Category$")
    public void iAmAbleToVerifyAndSelectCarServiceCityCategoryOnAutomotiveCategory() {
        automotive.getCarServiceCity();
    }

    @Then("^Verify all available operation on Car Service City Article Page$")
    public void verifyAllAvailableOperationOnCarServiceCityArticlePage() {
        automotive.verifyCarServiceCity();
    }
}
