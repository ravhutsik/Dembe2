package cm_business_banking.tests;

import cm_business_banking.objects.*;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class FranchiseTeamTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmempr/BB/Home/Navigation?CategoryId=1337");
    Franchising franchising = new Franchising(launchDriver.getDriver());
    FranchiseTeam franchiseTeam = new FranchiseTeam(launchDriver.getDriver());

    @And("^I am able to verify and select Franchise Team Category from Franchising Category$")
    public void iAmAbleToVerifyAndSelectFranchiseTeamCategoryFromFranchisingCategory() {
        franchising.getFranchiseTeam();
    }

    @And("^I am able to verify and select An Contact Details For The Franchising Team Category on Franchise Team Category$")
    public void iAmAbleToVerifyAndSelectAnContactDetailsForTheFranchisingTeamCategoryOnFranchiseTeamCategory() {
        franchiseTeam.getContactDetailsForTheFranchisingTeam();
    }

    @Then("^Verify all available operation on An Contact Details For The Franchising Team Article Page$")
    public void verifyAllAvailableOperationOnAnContactDetailsForTheFranchisingTeamArticlePage() {
        franchiseTeam.verifyContactDetailsForTheFranchisingTeam();
    }
}
