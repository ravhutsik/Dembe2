package cm_business_banking.tests;

import cm_business_banking.objects.BiggerPictureBusinessBanking;
import cm_business_banking.objects.CoreBankingSolution;
import cm_business_banking.objects.HomeCategory;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class BiggerPictureBusinessBankingTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmempr/BB/Home");
    HomeCategory homeCategory = new HomeCategory(launchDriver.getDriver());
    BiggerPictureBusinessBanking biggerPictureBusinessBanking = new BiggerPictureBusinessBanking(launchDriver.getDriver());

    @When("^I am able to verify and select Bigger Picture Business Banking Category$")
    public void iAmAbleToVerifyAndSelectBiggerPictureBusinessBankingCategory() {
        homeCategory.getBiggerPictureBusinessBanking();
    }

    @Then("^I am able to verify and View Brochures Category on Bigger Picture Business Banking Category$")
    public void iAmAbleToVerifyAndViewBrochuresCategoryOnBiggerPictureBusinessBankingCategory() {
        biggerPictureBusinessBanking.getBrochures();
    }

    @Then("^I am able to verify and View Term Videos Category on Bigger Picture Business Banking Category$")
    public void iAmAbleToVerifyAndViewTermVideosCategoryOnBiggerPictureBusinessBankingCategory() {
        biggerPictureBusinessBanking.getVideos();
    }

    @Then("^I am able to verify and View Radio Ads Category on Bigger Picture Business Banking Category$")
    public void iAmAbleToVerifyAndViewRadioAdsCategoryOnBiggerPictureBusinessBankingCategory() {
        biggerPictureBusinessBanking.getRadioAds();
    }

    @Then("^I am able to verify and View Banker Toolkit Category on Bigger Picture Business Banking Category$")
    public void iAmAbleToVerifyAndViewBankerToolkitCategoryOnBiggerPictureBusinessBankingCategory() {
        biggerPictureBusinessBanking.getBankerToolkit();
    }
}
