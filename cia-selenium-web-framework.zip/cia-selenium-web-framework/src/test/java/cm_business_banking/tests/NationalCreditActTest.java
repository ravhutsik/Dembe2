package cm_business_banking.tests;

import cm_business_banking.objects.Communication;
import cm_business_banking.objects.NationalCreditAct;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class NationalCreditActTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmemqa/BB/Home/Navigation?CategoryId=1237");
    Communication communication = new Communication(launchDriver.getDriver());
    NationalCreditAct nationalCreditAct = new NationalCreditAct(launchDriver.getDriver());


    @And("^I am able to select and verify National Credit Act on Communication Category$")
    public void iAmAbleToSelectAndVerifyNationalCreditActOnCommunicationCategory() {
        communication.getNCANationalCreditAct();
    }

    @And("^I am able to verify and select Automated Bureau Calls Category on National Credit Act Category$")
    public void iAmAbleToVerifyAndSelectAutomatedBureauCallsCategoryOnNationalCreditActCategory() {
        nationalCreditAct.getAutomatedBureauCalls();
    }

    @Then("^Verify all available operation on Automated Bureau Calls Article Page$")
    public void verifyAllAvailableOperationOnAutomatedBureauCallsArticlePage() {
        nationalCreditAct.verifyAutomatedBureauCalls();
    }
}
