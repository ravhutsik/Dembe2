package cm_business_banking.tests;

import cm_business_banking.objects.HomeCategory;
import cm_business_banking.objects.ManagedEvolution;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ManagedEvolutionTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmemqa/BB/Home");
    HomeCategory homeCategory = new HomeCategory(launchDriver.getDriver());
    ManagedEvolution managedEvolution = new ManagedEvolution(launchDriver.getDriver());



    @When("^I am able to verify and select Managed Evolution Category$")
    public void iAmAbleToVerifyAndSelectManagedEvolutionCategory() {
        homeCategory.getManagedEvolution();
    }

    @And("^I am able to verify and select An Integrated Solution Category on Managed Evolution Category$")
    public void iAmAbleToVerifyAndSelectAnIntegratedSolutionCategoryOnManagedEvolutionCategory() {
        managedEvolution.getIntegratedSolution();
    }

    @Then("^Verify all available operation on An Integrated Solution Article Page$")
    public void verifyAllAvailableOperationOnAnIntegratedSolutionArticlePage() {
        managedEvolution.verifyIntegratedSolution();
    }

    @And("^I am able to verify and select Eclipse Super User Training on Day one Category on Managed Evolution Category$")
    public void iAmAbleToVerifyAndSelectEclipseSuperUserTrainingOnDayOneCategoryOnManagedEvolutionCategory() {
        managedEvolution.getEclipseSuperUserTraining();
    }

    @Then("^Verify all available operation on Eclipse Super User Training on Day One Article Page$")
    public void verifyAllAvailableOperationOnEclipseSuperUserTrainingOnDayOneArticlePage() {
        managedEvolution.verifyEclipseSuperUserTraining();
    }

    @And("^I am able to verify and select Eclipse Super User Training on Day Two Category on Managed Evolution Category$")
    public void iAmAbleToVerifyAndSelectEclipseSuperUserTrainingOnDayTwoCategoryOnManagedEvolutionCategory() {
        managedEvolution.getEclipseSuperUserTraining2();
    }

    @Then("^Verify all available operation on Eclipse Super User Training on Day Two Article Page$")
    public void verifyAllAvailableOperationOnEclipseSuperUserTrainingOnDayTwoArticlePage() {
        managedEvolution.getEclipseSuperUserTraining2();
    }

    @And("^I am able to verify and select Beneficial Ownership Category on Managed Evolution Category$")
    public void iAmAbleToVerifyAndSelectBeneficialOwnershipCategoryOnManagedEvolutionCategory() {
        managedEvolution.getBeneficialOwnership();
    }

    @Then("^Verify all available operation on Beneficial Ownership Article Page$")
    public void verifyAllAvailableOperationOnBeneficialOwnershipArticlePage() {
        managedEvolution.verifyBeneficialOwnership();
    }

    @And("^I am able to verify and select BO Credit SME listing Category on Managed Evolution Category$")
    public void iAmAbleToVerifyAndSelectEclipseSuperUserTrainingOnDayCategoryOnManagedEvolutionCategory(int arg0) {
        managedEvolution.getBOCreditSMEListing();
    }

    @Then("^Verify all available operation on BO Credit SME listing Article Page$")
    public void verifyAllAvailableOperationOnBOCreditSMEListingArticlePage() {
        managedEvolution.verifyBOCreditSMEListingLabel();
    }
}
