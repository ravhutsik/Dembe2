package cm_business_banking.tests;

import cm_business_banking.objects.Communication;
import cm_business_banking.objects.CreditSystems;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class CreditSystemTest {

    LaunchDriver launchDriver =new LaunchDriver("http://biscorpmemqa/BB/Home/Navigation?CategoryId=1237");
    Communication communication = new Communication(launchDriver.getDriver());
    CreditSystems creditSystems = new CreditSystems(launchDriver.getDriver());


    @And("^I am able to select and verify Credit System Category on Communication Category$")
    public void iAmAbleToSelectAndVerifyCreditSystemCategoryOnCommunicationCategory() {
        communication.getCreditSystems();

    }

    @And("^I am able to verify and select Auto Review Category on Credit System$")
    public void iAmAbleToVerifyAndSelectAutoReviewCategoryOnCreditSystem() {
        creditSystems.getAutoReview();
    }

    @Then("^Verify all available operation on Auto Review Article Page$")
    public void verifyAllAvailableOperationOnAutoReviewArticlePage() {
        creditSystems.verifyAutoReview();
    }

    @And("^I am able to verify and select Excess And Arrear Management Category on Credit System$")
    public void iAmAbleToVerifyAndSelectExcessAndArrearManagementCategoryOnCreditSystem() {
        creditSystems.getExcessAndArrearManagement();
    }

    @Then("^Verify all available operation on Excess And Arrear Management Article Page$")
    public void verifyAllAvailableOperationOnExcessAndArrearManagementArticlePage() {
        creditSystems.verifyExcessAndArrearManagement();
    }

    @And("^I am able to verify and select eCAS Express Category on Credit System$")
    public void iAmAbleToVerifyAndSelectECASExpressCategoryOnCreditSystem() {
        creditSystems.getECASExpress();
    }

    @Then("^Verify all available operation on eCAS Express Article Page$")
    public void verifyAllAvailableOperationOnECASExpressArticlePage() {
        creditSystems.verifyECASExpress();
    }
}
