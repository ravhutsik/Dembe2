package cm_womens_forum.pom;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import static java.lang.Thread.*;


public class externalParties {
    private final WebDriver driver;

    //Women Forum system elements
     /*
    Name: Tshepo Mogale
    Date: 02 June 2021
    Description: External Parties elements
     */

    @FindBy(how = How.XPATH, using ="//*[@id=\"jsddm\"]/li[2]/a")
    private WebElement externalParties;

    @FindBy(how = How.XPATH, using ="//*[@id=\"divBody\"]/div[1]/a[1]/div[2]")
    private WebElement inspiringWoman;

    @FindBy(how = How.XPATH, using ="//*[@id=\"divBody\"]/div[1]/a[2]/div[2]")
    private WebElement businessEngage;

    @FindBy(how = How.XPATH, using ="//*[@id=\"divBody\"]/div[1]/a[3]/div[2]")
    private WebElement businessWomansAssociation;

    @FindBy(how = How.XPATH, using ="//*[@id=\"divBody\"]/div[2]/a[1]/div[2]")
    private WebElement nedbankMall;

    @FindBy(how = How.XPATH, using ="//*[@id=\"divBody\"]/div[2]/a[2]/div[2]")
    private WebElement internationalWomansForum;

    @FindBy(how = How.XPATH, using ="//*[@id=\"divBody\"]/div[2]/a[3]/div[2]")
    private WebElement leanInResources;

    @FindBy(how = How.XPATH, using ="//*[@id=\"cp_id_d8db2-1\"]/div[2]/div/div[1]/div/div[2]/div/div[1]/div/span/span/span")
    private WebElement inspiringWomanHomeText;

    @FindBy(how = How.XPATH, using ="//*[@id=\"menu-main-1\"]/li[1]/a")
    private WebElement businessEngageText;
    @FindBy(how = How.XPATH, using ="//*[@id=\"menu-item-1644\"]/a")
    private WebElement businessWomansAssociationText;

    @FindBy(how = How.XPATH, using ="//*[@id=\"menu-1-104e8ac\"]/li[1]/a")
    private WebElement internationalWomansForumText;

    @FindBy(how = How.XPATH, using ="//*[@id=\"series\"]/div/div[1]/div/div/h2")
    private WebElement leanInResourcesText;

    //Constructor
    public externalParties(WebDriver driver) {
        this.driver=driver;

        //Initialise Elements
        PageFactory.initElements(driver, this);
    }

    //Action Required
    public void clickOnExternalLink(){

        externalParties.click();
    }

    public void clickOnExternalLinkbusinessEngage() throws InterruptedException{
        businessEngage.click();
        String businessEngageTxt = businessEngageText.getText();
        Thread.sleep(1000);
        Assert.assertEquals("Home",businessEngageTxt);
        try {
            sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        driver.navigate().back();
    }

    public void businessWomansAssociation() throws InterruptedException{
        businessWomansAssociation.click();
        String businessWomansAssociationTxt = businessWomansAssociationText.getText();
        Thread.sleep(1000);
        Assert.assertEquals("Home",businessWomansAssociationTxt);
        try {
            sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        driver.navigate().back();
    }

    public void internationalWomansForum() throws InterruptedException{
        internationalWomansForum.click();
        String internationalWomansForumTxt = internationalWomansForumText.getText();
        Thread.sleep(1000);
        Assert.assertEquals("Home",internationalWomansForumTxt);
        try {
            sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        driver.navigate().back();
    }

    public void leanInResources() throws InterruptedException{
        leanInResources.click();
        String leanInResourcesTxt = leanInResourcesText.getText();
        Thread.sleep(1000);
        Assert.assertEquals("Expert video series from Lean In",leanInResourcesTxt);
        try {
            sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        driver.navigate().back();
    }

    public void clickOnInspiringWomanandVerify() throws InterruptedException {
        inspiringWoman.click();
        String InspiringWomanTxt = inspiringWomanHomeText.getText();
        Thread.sleep(100000);
        Assert.assertEquals("Get your daily dose of inspiration straight to your inbox...",InspiringWomanTxt);
        try {
            sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        driver.navigate().back();
    }
}
