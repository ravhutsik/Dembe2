package cm_womens_forum.pom;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class categories {
    private final WebDriver driver;

    @FindBy(how = How.XPATH, using ="//*[@id=\"CategoriesDiv\"]/a[1]/div/div[4]")
    private WebElement iAmWomanLink;

    @FindBy(how = How.XPATH, using ="//*[@id=\"CategoriesDiv\"]/a/div/div[4]/label")
    private WebElement aboutForumLink;

    @FindBy(how = How.XPATH, using ="//*[@id=\"CategoriesDiv\"]/a[1]/div/div[4]/label")
    private WebElement backgroundAndInformationLink;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[1]/div/div[7]/label")
    private WebElement tnTestArticleLink;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[2]/div/div[7]/label")
    private WebElement ctCommitteeMembersLink;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[3]/div/div[7]/label")
    private WebElement jhbWomanForumCommitteeMembersLink;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[4]/div/div[7]/label")
    private WebElement leboBikoPresentationAtWomansForumLink;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[5]/div/div[7]/label")
    private WebElement sixNovArticleLink;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[6]/div/div[7]/label")
    private WebElement womansForumPurposeLink;

    @FindBy(how = How.XPATH, using ="//*[@id=\"CategoriesDiv\"]/a[2]/div/div[4]/label")
    private WebElement presentationsLink;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[1]/div/div[7]/label")
    private WebElement testOnePresentationLink;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[2]/div/div[7]/label")
    private WebElement soemayaBoomgardAtConferencePresenationLink;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[3]/div/div[7]/label")
    private WebElement leboBikoPresentationAtWomenConferencePresentationLink;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[4]/div/div[7]/label")
    private WebElement messageFromRaisibePresentationLink;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[5]/div/div[7]/label")
    private WebElement barriersToTheAdvancementOfWomenInNedbankPresentationLink;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[6]/div/div[7]/label")
    private WebElement tranformationDialoguePresentationLink;

    @FindBy(how = How.XPATH, using ="//*[@id=\"BreadCrumbDiv\"]/div")
    private WebElement aboutForumCategoriesLink;

    @FindBy(how = How.XPATH, using ="//*[@id=\"BreadCrumbDiv\"]/a[1]/div")
    private WebElement selectCategories;

    @FindBy(how = How.XPATH, using ="//*[@id=\"CategoriesDiv\"]/a[2]/div/div[4]")
    private WebElement selectProfessionalDevelopment;

    @FindBy(how = How.XPATH, using ="//*[@id=\"CategoriesDiv\"]/a/div/div[4]/label")
    private WebElement selectResources;

    @FindBy(how = How.XPATH, using ="//*[@id=\"CategoriesDiv\"]/a[1]/div/div[4]/label")
    private WebElement selectArticles;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[1]/div/div[7]/label")
    private WebElement flexibilityAtWork;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[2]/div/div[7]/label")
    private WebElement fiveThingsThatMustChangeToEndGenderInequality;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[3]/div/div[7]/label")
    private WebElement genderBalancedSaWorkforce;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[4]/div/div[7]/label")
    private WebElement adressGenderBiasInCompaniesAtTeamLevel;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[5]/div/div[7]/label")
    private WebElement diversityIsPositiveForBusiness;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[6]/div/div[7]/label")
    private WebElement beatingBurnout;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[7]/div/div[7]/label")
    private WebElement howToHandleDiscriminatoryComments;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[8]/div/div[7]/label")
    private WebElement mensBuyInIsPartOfTheSolution;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[9]/div/div[7]/label")
    private WebElement overcomingTheFearOfSuccess;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[10]/div/div[7]/label")
    private WebElement lessonsFromImprovedDiversityRates;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[11]/div/div[7]/label")
    private WebElement financialMailFocusOnGenderParity;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[12]/div/div[7]")
    private WebElement motherhoodAndCareerAmbition;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[13]/div/div[7]/label")
    private WebElement halfTimeCreativeRolesToWooFemaleTalent;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[14]/div/div[7]/label")
    private WebElement womenInSaDisappearOnPathToSenoirLeadership;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[15]/div/div[7]/label")
    private WebElement theConfidenceGap;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[16]/div/div[7]/label")
    private WebElement whyWomenDontApplyForJobs;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[17]/div/div[7]/label")
    private WebElement howToGetIntoTheCsuite;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[18]/div/div[7]")
    private WebElement yourCareerNeedsMoreThanOneMentor;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[19]/div/div[7]/label")
    private WebElement evaluatingAJobOffer;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[20]/div/div[7]/label")
    private WebElement whenYouAreLeavingYourJobBecauseOfKids;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[21]/div/div[7]")
    private WebElement emotionalIntelligenceHasTwelveElements;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[22]/div/div[7]/label")
    private WebElement theFemaleEconomy;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[23]/div/div[7]/label")
    private WebElement offrampsAndOnramps;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[24]/div/div[7]/label")
    private WebElement sevenTipsForAsuccessfulNegotiation;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[25]/div/div[7]/label")
    private WebElement womenInTheWorkPlace;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[26]/div/div[7]/label")
    private WebElement nationalBudgetPresentation;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[27]/div/div[7]/label")
    private WebElement resistingOfficePoliticsCanDamageYourCareer;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[28]/div/div[7]/label")
    private WebElement strategiesToPositionYouForAleadershipRole;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[29]/div/div[7]/label")
    private WebElement whyMentoringWontCreateMoreFermaleLeaders;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[30]/div/div[7]/label")
    private WebElement leadershipNatureVsNuture;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[31]/div/div[7]/label")
    private WebElement harderOnFemaleLeaders;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[32]/div/div[7]/label")
    private WebElement burnoutTheEnemyOfSleep;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[33]/div/div[7]/label")
    private WebElement womenMatterAfrica;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[34]/div/div[7]/label")
    private WebElement weShouldAllBeFeministsBook;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[35]/div/div[7]/label")
    private WebElement alwaysLikeAgirl;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[36]/div/div[7]/label")
    private WebElement threeSixNovArticle;

    @FindBy(how = How.XPATH, using = "//*[@id=\"BreadCrumbDiv\"]/a[3]/div")
    private WebElement navigateBackToResources;

    @FindBy(how = How.XPATH, using ="//*[@id=\"CategoriesDiv\"]/a[2]/div/div[4]/label")
    private WebElement expertTalks;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[1]/div/div[7]/label")
    private WebElement winningStrategiesForAnEvolvingCareer;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[2]/div/div[7]/label")
    private WebElement expertTalksNationalBudgetPresentation;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[3]/div/div[7]/label")
    private WebElement thePowerOfVulnerability;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[4]/div/div[7]/label")
    private WebElement howGreatLeadersInspireAction;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[5]/div/div[7]/label")
    private WebElement teachGirlsBraveryNotPerfection;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[6]/div/div[7]/label")
    private WebElement sherylSandbergAfterLeanIn;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[7]/div/div[7]/label")
    private WebElement weShouldAllBeFeminists;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[8]/div/div[7]/label")
    private WebElement whyWeHaveTooFewWomenLeaders;

    @FindBy(how = How.XPATH, using ="//*[@id=\"ArticlesDiv\"]/a[9]/div/div[7]/label")
    private WebElement myYearOfSavingYesShondaRhimes;


    //Constructor
    public categories(WebDriver driver) {
        this.driver=driver;

        //Initialise Elements
        PageFactory.initElements(driver, this);
    }

    //Action Required
    public void clickIAmWomanLink() throws InterruptedException{
        iAmWomanLink.click();
    }

    public void clickAboutForumLink() throws InterruptedException{
        aboutForumLink.click();
    }

    public void clickBackgroundAndInformationLink() throws InterruptedException{
        backgroundAndInformationLink.click();
    }

    public void verifyTntArticle() throws InterruptedException{
        String feedbackCheck = tnTestArticleLink.getText();
        Assert.assertEquals("TNTestArticle11052020",feedbackCheck);
    }

    public void verifyCtCommitteeMembersLink() throws InterruptedException{
        String feedbackCheck = ctCommitteeMembersLink.getText();
        Assert.assertEquals("CT committee members",feedbackCheck);
    }

    public void verifyJhbWomanForumCommitteeMembersLink() throws InterruptedException{
        String feedbackCheck = jhbWomanForumCommitteeMembersLink.getText();
        Assert.assertEquals("Johannesburg Woman's Forum committee members",feedbackCheck);
    }

    public void verifyLeboBikoPresentationAtWomansForumLink() throws InterruptedException{
        String feedbackCheck = leboBikoPresentationAtWomansForumLink.getText();
        Assert.assertEquals("Lebo Biko Presentation at Women's Conference",feedbackCheck);
    }

    public void verifySixNovArticleLink() throws InterruptedException{
        String feedbackCheck = sixNovArticleLink.getText();
        Assert.assertEquals("3Sixty Nov 2016 Article",feedbackCheck);
    }

    public void verifyWomansForumPurposeLink() throws InterruptedException{
        String feedbackCheck = womansForumPurposeLink.getText();
        Assert.assertEquals("Women's Forum Purpose",feedbackCheck);
    }

    public void navigateBackToAboutForum() throws InterruptedException{
        aboutForumCategoriesLink.click();
    }

    public void selectPresentationsLink() throws InterruptedException{
        presentationsLink.click();
    }

    public void verifyTestOnePresentationLink() throws InterruptedException{
        String feedbackCheck = testOnePresentationLink.getText();
        Assert.assertEquals("test1",feedbackCheck);
    }

    public void verifyLoemayaBoomgardAtConferencePresenationLink() throws InterruptedException{
        String feedbackCheck = soemayaBoomgardAtConferencePresenationLink.getText();
        Assert.assertEquals("Soemaya Boomgard at 2016 conference",feedbackCheck);
    }

    public void verifyLeboBikoPresentationAtWomenConferencePresentationLink() throws InterruptedException{
        String feedbackCheck = leboBikoPresentationAtWomenConferencePresentationLink.getText();
        Assert.assertEquals("Lebo Biko Presentation at Woman's Conference",feedbackCheck);
    }

    public void verifyMessageFromRaisibePresentationLink() throws InterruptedException{
        String feedbackCheck = messageFromRaisibePresentationLink.getText();
        Assert.assertEquals("Message from Raisibe",feedbackCheck);
    }

    public void verifyBarriersToTheAdvancementOfWomenInNedbankPresentationLink() throws InterruptedException{
        String feedbackCheck = barriersToTheAdvancementOfWomenInNedbankPresentationLink.getText();
        Assert.assertEquals("Barriers to the Advancement of Women in Nedbank",feedbackCheck);
    }

    public void verifyTranformationDialoguePresentationLink() throws InterruptedException{
        String feedbackCheck = tranformationDialoguePresentationLink.getText();
        Assert.assertEquals("Tranformation Dialogue Presentation",feedbackCheck);
    }

    public void selectCategories() throws InterruptedException{
        selectCategories.click();
    }

    public void selectProfessionalDevelopment() throws InterruptedException{
        selectProfessionalDevelopment.click();
    }

    public void selectResources() throws InterruptedException{
        selectResources.click();
    }

    public void selectArticles() throws InterruptedException{
        selectArticles.click();
    }

    public void verifyArticleFlexibilityAtWork() throws InterruptedException{
        String feedbackCheck = flexibilityAtWork.getText();
        Assert.assertEquals("Flexibility at work",feedbackCheck);
    }

    public void verifyArticleFiveThingsThatMustChangeToEndGenderInequality() throws InterruptedException{
        String feedbackCheck = fiveThingsThatMustChangeToEndGenderInequality.getText();
        Assert.assertEquals("5 things that must change to end gender inequality",feedbackCheck);
    }

    public void verifyArticleGenderBalancedSaWorkforce() throws InterruptedException{
        String feedbackCheck = genderBalancedSaWorkforce.getText();
        Assert.assertEquals("Gender balanced SA workforce?",feedbackCheck);
    }

    public void verifyArticleAdressGenderBiasInCompaniesAtTeamLevel() throws InterruptedException{
        String feedbackCheck = adressGenderBiasInCompaniesAtTeamLevel.getText();
        Assert.assertEquals("Address gender bias in companies at team level",feedbackCheck);
    }

    public void verifyArticleDiversityIsPositiveForBusiness() throws InterruptedException{
        String feedbackCheck = diversityIsPositiveForBusiness.getText();
        Assert.assertEquals("Diversity is positive for business",feedbackCheck);
    }

    public void verifyArticleBeatingBurnout() throws InterruptedException{
        String feedbackCheck = beatingBurnout.getText();
        Assert.assertEquals("Beating burnout",feedbackCheck);
    }

    public void verifyArticleHowToHandleDiscriminatoryComments() throws InterruptedException{
        String feedbackCheck = howToHandleDiscriminatoryComments.getText();
        Assert.assertEquals("How to handle discriminatory comments", feedbackCheck);
    }

    public void verifyArticlemensBuyInIsPartOfTheSolution() throws InterruptedException{
        String feedbackCheck = mensBuyInIsPartOfTheSolution.getText();
        Assert.assertEquals("Men's buy-in is part of the solution", feedbackCheck);
    }

    public void verifyArticleOvercomingTheFearOfSuccess() throws InterruptedException{
        String feedbackCheck = overcomingTheFearOfSuccess.getText();
        Assert.assertEquals("Overcoming the fear of success",feedbackCheck);
    }

    public void verifyArticleLessonsFromImprovedDiversityRates() throws InterruptedException{
        String feedbackCheck = lessonsFromImprovedDiversityRates.getText();
        Assert.assertEquals("Lessons from improved diversity rates",feedbackCheck);
    }

    public void verifyArticleFinancialMailFocusOnGenderParity() throws InterruptedException{
        String feedbackCheck = financialMailFocusOnGenderParity.getText();
        Assert.assertEquals("Financial Mail: Focus on gender parity",feedbackCheck);
    }

    public void verifyArticleMotherhoodAndCareerAmbition() throws InterruptedException{
        String feedbackCheck = motherhoodAndCareerAmbition.getText();
        Assert.assertEquals("Motherhood and career ambition",feedbackCheck);
    }

    public void verifyArticleHalfTimeCreativeRolesToWooFemaleTalent() throws InterruptedException{
        String feedbackCheck = halfTimeCreativeRolesToWooFemaleTalent.getText();
        Assert.assertEquals("Half-time creative roles to woo female talent",feedbackCheck);
    }

    public void verifyArticleWomenInSaDisappearOnPathToSenoirLeadership() throws InterruptedException{
        String feedbackCheck = womenInSaDisappearOnPathToSenoirLeadership.getText();
        Assert.assertEquals("Women in SA disappear on path to senior leadership",feedbackCheck);
    }

    public void verifyArticleTheConfidenceGap() throws InterruptedException{
        String feedbackCheck = theConfidenceGap.getText();
        Assert.assertEquals("The Confidence Gap",feedbackCheck);
    }

    public void verifyArticleWhyWomenDontApplyForJobs() throws InterruptedException{
        String feedbackCheck = whyWomenDontApplyForJobs.getText();
        Assert.assertEquals("Why Women Don't apply For Jobs",feedbackCheck);
    }

    public void verifyArticleHowToGetIntoTheCsuite() throws InterruptedException{
        String feedbackCheck = howToGetIntoTheCsuite.getText();
        Assert.assertEquals("How to get into the C-Suite",feedbackCheck);
    }

    public void verifyArticleYourCareerNeedsMoreThanOneMentor() throws InterruptedException{
        String feedbackCheck = yourCareerNeedsMoreThanOneMentor.getText();
        Assert.assertEquals("Your Career Needs More than 1 Mentor",feedbackCheck);
    }

    public void verifyArticleEvaluatingAJobOffer() throws InterruptedException{
        String feedbackCheck = evaluatingAJobOffer.getText();
        Assert.assertEquals("Evaluating a job offer",feedbackCheck);
    }

    public void verifyArticleWhenYouAreLeavingYourJobBecauseOfKids() throws InterruptedException{
        String feedbackCheck = whenYouAreLeavingYourJobBecauseOfKids.getText();
        Assert.assertEquals("When you are leaving your job because of kids",feedbackCheck);
    }

    public void verifyArticleEmotionalIntelligenceHasTwelveElements() throws InterruptedException{
        String feedbackCheck = emotionalIntelligenceHasTwelveElements.getText();
        Assert.assertEquals("Emotional Intelligence has 12 Elements",feedbackCheck);
    }

    public void verifyArticleTheFemaleEconomy() throws InterruptedException{
        String feedbackCheck = theFemaleEconomy.getText();
        Assert.assertEquals("The Female Economy",feedbackCheck);
    }

    public void verifyArticleOfframpsAndOnramps() throws InterruptedException{
        String feedbackCheck = offrampsAndOnramps.getText();
        Assert.assertEquals("Offramps and onramps",feedbackCheck);
    }

    public void verifyArticleSevenTipsForAsuccessfulNegotiation() throws InterruptedException{
        String feedbackCheck = sevenTipsForAsuccessfulNegotiation.getText();
        Assert.assertEquals("Seven Tips for a Successful Negotiation",feedbackCheck);
    }

    public void verifyArticleWomenInTheWorkPlace() throws InterruptedException{
        String feedbackCheck = womenInTheWorkPlace.getText();
        Assert.assertEquals("Women in the Workplace 2016",feedbackCheck);
    }

    public void verifyArticleNationalBudgetPresentation() throws InterruptedException{
        String feedbackCheck = nationalBudgetPresentation.getText();
        Assert.assertEquals("National Budget Presentation 2017",feedbackCheck);
    }

    public void verifyArticleResistingOfficePoliticsCanDamageYourCareer() throws InterruptedException{
        String feedbackCheck = resistingOfficePoliticsCanDamageYourCareer.getText();
        Assert.assertEquals("Resisting Office Politics Can Damage Your Career",feedbackCheck);
    }

    public void verifyArticleStrategiesToPositionYouForAleadershipRole() throws InterruptedException{
        String feedbackCheck = strategiesToPositionYouForAleadershipRole.getText();
        Assert.assertEquals("Strategies to position you for a leadership role",feedbackCheck);
    }

    public void verifyArticleWhyMentoringWontCreateMoreFermaleLeaders() throws InterruptedException{
        String feedbackCheck = whyMentoringWontCreateMoreFermaleLeaders.getText();
        Assert.assertEquals("Why Mentoring Won’t Create More Female Leaders",feedbackCheck);
    }

    public void verifyArticleLeadershipNatureVsNuture() throws InterruptedException{
        String feedbackCheck = leadershipNatureVsNuture.getText();
        Assert.assertEquals("Leadership - Nature vs nurture:?",feedbackCheck);
    }

    public void verifyArticleHarderOnFemaleLeaders() throws InterruptedException{
        String feedbackCheck = harderOnFemaleLeaders.getText();
        Assert.assertEquals("Harder on Female Leaders",feedbackCheck);
    }

    public void verifyArticleBurnoutTheEnemyOfSleep() throws InterruptedException{
        String feedbackCheck = burnoutTheEnemyOfSleep.getText();
        Assert.assertEquals("Burnout: The Enemy of Sleep",feedbackCheck);
    }

    public void verifyArticleWomenMatterAfrica() throws InterruptedException{
        String feedbackCheck = womenMatterAfrica.getText();
        Assert.assertEquals("Women Matter Africa",feedbackCheck);
    }

    public void verifyArticleWeShouldAllBeFeministsBook() throws InterruptedException{
        String feedbackCheck = weShouldAllBeFeministsBook.getText();
        Assert.assertEquals("We Should All Be Feminists Book",feedbackCheck);
    }

    public void verifyArticleAlwaysLikeAgirl() throws InterruptedException{
        String feedbackCheck = alwaysLikeAgirl.getText();
        Assert.assertEquals("Always Like a Girl",feedbackCheck);
    }

    public void verifyArticleThreeSixNovArticle() throws InterruptedException{
        String feedbackCheck = threeSixNovArticle.getText();
        Assert.assertEquals("3Sixty Nov 2016 Article",feedbackCheck);
    }

    public void navigateBackToResources() throws InterruptedException{
        navigateBackToResources.click();
    }

    public void selectExpertTalksLink() throws InterruptedException{
        expertTalks.click();
    }

    public void verifyExpertTalkWinningStrategiesForAnEvolvingCareerLink() throws InterruptedException{
        String feedbackCheck = winningStrategiesForAnEvolvingCareer.getText();
        Assert.assertEquals("Winning Strategies For an Evolving Career",feedbackCheck);
    }

    public void verifyExpertTalksNationalBudgetPresentationLink() throws InterruptedException{
        String feedbackCheck = expertTalksNationalBudgetPresentation.getText();
        Assert.assertEquals("National Budget Presentation 2017",feedbackCheck);
    }

    public void verifyExpertTalkThePowerOfVulnerabilityLink() throws InterruptedException{
        String feedbackCheck = thePowerOfVulnerability.getText();
        Assert.assertEquals("The Power of Vulnerability",feedbackCheck);
    }

    public void verifyExpertTalkHowGreatLeadersInspireActionLink() throws InterruptedException{
        String feedbackCheck = howGreatLeadersInspireAction.getText();
        Assert.assertEquals("How Great Leaders Inspire Action",feedbackCheck);
    }

    public void verifyExpertTalkTeachGirlsBraveryNotPerfectionLink() throws InterruptedException{
        String feedbackCheck = teachGirlsBraveryNotPerfection.getText();
        Assert.assertEquals("Teach Girls Bravery Not Perfection",feedbackCheck);
    }

    public void verifyExpertTalkSherylSandbergAfterLeanInLink() throws InterruptedException{
        String feedbackCheck = sherylSandbergAfterLeanIn.getText();
        Assert.assertEquals("Sheryl Sandberg After Lean In",feedbackCheck);
    }

    public void verifyExpertTalkWeShouldAllBeFeministsLink() throws InterruptedException{
        String feedbackCheck = weShouldAllBeFeminists.getText();
        Assert.assertEquals("We Should All Be Feminists",feedbackCheck);
    }

    public void verifyExpertTalkWhyWeHaveTooFewWomenLeadersLink() throws InterruptedException{
        String feedbackCheck = whyWeHaveTooFewWomenLeaders.getText();
        Assert.assertEquals("Why we have too few women leaders",feedbackCheck);
    }

    public void verifyExpertTalkmyYearOfSavingYesShondaRhimesLink() throws InterruptedException{
        String feedbackCheck = myYearOfSavingYesShondaRhimes.getText();
        Assert.assertEquals("My Year of Saying Yes- Shonda Rhimes",feedbackCheck);
    }

    public void verifyIfOnResourcesPage() throws InterruptedException{
        String feedbackCheck = navigateBackToResources.getText();
        Assert.assertEquals("Resources", feedbackCheck);
    }
}
