package cm_womens_forum.cm_tests;
import cm_utils.DriverFactory;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cm_womens_forum.pom.homepage;
import cm_womens_forum.pom.externalParties;

import java.io.IOException;

public class cm_externalPartners {
    String url = "http://biscorpmemqa:86/WF/Home";
    private homepage HPObject = new homepage(DriverFactory.getDriver(url));
    private externalParties externalPartiesObjects = new externalParties(DriverFactory.getDriver(url));

    @Given("^i click on the EXTERNAL PARTNERS link$")
    public void clickOnExternalLink() throws IOException {
        externalPartiesObjects.clickOnExternalLink();
    }

    @And("^i can be able to view and verify External Link Business Engage$")
    public void clickOnExternalEventsLinks() throws IOException, InterruptedException {
        externalPartiesObjects.clickOnExternalLinkbusinessEngage();
    }

    @And("^i can be able to view and verify External Link International Womans Forum$")
    public void clickOnExternalLinkbusinessEngage() throws IOException, InterruptedException {
        externalPartiesObjects.internationalWomansForum();
    }

    @And("^i can be able to view and verify External Link Lean In Resources$")
    public void clickOnLeanInResources() throws IOException, InterruptedException {
        externalPartiesObjects.leanInResources();
    }

    @And("^i can be able to view and verify External Link Business Womans Association$")
    public void clickOnExternalLinkbusinessWomansAssociation() throws IOException, InterruptedException {
        externalPartiesObjects.businessWomansAssociation();
    }

    @Then("^i can be able to view and verify External Link Inspiring Woman$")
    public void clickOnInspiringWomanandVerify() throws IOException, InterruptedException {
        externalPartiesObjects.clickOnInspiringWomanandVerify();
    }
}