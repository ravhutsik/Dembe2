package cm_womens_forum.cm_tests;

import cm_utils.DriverFactory;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cm_womens_forum.pom.calendar;
import cm_womens_forum.pom.homepage;

import java.io.IOException;

public class cm_calendar {

    String url = "http://biscorpmemqa:86/WF/Home";
    private homepage HPObject = new homepage(DriverFactory.getDriver(url));
    private calendar calendarObjects = new calendar (DriverFactory.getDriver(url));

    @Given("^i am on home page and click on the CALENDAR link$")
    public void iClickOnTheCALENDARLink() throws IOException {
        HPObject.calendar();

    }

    @When("^i can be able to view all available events$")
    public void iCanBeAbleToViewAllAvailableEvents() throws IOException {
        calendarObjects.eventValidation();
    }

    @Then("^i validate calendar page$")
    public void iValidateCalendarPage() throws IOException {
        calendarObjects.calendarValidation();
    }
}
