package cm_womens_forum.cm_tests;

import cm_utils.DriverFactory;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import cm_womens_forum.pom.homepage;

import java.io.IOException;


public class cm_login {

    String url = "http://biscorpmemqa:86/WF/Home";
    private homepage HPObject = new homepage(DriverFactory.getDriver(url));


    @Given("^i have launched the browser$")
    public void iHaveLaunchedTheBrowser() {

        DriverFactory.getDriver(url);
    }

    @When("^i validated the home page$")
    public void iValidatedTheHomePage() throws IOException {
        HPObject.VerifyHomePage();
    }
}
