package cm_womens_forum.cm_tests;
import cm_utils.DriverFactory;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cm_womens_forum.pom.categories;
import cm_womens_forum.pom.homepage;

import java.io.IOException;

public class cm_categories {
    String url = "http://biscorpmemqa:86/WF/Home";

    private homepage HPObject = new homepage(DriverFactory.getDriver(url));
    private categories categoriesObjects = new categories(DriverFactory.getDriver(url));

    @Given("^I am at the WF home page$")
    public void iAmAtTheWFHomePage() throws IOException {
        HPObject.VerifyHomePage();
    }

    @When("^I am able to select and view options under I am A woman$")
    public void clickOnIAmWomanLink () throws IOException {
        try {
            categoriesObjects.clickIAmWomanLink();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @And("^I am able to select and view options under About the Forum$")
    public void clickAboutForumLink()  throws InterruptedException{
        categoriesObjects.clickAboutForumLink();
    }

    @And("^I able to select and view options under Background and Information$")
    public void clickBackgroundAndInformationLink() throws InterruptedException{
        categoriesObjects.clickBackgroundAndInformationLink();
    }

    @And("^I can Validate the TNTestArticle11052020 option$")
    public void verifyTntArticle() throws InterruptedException{
        categoriesObjects.verifyTntArticle();
    }

    @And("^I can Validate the CT committee members link$")
    public void verifyCtCommitteeMembersLink() throws InterruptedException{
        categoriesObjects.verifyCtCommitteeMembersLink();
    }

    @And("^I can Validate Woman's Forum committee members link$")
    public void verifyJhbWomanForumCommitteeMembersLink() throws InterruptedException{
        categoriesObjects.verifyJhbWomanForumCommitteeMembersLink();
    }

    @And("^Lebo Biko Presentation at Women's Conference link$")
    public void verifyLeboBikoPresentationAtWomansForumLink() throws InterruptedException{
        categoriesObjects.verifyLeboBikoPresentationAtWomansForumLink();
    }

    @And("^I can Validate 3Sixty Nov 2016 Article link$")
    public void verifySixNovArticleLink() throws InterruptedException{
        categoriesObjects.verifySixNovArticleLink();
    }

    @And("^I can Validate Woman's Forum Purpose link$")
    public void verifyWomansForumPurposeLink() throws InterruptedException{
        categoriesObjects.verifyWomansForumPurposeLink();
    }

    @And("^Navigate back to About forum$")
    public void navigateBackToAboutForum() throws InterruptedException{
        categoriesObjects.navigateBackToAboutForum();
    }

    @And("^Select and view options under Presentations$")
    public void selectPresentationsLink() throws InterruptedException{
        categoriesObjects.selectPresentationsLink();
    }

    @And("^I can validate the test1 link$")
    public void verifyTestOnePresentationLink() throws InterruptedException{
        categoriesObjects.verifyTestOnePresentationLink();
    }

    @And("^I can validate the Soemaya Boomgard at 2016 Conference link$")
    public void verifyLoemayaBoomgardAtConferencePresenationLink() throws InterruptedException{
        categoriesObjects.verifyLoemayaBoomgardAtConferencePresenationLink();
    }

    @And("^I can validate the Lebo Biko Presentation at Women's Conference link$")
    public void verifyLeboBikoPresentationAtWomenConferencePresentationLink() throws InterruptedException{
        categoriesObjects.verifyLeboBikoPresentationAtWomenConferencePresentationLink();
    }

    @And("^I can validate Message from Raisibe link$")
    public void verifyMessageFromRaisibePresentationLink() throws InterruptedException{
        categoriesObjects.verifyMessageFromRaisibePresentationLink();
    }

    @And("^I can validate the Barriers to the Advancement of Woman in Nedbank link$")
    public void verifyBarriersToTheAdvancementOfWomenInNedbankPresentationLink() throws InterruptedException{
        categoriesObjects.verifyBarriersToTheAdvancementOfWomenInNedbankPresentationLink();
    }

    @And("^I can validate the Transformation Dialogue Presentation link$")
    public void verifyTranformationDialoguePresentationLink() throws InterruptedException{
        categoriesObjects.verifyTranformationDialoguePresentationLink();
    }

    @Then("^Navigate back to Categories$")
    public void selectCategories() throws InterruptedException{
        categoriesObjects.selectCategories();
    }

    @When("^I am able to select and view options under Professional Development$")
    public void selectProfessionalDevelopment() throws InterruptedException{
        categoriesObjects.selectProfessionalDevelopment();
    }

    @And("^I am able to select and view options under Resources$")
    public void selectResources() throws InterruptedException{
        categoriesObjects.selectResources();
    }

    @And("^I am able to select and verify options under Articles$")
    public void selectArticles() throws InterruptedException{
        categoriesObjects.selectArticles();
    }

    @And("^I can validate the Flexibility at work article link$")
    public void verifyArticleFlexibilityAtWork() throws InterruptedException{
        categoriesObjects.verifyArticleFlexibilityAtWork();
    }

    @And("^I can validate the 5 things that must change to end gender inequality article link$")
    public void verifyArticleFiveThingsThatMustChangeToEndGenderInequality() throws InterruptedException{
        categoriesObjects.verifyArticleFiveThingsThatMustChangeToEndGenderInequality();
    }

    @And("^I can validate the Gender balanced SA workforce article link$")
    public void verifyArticleGenderBalancedSaWorkforce() throws InterruptedException{
        categoriesObjects.verifyArticleGenderBalancedSaWorkforce();
    }

    @And("^I can validate the Address gender bias in companies at team level article link$")
    public void verifyArticleAdressGenderBiasInCompaniesAtTeamLevel() throws InterruptedException{
        categoriesObjects.verifyArticleAdressGenderBiasInCompaniesAtTeamLevel();
    }

    @And("^I can validate the Diversity is positive for business article link$")
    public void verifyArticleDiversityIsPositiveForBusiness() throws InterruptedException{
        categoriesObjects.verifyArticleDiversityIsPositiveForBusiness();
    }

    @And("^I can validate Beating burnout article link$")
    public void verifyArticleBeatingBurnout() throws InterruptedException{
        categoriesObjects.verifyArticleBeatingBurnout();
    }

    @And("^I can validate the How to handle discriminatory comments article link$")
    public void verifyArticleHowToHandleDiscriminatoryComments() throws InterruptedException{
        categoriesObjects.verifyArticleHowToHandleDiscriminatoryComments();
    }

    @And("^I can validate Men's buy-in is part of the solution article link$")
    public void verifyArticlemensBuyInIsPartOfTheSolution() throws InterruptedException{
        categoriesObjects.verifyArticlemensBuyInIsPartOfTheSolution();
    }

    @And("^I can validate Overcoming the fear of success article link$")
    public void verifyArticleOvercomingTheFearOfSuccess() throws InterruptedException{
        categoriesObjects.verifyArticleOvercomingTheFearOfSuccess();
    }

    @And("^I can validate Lessons from improved diversity rates article link$")
    public void verifyArticleLessonsFromImprovedDiversityRates() throws InterruptedException{
        categoriesObjects.verifyArticleLessonsFromImprovedDiversityRates();
    }

    @And("^I can validate Financial Mail: Focus on gender parity article link$")
    public void verifyArticleFinancialMailFocusOnGenderParity() throws InterruptedException{
        categoriesObjects.verifyArticleFinancialMailFocusOnGenderParity();
    }

    @And("^I can validate Motherhood and career ambition article link$")
    public void verifyArticleMotherhoodAndCareerAmbition() throws InterruptedException{
        categoriesObjects.verifyArticleMotherhoodAndCareerAmbition();
    }

    @And("^I can validate Half-time creative roles to woo female talent article link$")
    public void verifyArticleHalfTimeCreativeRolesToWooFemaleTalent() throws InterruptedException{
        categoriesObjects.verifyArticleHalfTimeCreativeRolesToWooFemaleTalent();
    }

    @And("^I can validate Woman in SA disappear on the path to senior leadership article link$")
    public void verifyArticleWomenInSaDisappearOnPathToSenoirLeadership() throws InterruptedException{
        categoriesObjects.verifyArticleWomenInSaDisappearOnPathToSenoirLeadership();
    }

    @And("^I can validate The Confidence Gap article link$")
    public void verifyArticleTheConfidenceGap() throws InterruptedException{
        categoriesObjects.verifyArticleTheConfidenceGap();
    }

    @And("^I can validate Why Women Don't apply for Jobs article link$")
    public void verifyArticleWhyWomenDontApplyForJobs() throws InterruptedException{
        categoriesObjects.verifyArticleWhyWomenDontApplyForJobs();
    }

    @And("^I can validate How to get into the C-Suite article link$")
    public void verifyArticleHowToGetIntoTheCsuite() throws InterruptedException{
        categoriesObjects.verifyArticleHowToGetIntoTheCsuite();
    }

    @And("^I can validate Your Career Needs More than 1 Mentor article link$")
    public void verifyArticleYourCareerNeedsMoreThanOneMentor() throws InterruptedException{
        categoriesObjects.verifyArticleYourCareerNeedsMoreThanOneMentor();
    }

    @And("^I can Validate Evaluating a job offer article link$")
    public void verifyArticleEvaluatingAJobOffer() throws InterruptedException{
        categoriesObjects.verifyArticleEvaluatingAJobOffer();
    }

    @And("^I can Validate When you are leaving your job because of your kids article link$")
    public void verifyArticleWhenYouAreLeavingYourJobBecauseOfKids() throws InterruptedException{
        categoriesObjects.verifyArticleWhenYouAreLeavingYourJobBecauseOfKids();
    }

    @And("^I can validate Emotional Intelligence has 12 Elements article link$")
    public void verifyArticleEmotionalIntelligenceHasTwelveElements() throws InterruptedException{
        categoriesObjects.verifyArticleEmotionalIntelligenceHasTwelveElements();
    }

    @And("^I can validate The Female Economy article link$")
    public void verifyArticleTheFemaleEconomy() throws InterruptedException{
        categoriesObjects.verifyArticleTheFemaleEconomy();
    }

    @And("^I can validate Offramps and onramps article link$")
    public void verifyArticleOfframpsAndOnramps() throws InterruptedException{
        categoriesObjects.verifyArticleOfframpsAndOnramps();
    }

    @And("^I can validate Seven Tips for a Successful Negotiation article link$")
    public void verifyArticleSevenTipsForAsuccessfulNegotiation() throws InterruptedException{
        categoriesObjects.verifyArticleSevenTipsForAsuccessfulNegotiation();
    }

    @And("^I can validate Women in the Workplace 2016 article link$")
    public void verifyArticleWomenInTheWorkPlace() throws InterruptedException{
        categoriesObjects.verifyArticleWomenInTheWorkPlace();
    }

    @And("^I can validate National Budget Presentation 2017 article link$")
    public void verifyArticleNationalBudgetPresentation() throws InterruptedException{
        categoriesObjects.verifyArticleNationalBudgetPresentation();
    }

    @And("^I can validate Resisting Office Politics Can Damage Your Career article link$")
    public void verifyArticleResistingOfficePoliticsCanDamageYourCareer() throws InterruptedException{
        categoriesObjects.verifyArticleResistingOfficePoliticsCanDamageYourCareer();
    }

    @And("^I can validate Strategies to position you for a leadership role article link$")
    public void verifyArticleStrategiesToPositionYouForAleadershipRole() throws InterruptedException{
        categoriesObjects.verifyArticleStrategiesToPositionYouForAleadershipRole();
    }

    @And("^I can validate Why Mentoring Won't Create More Female Leaders article link$")
    public void verifyArticleWhyMentoringWontCreateMoreFermaleLeaders() throws InterruptedException{
        categoriesObjects.verifyArticleWhyMentoringWontCreateMoreFermaleLeaders();
    }

    @And("^I can validate Leadership - Nature vs nurture article link$")
    public void verifyArticleLeadershipNatureVsNuture() throws InterruptedException{
        categoriesObjects.verifyArticleLeadershipNatureVsNuture();
    }

    @And("^I can validate Harder on Female leaders article link$")
    public void verifyArticleHarderOnFemaleLeaders() throws InterruptedException{
        categoriesObjects.verifyArticleHarderOnFemaleLeaders();
    }

    @And("^I can validate Burnout: The Enemy of Sleep article link$")
    public void verifyArticleBurnoutTheEnemyOfSleep() throws InterruptedException{
        categoriesObjects.verifyArticleBurnoutTheEnemyOfSleep();
    }

    @And("^I can validate Women Matter Africa article link$")
    public void verifyArticleWomenMatterAfrica() throws InterruptedException{
        categoriesObjects.verifyArticleWomenMatterAfrica();
    }

    @And("^I can validate We should All be Feminists Book article link$")
    public void verifyArticleWeShouldAllBeFeministsBook() throws InterruptedException{
        categoriesObjects.verifyArticleWeShouldAllBeFeministsBook();
    }

    @And("^I can validate Always Like a Girl article link$")
    public void verifyArticleAlwaysLikeAgirl() throws InterruptedException{
        categoriesObjects.verifyArticleAlwaysLikeAgirl();
    }

    @And("^I can Validate 3Sixty Nov 2016 article link$")
    public void verifyArticleThreeSixNovArticle() throws InterruptedException{
        categoriesObjects.verifyArticleThreeSixNovArticle();
    }

    @Then("^Navigate back to Resources$")
    public void navigateBackToResources() throws InterruptedException{
        categoriesObjects.navigateBackToResources();
    }

   /* @Given("^I am on the Resources page$")
    public void verifyIfOnResourcesPage() throws InterruptedException{
        categoriesObjects.verifyIfOnResourcesPage();
    }*/

    @And("^I am able to select and verify options under Expert Talks$")
    public void selectExpertTalksLink() throws InterruptedException{
        categoriesObjects.selectExpertTalksLink();
    }

    @And("^I can validate Winning Strategies for an Evolving Career expert talk link$")
    public void verifyExpertTalkWinningStrategiesForAnEvolvingCareerLink() throws InterruptedException{
        categoriesObjects.verifyExpertTalkWinningStrategiesForAnEvolvingCareerLink();
    }

    @And("^I can validate National Budget Presentation expert link$")
    public void verifyExpertTalksNationalBudgetPresentationLink() throws InterruptedException{
        categoriesObjects.verifyExpertTalksNationalBudgetPresentationLink();
    }

    @And("^I can validate The Power of Vulnerability expert link$")
    public void verifyExpertTalkThePowerOfVulnerabilityLink() throws InterruptedException{
        categoriesObjects.verifyExpertTalkThePowerOfVulnerabilityLink();
    }

    @And("^I can validate How Great Leaders Inspire Action expert link$")
    public void verifyExpertTalkHowGreatLeadersInspireActionLink() throws InterruptedException{
        categoriesObjects.verifyExpertTalkHowGreatLeadersInspireActionLink();
    }

    @And("^I can validate Teach Girls Bravery Not Perfection expert link$")
    public void verifyExpertTalkTeachGirlsBraveryNotPerfectionLink() throws InterruptedException{
        categoriesObjects.verifyExpertTalkTeachGirlsBraveryNotPerfectionLink();
    }

    @And("^I can validate Sheryl Sandberg After Lean In expert link$")
    public void verifyExpertTalkSherylSandbergAfterLeanInLink() throws InterruptedException{
        categoriesObjects.verifyExpertTalkSherylSandbergAfterLeanInLink();
    }

    @And("^I can validate We Should All Be Feminists expert link$")
    public void verifyExpertTalkWeShouldAllBeFeministsLink() throws InterruptedException{
        categoriesObjects.verifyExpertTalkWeShouldAllBeFeministsLink();
    }

    @And("^I can validate Why We Have Too Few Women Leaders expert link$")
    public void verifyExpertTalkWhyWeHaveTooFewWomenLeadersLink() throws InterruptedException{
        categoriesObjects.verifyExpertTalkWhyWeHaveTooFewWomenLeadersLink();
    }

    @And("^I can validate My Year Of Saving Yes Shonda Rhimes expert link$")
    public void verifyExpertTalkmyYearOfSavingYesShondaRhimesLink() throws InterruptedException{
        categoriesObjects.verifyExpertTalkmyYearOfSavingYesShondaRhimesLink();
    }
}
