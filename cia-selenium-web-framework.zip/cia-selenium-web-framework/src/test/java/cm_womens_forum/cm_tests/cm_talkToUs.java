package cm_womens_forum.cm_tests;

import cm_utils.DriverFactory;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import cm_womens_forum.pom.homepage;
import cm_womens_forum.pom.talkToUs;

import java.io.IOException;

public class cm_talkToUs {
    //initializing the homepage object drivers
    String url = "http://biscorpmemqa:86/WF/Home";

    private homepage HPObject = new homepage(DriverFactory.getDriver(url));
    private talkToUs talkToUsObject = new talkToUs(DriverFactory.getDriver(url));

    @Given("^i am at the WF home page$")
    public void iAmAtTheWFHomePage() throws IOException {
        HPObject.VerifyHomePage();
    }

    @When("^i click on the TALK TO US link$")
    public void iClickOnTheTALKTOUSLink() throws IOException {
        HPObject.talkToUs();
    }

    @And("^i can be able to click on the feedback/suggestion link$")
    public void iCanBeAbleToClickOnTheFeedbackSuggestionLink() throws IOException {
        talkToUsObject.suggestion();
    }

    @And("^i can be able to send email$")
    public void iCanBeAbleToSendEmail() throws IOException {
        talkToUsObject.suggestioncheckPoint();
    }
}
