package atnl.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class ATNLHomePage {


    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String operationalManagementLabel = "ATNL Page";


    @FindBy(how = How.XPATH, using = "/html/body/div[1]/div/div/div/a[1]")
    public WebElement operationalManagement;

    public ATNLHomePage(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void LaunchPage() {
        businessBankingHelper.verifyAndClickElement( operationalManagement, operationalManagementLabel);
    }



}
