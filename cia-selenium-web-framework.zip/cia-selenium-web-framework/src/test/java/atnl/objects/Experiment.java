package atnl.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Experiment {

    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String operationalManagementLabel = "New Experiment";


    @FindBy(how = How.XPATH, using = "/html/body/div[1]/div[3]/div/div/div/a")
    public WebElement newExperiment;
    @FindBy(how = How.XPATH, using = "//*[@id=\"experimentSetupHeader\"]/h4")
    public WebElement setExperiment;

    @FindBy(how = How.XPATH, using = "//*[@id=\"divSTCreateExperiment\"]/div/div/div[1]/div[1]/div/div[1]/div[1]/div/div/button")
    public WebElement businessUnit;

    @FindBy(how = How.XPATH, using = "//*[@id=\"divSTCreateExperiment\"]/div/div/div[1]/div[1]/div/div[1]/div[1]/div/div/ul/li[6]/a/label")
    public WebElement card;

    @FindBy(how = How.ID, using = "txtExperimentName")
    public WebElement experimentName;

    @FindBy(how = How.ID, using = "txtDescription")
    public WebElement description;

    @FindBy(how = How.ID, using = "dtEventStartDate")
    public WebElement dtEventStartDate;

    public Experiment(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void createNewExperiment() {

        newExperiment.click();
        setExperiment.click();
        experimentName.sendKeys("Test Automation 1");
        description.sendKeys("Test Automation 1");
        dtEventStartDate.sendKeys("2021/01/01");

        businessUnit.click();
        card.click();
        description.click();

    }


}
