package atnl.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class ValidateUserName {
    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;

    @FindBy(how = How.XPATH, using = "//*[@id=\"ExperimentTableList\"]/thead/tr/th[1]")
    public WebElement newExperiment;

    public ValidateUserName(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void checkUser(){



    }
    public void dropDown(int value, WebElement element){

        for(int x = 0; x < value;++x){
            element.sendKeys(Keys.ARROW_DOWN);
        }
        element.sendKeys(Keys.ENTER);

    }
}
