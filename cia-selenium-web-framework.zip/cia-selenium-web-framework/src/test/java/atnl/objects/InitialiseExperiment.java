package atnl.objects;

import cm_utils.BusinessBankingHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

public class InitialiseExperiment {


    public final WebDriver driver;
    BusinessBankingHelper businessBankingHelper;
    final String operationalManagementLabel = "OPERATIONAL MANAGEMENT";


    @FindBy(how = How.XPATH, using = "//*[@id=\"navbarDropdown\"]")
    public WebElement dataExplorer;

    @FindBy(how = How.XPATH, using = "//*[@id=\"navbarSupportedContent\"]/ul[1]/li[3]/div/a[1]")
    public WebElement maintainDataset;

    @FindBy(how = How.XPATH, using = "//*[@id=\"navbarSupportedContent\"]/ul[1]/li[3]/div/a[2]")
    public WebElement linkPreExperimentData;

    @FindBy(how = How.XPATH, using = "//*[@id=\"navbarSupportedContent\"]/ul[1]/li[3]/div/a[3]")
    public WebElement linkPostExperimentData;

    @FindBy(how = How.ID, using = "ddlBusinessUnits")
    public WebElement ddlBusinessUnits;

    @FindBy(how = How.ID, using = "ddlExperiments")
    public WebElement ddlExperiments;

    @FindBy(how = How.XPATH, using = "/html/body/span/span/span[1]/input")
    public WebElement listBoxSearch;

    @FindBy(how = How.XPATH, using = "//*[@id=\"select2-ddlDataExplorerList-container\"]")
    public WebElement dataExplorerList;

    @FindBy(how = How.ID, using = "btnSaveAndInitialise")
    public WebElement saveAndInitialise;

    @FindBy(how = How.XPATH, using = "//*[@id=\"ddlBusinessUnits\"]")
    public WebElement postBusinessUnit;

    @FindBy(how = How.XPATH, using = "//*[@id=\"ddlExperiments\"]")
    public WebElement postExperimentList;

    @FindBy(how = How.ID, using = "ddlUploadType")
    public WebElement postUploadType;

    @FindBy(how = How.ID, using = "ddlDataExplorerList")
    public WebElement postDataSetList;

    @FindBy(how = How.ID, using = "btnLinkPostExperimentData")
    public WebElement postExperimentButton;

    public InitialiseExperiment(WebDriver driver){
        this.driver = driver;
        businessBankingHelper = new BusinessBankingHelper(driver);
        PageFactory.initElements(driver, this);
    }

    public void linkPreExperiment() {
        try{

            businessBankingHelper.clickElement( dataExplorer);
            businessBankingHelper.verifyAndClickElement( linkPreExperimentData, "linkPreExperimentData");

            Select select = new Select(ddlBusinessUnits);

            select.selectByVisibleText("Card");
            Select experiment = new Select(ddlExperiments);

            experiment.selectByVisibleText("Test Data");

            dataExplorerList.click();
            listBoxSearch.sendKeys("dfasdf");
            Thread.sleep(100);
            listBoxSearch.sendKeys(Keys.ARROW_DOWN);
            listBoxSearch.sendKeys(Keys.ENTER);

            businessBankingHelper.takeSnapShot("PreExperiment");

            saveAndInitialise.click();


        System.out.println("______");

        }catch (Exception e){
            e.printStackTrace();
        }

    }

    public void linkPostExperiment(){

        businessBankingHelper.clickElement( dataExplorer);
        businessBankingHelper.verifyAndClickElement( linkPostExperimentData, "linkPostExperimentData");

//        Select postBusinessUnitSelect = new Select(postBusinessUnit);
//        postBusinessUnitSelect.selectByVisibleText("Card");

        dropDown(5, postBusinessUnit);


        Select postExperimentSelect = new Select(postExperimentList);
        postExperimentSelect.selectByVisibleText("Test Data");


//        Select postUploadTypeSelect = new Select(postUploadType);
//        postUploadTypeSelect.selectByVisibleText("Control Table");
        dropDown(5, postUploadType);



        Select postDataSetSelect = new Select(postDataSetList);

        List<WebElement> dataList = postDataSetSelect.getOptions();

        for (WebElement elementAtIndex:dataList) {
            System.out.println(elementAtIndex.getText());
            if(elementAtIndex.getText().trim().equals("20210415 test Control Ram")){
                elementAtIndex.click();
            }
        }


//        postExperimentButton.click();

    }

    public void dropDown(int value, WebElement element){

        for(int x = 0; x < value;++x){
            element.sendKeys(Keys.ARROW_DOWN);
        }
        element.sendKeys(Keys.ENTER);

    }

}
