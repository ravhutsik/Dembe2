package atnl.tests;

import atnl.objects.ATNLHomePage;
import atnl.objects.InitialiseExperiment;
import cm_business_banking.tests.LaunchDriver;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ATNLTest {

    LaunchDriver launchDriver =new LaunchDriver("http://ciaatnlwebqa/ATnL");
    ATNLHomePage atnlHomePage;
    InitialiseExperiment initialiseExperiment = new InitialiseExperiment(launchDriver.getDriver());



    @Given("^I am at ATNL home page$")
    public void iAmAtATNLHomePage() {
        launchDriver.getDriver();
    }

    @When("^I am able to verify and select Continue Here field$")
    public void iAmAbleToVerifyAndSelectContinueHereField() {
        atnlHomePage = new ATNLHomePage(launchDriver.getDriver());
        atnlHomePage.LaunchPage();

        initialiseExperiment.linkPostExperiment();
    }

    @Then("^I am able see various options for ATnL Experiments$")
    public void iAmAbleSeeVariousOptionsForATnLExperiments() {
    }
}
