package atnl.tests;

import atnl.objects.ATNLHomePage;
import atnl.objects.Experiment;
import cm_business_banking.tests.LaunchDriver;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class ExperimentTest {
    LaunchDriver launchDriver =new LaunchDriver("http://ciaatnlwebqa/ATnL/Experiments");
    Experiment experiment = new Experiment(launchDriver.getDriver());

    @And("^I am able to click New Experiment option$")
    public void iAmAbleToClickNewExperimentOption() {
        experiment.createNewExperiment();
    }

    @Then("^Verify that new Experiment is created$")
    public void verifyThatNewExperimentIsCreated() {
    }
}
