package cm_utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import java.io.File;
import java.util.concurrent.TimeUnit;

public class DriverFactory {
    private static WebDriver driver = null;

    public DriverFactory(){

    }

    public static WebDriver getDriver(String url) {

        //String url = "http://biscorpmemqa:86/WF/Home";
        System.setProperty("webdriver.edge.driver", "common_drivers" + File.separator + "msedgedriver.exe");

        if (driver == null) {
            driver = new EdgeDriver();
        }

        driver.get(url); // open the metadata hub system URL
        driver.manage().window().maximize(); //maximise the browser
        driver.manage().deleteAllCookies();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); //waiting for the page to load

        return driver;
    }

}
