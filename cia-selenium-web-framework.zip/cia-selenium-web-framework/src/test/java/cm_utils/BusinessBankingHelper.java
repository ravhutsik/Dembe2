package cm_utils;

import com.mongodb.Bytes;
import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class BusinessBankingHelper {

    private final WebDriver driver;

    public BusinessBankingHelper(WebDriver driver){
        this.driver=driver;

        //Initialise Elements
        PageFactory.initElements(driver, this);
    }

    public void verifyPage(String expected, WebElement webElement){

        String actualText = webElement.getText();
        Assert.assertEquals(expected ,actualText);

    }
    public void verifyMultiPage(String expected, WebElement webElement){
        takeSnapShot(expected +" Page");
        String actualText = webElement.getText();
        Assert.assertEquals(expected ,actualText);
    }
    public void clickElement(WebElement webElement){
        webElement.click();
    }


    public int getWebElement(WebElement webElement, String elementName){

        List<WebElement> elements = webElement.findElements(By.xpath("*"));
        int index = 0;
        for (WebElement element: elements) {
            System.out.println(element);

            ++index;

            if(element.getText().trim().equals(elementName.trim())){
                return index;
            }
        }

        throw new AssertionError(elementName + " Not Found on the List");
    }

    public void verifyAndClickElement(WebElement webElement,String pictureName){
        try{
            System.out.println(webElement.getText());
            takeSnapShot(pictureName);
            if(webElement.isDisplayed()){
                webElement.click();
            }else{
                throw new AssertionError( pictureName + " Element is not visible");
            }

        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }

    }
    public void verifyAndClickMultiElement(WebElement webElement,String pictureName){
        try{
            String actualText = webElement.getText();
            System.out.println(actualText);
            takeSnapShot(pictureName);
            if(webElement.isDisplayed()){
                webElement.click();
            }else{
                throw new AssertionError( pictureName + " Element is not visible");
            }
            takeSnapShot(pictureName +" Page");
            Assert.assertEquals(pictureName ,actualText);

        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }

    }

    public void navigateBack()  {
        driver.navigate().back();
    }
    public WebElement getWebElement(String value){
        return driver.findElement(By.xpath("//*[text() = '"+ value +"']"));
    }


    public void verifyAndClickElement(String expected, WebElement webElement,String pictureName){
        try{
            System.out.println(webElement.getText());
            takeSnapShot(pictureName);
            if(webElement.isDisplayed()){
                webElement.click();
            }else{
                throw new AssertionError("Element is not visible");
            }

        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }

    }

    public void performOperation(String [] listOfValues){
        for (String listOfValue : listOfValues) {
            verifyAndClickMultiElement(getWebElement(listOfValue), listOfValue);
            navigateBack();
        }
    }

    public void takeSnapShot(String fileWithPath){

        try{
            TakesScreenshot takeScreenshot = ((TakesScreenshot) driver);

            File srcFile = takeScreenshot.getScreenshotAs(OutputType.FILE);


            File destFile = new File("C:\\opt\\cia-selenium-web-framework\\target\\screenshot\\" + fileWithPath + ".png");

            FileUtils.copyFile(srcFile,destFile);

        }catch (Exception e){
            e.printStackTrace();
            throw new AssertionError(e.getMessage());
        }
    }

    public void closePage(){
        driver.close();
    }
}
